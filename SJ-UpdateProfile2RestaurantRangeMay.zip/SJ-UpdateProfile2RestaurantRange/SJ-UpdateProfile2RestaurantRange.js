'use strict';

//var dbUtil = require('./utils/DBUtils');
//var helper = require('./utils/LogosHelper');
//var deepstream = require('./utils/DeepstreamUtils');
var moment = require('moment-timezone');
var mysql = require('mysql');
var request = require('request');
var async = require('async');
var chgRest = [];

var googleMapsClient = require('@google/maps').createClient({
  key: 'AIzaSyAee__HtugospcGV7XzDUiD0AZsA37sbBc'
});

exports.handler = (event, context, callback) => {
	var results;
	var doneCount = 0;
		
	findChangedProfiles (results, function(err, response) {
		if (err) {
			console.log('findChangedProfiles: ' + err);			
		} else {
			console.log('findChangedProfiles: ' + response);
		}
		doneCount++;
    		console.log('Complete - findChangedProfiles - DoneCount Main = ' + doneCount);
		if 	(doneCount === 1) {
			callback(null, 'Finished');
		}
	});		
}

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}


//Feature 5: Finds restauarants which have been added 
//MM 02-15-2018 This function finds any new restaurants and inserts records into home2restaurant based on proximity 
function findChangedProfiles (results, callback) {
	var connection = new getLogosConnection();
	var sql;
	var lastRun = new Date();
	var chgRestItem;
	var doneCount = 0;
	var maxCount;
	var rngArray = [];	
	var latitudeMin;
	var longitudeMin;
	var latitudeMax;
	var longitudeMax;
    var latitudeOffset;
    var longitudeOffset;
	const milesPerDegree = 69.172;
	
	var rngArrayItem = {
		'range':1
	};
	rngArray.push(rngArrayItem);
	var rngArrayItem2 = {
		'range':5
	};
	rngArray.push(rngArrayItem2);
	var rngArrayItem3 = {
		'range':10
	};
	rngArray.push(rngArrayItem3);
	
	lastRun.setHours(lastRun.getHours()-1);
	var sqlDate = moment(lastRun).format("YYYY-MM-DD  HH:mm:ss");
	//console.log('findChangedRestaurants lastRun - ' + lastRun);
	sql =  "select profileid, latitude, longitude from logoshealth.profile where latitude is not null and badaddress != 'Y' and activeflag = 'Y'" +
	" and geochange > '" + sqlDate + "'";
	
	console.log('Initial Query SQL: ' + sql);
	connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('findChangedProfiles : The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
        } else {
            if (results !== null && results.length > 0) {
				console.log('findChangedProfiles - Result length count: ' + results.length);
				//console.log('findProfiles - Results ', results);
				for (var j = 0; j < results.length; j++) {
                		for (var k = 0; k < rngArray.length; k++) {
						latitudeOffset = rngArray[k].range/milesPerDegree;				
						latitudeMin = +results[j].latitude - +latitudeOffset;				
						latitudeMax = +results[j].latitude + +latitudeOffset;				

						longitudeOffset = rngArray[k].range/(Math.cos(results[j].latitude* (Math.PI / 180))*milesPerDegree);
						longitudeMin = +results[j].longitude - +longitudeOffset;				
						longitudeMax = +results[j].longitude + +longitudeOffset;				
							
						chgRestItem = {
							'profileid':results[j].profileid,
							'searchrange':rngArray[k].range,
    							'latitude':results[j].latitude,
    							'latitudemin':latitudeMin,
    							'latitudemax':latitudeMax,
    							'latitudeoffset':latitudeOffset,
							'longitude':results[j].longitude,
    							'longitudemin':longitudeMin,
    							'longitudemax':longitudeMax,
    							'longitudeoffset':longitudeOffset
						};
						chgRest.push(chgRestItem);
   						//console.log('restGeoItem --->', restGeoItem);
   						console.log('chgRestItem --->', chgRestItem);	
					}
				}
				closeConnection(connection); //all is done so releasing the resources	
				callback(null, 'Success Happy Path Test - findChangedProfiles');																	
			
				if(chgRest !== null && chgRest.length > 0) {
					for (var i = 0; i < chgRest.length; i++) {
						//BOOKMARK
						insertMapping(chgRest[i], function(err, response) {
    							if (err) {
        							console.log(err);
								doneCount++;
								if (doneCount === chgRest.length) {
									console.log('findChangedProfiles - doneCountErr: ' + doneCount + 'chgRestErr: '+ chgRest.length);
									callback(err, null);																	
								} 	
    							} else {
								doneCount++;	
								console.log('findChangedProfiles - doneCount: ' + doneCount);
								if (doneCount === chgRest.length) {
									console.log('findChangedProfiles - doneCountHappy: ' + doneCount + 'restGeoHappy: '+ chgRest.length);
									callback(null, 'Success Happy Path - findChangedProfiles');																	
								} 	
							}
						});
					}	
				} else {
					callback(null, 'No data found - inner loop findChangedProfiles');					
				}		
			}	else {
				closeConnection(connection); //all is done so releasing the resources	
				callback(null, 'No data found - outer loop findChangedProfiles');
			}
		}
    });	
}	

//MM 02-15-2018 This function inserts records into the home2restaurant table
function insertMapping (chgItem, callback) {
	var connection = new getLogosConnection();
	var sql; 

	
	sql = "insert into logoshealth.home2restaurant (restaurantid, profileid, searchrange) " +
	"select restaurantid, " + chgItem.profileid + ", " + chgItem.searchrange + " from logoshealth.restaurant " +
	"where latitude between " + chgItem.latitudemin + " and " + chgItem.latitudemax + 
    " and longitude between " + chgItem.longitudemin + " and " + chgItem.longitudemax + " and restaurantid not in " +
	"(select restaurantid from logoshealth.home2restaurant where profileid = " + chgItem.profileid +
	" and searchrange = " + chgItem.searchrange + ")";
	
	console.log('SQL --->' + sql);
	connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('insertMapping : The Error is: ', error);
			console.log("for SQL: " + sql);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results.affectedRows > 0)  {
				console.log("Records add for profileid = " + chgItem.profileid + ", searchrange = " + chgItem.searchrange + ": " + results.affectedRows);
				closeConnection(connection); //all is done so releasing the resources	
				callback(null, 'Success');
			}	else {
				closeConnection(connection); //all is done so releasing the resources
				callback(null, 'No New Records Inserted');
			}
		}
    });	
}	

