/**
    Copyright LogosHealth.com, Inc. or its affiliates. All Rights Reserved.
*/

/**
 * An interactive Alexa Voice call interpretor LogosHealth
 *
 */

/**
 * App ID for the LogosHealth skill
 */
var APP_ID;


/**
 * The AlexaSkill prototype and helper functions
 */
var AlexaSkill = require('./AlexaSkill');

/**
 * comments
 *
 * @see 
 */
var Logos = function () {
    AlexaSkill.call(this, APP_ID);
};

// Extend AlexaSkill
Logos.prototype = Object.create(AlexaSkill.prototype);
Logos.prototype.constructor = Logos;

Logos.prototype.eventHandlers.onSessionStarted = function (sessionStartedRequest, session) {
    console.log("onSessionStarted requestId: " + sessionStartedRequest.requestId + ", sessionId: " + session.sessionId);
    // any initialization logic goes here
};

Logos.prototype.eventHandlers.onLaunch = function (launchRequest, session, response) {
    console.log("onLaunch requestId: " + launchRequest.requestId + ", sessionId: " + session.sessionId);
    //connectionLogosDatabase(response);
    //loadRDS(response);
};

/**
 * Overridden to show that a subclass can override this function to teardown session state.
 */
Logos.prototype.eventHandlers.onSessionEnded = function (sessionEndedRequest, session) {
    console.log("onSessionEnded requestId: " + sessionEndedRequest.requestId + ", sessionId: " + session.sessionId);
    // any cleanup logic goes here
};

Logos.prototype.intentHandlers = {
    "OpenLogosHealthProfile": function (intent, session, response) {
        handleLogosOpenRequest(response);
    },
    
    "CreateLogosHealthProfile": function (intent, session, response) {
        handleLogosProfileRequest(response);
    },

    "AMAZON.YesIntent": function (intent, session, response) {
        response.ask("User picked Yes, process continues", "What can I help you with?");
    },
    
    "AMAZON.NoIntent": function (intent, session, response) {
        response.ask("User picked No option, close process?", "GoodBye");
    },
    
    "AMAZON.HelpIntent": function (intent, session, response) {
        response.ask("You can choose existing options or choose to read health text?", "What can I help you with?");
    },

    "AMAZON.StopIntent": function (intent, session, response) {
        var speechOutput = "Goodbye";
        response.tell(speechOutput);
    },

    "AMAZON.CancelIntent": function (intent, session, response) {
        var speechOutput = "Goodbye";
        response.tell(speechOutput);
    }
};

/**
 * Initializes App with welcome message.
 */
function handleLogosOpenRequest(response) {
    // Send standard welcome message
    // Create speech output
    var speechOutput = "Welcome to Logos Health personal health records.  Who am I speaking with today?";
    var cardTitle = "Welcome message";
    response.tellWithCard(speechOutput, cardTitle, speechOutput);
}

/**
 * Creates a new profile for Logos Health
 */
function handleLogosProfileRequest(response) {
    // Verify if profile has existence in database, if yes voice out inability to create one more otherwise initlize process to create one
    var speechOutput = "New profile creating. Please provide member name";
    var cardTitle = "Profile creation";
    response.tellWithCard(speechOutput, cardTitle, speechOutput);
}

function loadRDS(response) {
   addRoleToDBCluster(params, function (err, data) {
    if (err) console.log(err, err.stack); // an error occurred
        else     console.log(data);           // successful response
    });
}

/**
 * Connect MySQL database, print database connection
 */
function connectionLogosDatabase(response) {
    // Connect AWS MySQL database
    var mysql = require('mysql');
    
    var connection = mysql.createConnection({
        host     : 'logosadmin.cc3uezlhb8ve.us-west-2.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin',
        password : 'L0g0sH3alth',  //yet to encrypt password
        database : 'logoshealth'

    });
    var app = express();

    connection.connect(function(err){

        if(!err) {
            console.log("Database is connected ... "+connection);    
        } else {
            console.log("Error connecting database ... ");    
        }
    });
    
    connection.end();
    
    var speechOutput = "Database Connection "+connection;
    var cardTitle = "DB Connection";
    response.tellWithCard(speechOutput, cardTitle, speechOutput);
}

// Create the handler that responds to the Alexa Request.
exports.handler = function (event, context) {
    // Create an instance of the LogosHealth skill.
    var logos = new Logos();
    logos.execute(event, context);
};

