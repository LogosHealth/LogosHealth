
// Create the handler that responds to the Alexa Request.
exports.handler = function (event, context, callback) {
    console.log("One ");
    
    exports.checkConnection(event, function(res) {
        context.succeed(res) 
    });
  
};

//module.exports = AlexaSkill;

exports.checkConnection = function(event, context, callback) {

  var mysql = require('mysql')
  var connection = mysql.createConnection({
        host     : 'testlogos.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin',
        password : 'testlogos'  //yet to encrypt password

    });
    
    connection.connect();
    console.log("The connection is "+connection);
    connection.query('SELECT * FROM testdb.Account', function (error, results, fields) {
        if (error) {
            console.log('The Error is: ', error);
        } else {
            //console.log('Result set Array is : ', results);
            if (results !== null && results.length > 0) {
                for (var res in results) {
                    console.log('Row is : ', results[res]);
                }
                
            }
            console.log('Connection Successfully Established <<<<<< ');
        }
    });

  connection.end();
  //context.callbackWaitsForEmptyEventLoop = false;
  //callback("ok","ok");
};