'use strict';

/**
 * LogosHealth App Request Handler. This Action class reviews Alexa AVS commands and provides a response.
 * Supports an interactive mode from Alexa
 * Persists user inputs
 * Provides options based on LogosHealth App
 */

//global variables
var AWS = require('aws-sdk');
var mysql = require('mysql');
var dbUtil = require('./Utils/DBUtis.js');
var helper = require('./Utils/LogosHelper.js');

var APP_ID = 'amzn1.ask.skill.43a6c098-7243-4e50-9017-d080c86eee32';

// --------------- Helpers that build all of the responses -----------------------

function buildSpeechletResponse(title, output, repromptText, shouldEndSession) {
    return {
        outputSpeech: {
            type: 'PlainText',
            text: output,
        },
        card: {
            type: 'Simple',
            title: `${title}`,
            content: `${output}`,
        },
        reprompt: {
            outputSpeech: {
                type: 'PlainText',
                text: repromptText,
            },
        },
        shouldEndSession,
    };
}

function buildResponse(sessionAttributes, speechletResponse) {
    return {
        version: '1.0',
        sessionAttributes,
        response: speechletResponse,
    };
}


// --------------- Functions that control the skill's behavior -----------------------

function getWelcomeResponse(callback) {
    // If we wanted to initialize the session to have some attributes we could add those here.
    const sessionAttributes = {};
    const cardTitle = 'LogosHealth App';

    let speechOutput = 'Welcome to Logos Health personal health records.  Who am I speaking with today??", "Welcome';

    const repromptText = 'What can I help you with?';
    const shouldEndSession = false;
    
    callback(sessionAttributes, buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession));

}

function verifyUserExists(event,context, callback) {
    //Check Database with profile name, if exists repond with greeting else propose a creation
    console.log('Check Profile by Name has been called >>>>>>');
    var accountsRes = [];
    var mysql = require('mysql');
    var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin',
        password : 'L0g0sH3alth'  //yet to encrypt password

    });
    
    connection.connect();
    console.log("The connection is "+connection);
    connection.query('SELECT * FROM logoshealth.Account', function (error, results, fields) {
        if (error) {
            console.log('The Error is: ', error);
        } else {
            //console.log('Result set Array is : ', results);
            
            if (results !== null && results.length > 0) {
                for (var res in results) {
                    console.log('Row is : ', results[res]);
                    accountsRes.push(results[res]);
                }
            }
            
            console.log('Connection Successfully Established <<<<<< '+results);
            //callback(null,results);
            connection.end();
        }
    });
    return accountsRes;
}

function handleSessionEndRequest(callback) {
    const cardTitle = 'Session Ended';
    const speechOutput = 'Have a nice day!';
    // Setting this to true ends the session and exits the skill.
    const shouldEndSession = true;

    callback({}, buildSpeechletResponse(cardTitle, speechOutput, null, shouldEndSession));
}


// --------------- Events -----------------------

/**
 * Called when the session starts.
 */
function onSessionStarted(sessionStartedRequest, session) {
    console.log(`onSessionStarted requestId=${sessionStartedRequest.requestId}, sessionId=${session.sessionId}`);
}

/**
 * Called when the user launches the skill without specifying what they want.
 */
function onLaunch(launchRequest, session, callback) {
    //console.log(`onLaunch requestId=${launchRequest.requestId}, sessionId=${session.sessionId}`);

    //console.log('BeforeGetWelcomeResponse');
    getWelcomeResponse(callback);
    //console.log('AfterGetWelcomeResponse: ' + callback);
}

/**
 * Deprecated: TODO: clean it. Removed it!!!
 * Called when the user launches the skill to Open Logos Health Application.
 */
function onOpenLogosApp(event, context, launchRequest, session, callback) {
    //console.log(`onLaunch requestId=${launchRequest.requestId}, sessionId=${session.sessionId}`);

    console.log('Before verifyUserExists >>>>>');
    verifyUserExists(event,context, callback);
    console.log('After verifyUserExists: <<<<<<< ' + callback);
}

/**
 * Called when the user specifies an intent for this skill.
 */
function processIntent(event, context, intentRequest, session, callback) {
    console.log("onIntent requestId=" + intentRequest.requestId
        + ", sessionId=" + session.sessionId);
 
    var intent = intentRequest.intent,
        intentName = intentRequest.intent.name;
 
 
    // dispatch custom intents to handlers here
    if (intentName == 'OpenLogosHealthProfile') {
        handleOpenLogosHealthProfile(event, context,intent, session, callback);
    }    
    else if (intentName == 'CreateLogosHealthProfile') {        
	    handleCreateLogosHealthProfile(event, context, intent, session, callback);    
    } 
    else if (intentName == 'AMAZON.HelpIntent') {        
	    helpRequest(intent, session, callback);    
    }    
    else if (intentName == 'AMAZON.CancelIntent')  {        
	    quitRequest(intent, session, callback);  
    }
    else {
        throw "Invalid intent";
    }
}

/*
* Intent handlers, TODO: Implement
*/

function handleOpenLogosHealthProfile (event, context, intent, session, callback) {
    
    const sessionAttributes = {};
    const cardTitle = 'Open Profile';

    let speechOutput = 'Hello Marty, How are you today?", "Welcome';

    const repromptText = 'Opening a profile';
    const shouldEndSession = false;
    
    var accounts = verifyUserExists(event, context, callback);
    
    console.log(" The Accounts retrieved from Database >>>>"+accounts);

    callback(sessionAttributes, buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession));
}

function createAppLink (event, context, request, appID) {
    var request_id = event.request.requestId;
    var echo_id = '';
    //for APP id use global variable APP_ID
    
    //TODO:
    //make aa link with the appID and requestor device ID
    //API CALL HERE
}

function handleCreateLogosHealthProfile (event, context, intent, session, callback) {
    //TODO: Implementation
    
    const sessionAttributes = {};
    const cardTitle = 'Open Profile';

    let speechOutput = 'Hello, your create profile request has been initiated", "Provide inputs';

    const repromptText = 'Creating a profile';
    const shouldEndSession = false;
    
    //TODO: Implement Create Profile DB logic here
    
    
    callback(sessionAttributes, buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession));
}

function helpRequest (intent, session, callback) {
    //TODO: Implementation
}

function quitRequest (intent, session, callback) {
    //TODO: Implementation
}

/**
 * Called when the user ends the session.
 * Is not called when the skill returns shouldEndSession=true.
 */
function onSessionEnded(sessionEndedRequest, session) {
    console.log(`onSessionEnded requestId=${sessionEndedRequest.requestId}, sessionId=${session.sessionId}`);
    // Add cleanup logic here
}


// --------------- Main handler -----------------------

// Route the incoming request based on type (LaunchRequest, IntentRequest,
// etc.) The JSON body of the request is provided in the event parameter.
exports.handler = (event, context, callback) => {
    try {
        //console.log(`event.session.application.applicationId=${event.session.application.applicationId}`);

        /**
         * Populate Skill APP ID to control function calls.
         */
        
        if (event.session.new) {           
            console.log('New Session created >>>>>');
            onSessionStarted({ requestId: event.request.requestId }, event.session);
        }

        if (event.request.type === 'LaunchRequest') {
            console.log('Launch Request processing >>>>>.');
            onLaunch(event.request,event.session,
                (sessionAttributes, speechletResponse) => {
                    callback(null, buildResponse(sessionAttributes, speechletResponse));
                });
        } else if (event.request.type === 'IntentRequest') {
            console.log('Intent Request processing >>>>>');
            processIntent(event, context, event.request,event.session,
                (sessionAttributes, speechletResponse) => {
                    callback(null, buildResponse(sessionAttributes, speechletResponse));
                });
            
        } else if (event.request.type === 'SessionEndedRequest') {
            console.log('SessionEndedRequest >>>>>>');
            onSessionEnded(event.request, event.session);
            callback();
        }
    } catch (err) {
        callback(err);
    }
};