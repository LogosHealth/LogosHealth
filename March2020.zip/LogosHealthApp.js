'use strict';

var dbUtil = require('./utils/DBUtils');
var helper = require('./utils/LogosHelper');
//var deepstream = require('./utils/DeepstreamUtils');
var moment = require('moment-timezone');

var request = require('request');

//var googleMapsClient = require('@google/maps').createClient({
//  key: 'AIzaSyBIX3hQyWMfJHRk8zRlkzUtCIXXlcntELc'
//});

// --------------- Functions that control the skill's behavior -----------------------
function onLaunch(event, launchRequest, session, callback) {	
	accountEmail(event, request, session, accountId, callback);
}

function accountId(error, data, session, event, callback) {
    if (error) throw error;
    console.log(" The Email found from account is "+data.email);
    dbUtil.getAccountIdFromEmail(data.email, session, event, callback);
}

function accountEmail(event, request, session, accountId, callback) {
	var amznProfileURL = 'https://api.amazon.com/user/profile?access_token=';
    amznProfileURL += event.session.user.accessToken;
    
	console.log('Event: ', event);
	console.log('User: ', session.user);
	
    request(amznProfileURL, function(error, response, body) {
 	    var respBody = "";
 	    if (!error && response.statusCode == 200) {
    	    respBody = JSON.parse(body);
    	    console.log('Email from Amazon: ' + respBody.email);
    	    console.log('JSON Body: ', respBody);
	    } else {
    	    console.log('error: ' + error);
    	    console.log('response.statusCode: ' + response.statusCode);
			
		}		
	    accountId(error,respBody, session, event, callback);
	});
}

function onSessionStarted(event, sessionStartedRequest, context, session, callback) {
    console.log('onSessionStarted requestId=${sessionStartedRequest.requestId}, sessionId=${session.sessionId}');    
}

function onSessionEnded(sessionEndedRequest, session) {
	var dateNow = Date.now();	
	console.log('Date Now >>>>>', moment.tz(dateNow, "America/Los_Angeles").format());
    console.log('onSessionEnded requestId=${sessionEndedRequest.requestId}, sessionId=${session.sessionId}');
}

// --------------- Main handler -----------------------
exports.handler = (event, context, callback) => {
    try {        
            if (event.session.new) {           
                console.log('New Session created >>>>>');
                //console.log('User information: ', event.request.context.System.user);
                console.log('Event information: ', event);
                console.log('Person information: ', event.context.System.person);
                onSessionStarted(event,{ requestId: event.request.requestId }, context, event.session,  
            		(sessionAttributes, speechletResponse) => {
                        callback(null, helper.buildResponse(sessionAttributes, speechletResponse));
                    });
                onLaunch(event,event.request,event.session,
                    (sessionAttributes, speechletResponse) => {
                        callback(null, helper.buildResponse(sessionAttributes, speechletResponse));
                    });                    
            } else {        
                if (event.request.type === 'LaunchRequest') {
                    console.log('Launch Request processing >>>>>.');
                    onLaunch(event,event.request,event.session,
                        (sessionAttributes, speechletResponse) => {
                            callback(null, helper.buildResponse(sessionAttributes, speechletResponse));
                        });
                } else if (event.request.type === 'IntentRequest') {
                    console.log('Intent Request processing >>>>>');
                    helper.processUserReponse(event, context, event.request,event.session,
                        (sessionAttributes, speechletResponse) => {
                            callback(null, helper.buildResponse(sessionAttributes, speechletResponse));
                        });            
                } else if (event.request.type === 'SessionEndedRequest') {
                    console.log('SessionEndedRequest >>>>>>');
                    console.log('event.request: ', event.request);
                    console.log('event.session: ', event.session);
                
                    onSessionEnded(event.request, event.session);
                    callback();
                } else {
                    console.log('SessionRequest fall through');
                    console.log('event.request: ', event.request);
                    console.log('event.session: ', event.session);
                }
            }
        } catch (err) {
            console.log('***Main Try Catch Error from exports.handler***', err);
            callback(err);
    }
};