'use strict';

var mysql = require('mysql');
var moment = require('moment');
var pool;

exports.handler = (event, context, callback) => {
	var bodyJson;
	console.log('event: ', event);
	//console.log('event method: ', event.httpMethod);
	//console.log('context: ', context);	

	pool = mysql.createPool({
		connectionLimit: 100,
		connectTimeout: 5000,
		acquireTimeout: 5000,
		multipleStatements: true,
		host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
		port      : '3306',
		user     : 'logosadmin', //yet to encrypt password and read from properties
		password : 'L0g0sH3alth', //yet to encrypt password and read from properties
		database: 'logoshealth',
		debug: false
	});    

  if (event.httpMethod == 'GET') { 
	console.log('GET method called');  
	GetGoalsByProfile (event, function(err, response) {
		if (err) {
			console.log('Error from GetGoalsByProfile: ' + err);
			bodyJson = JSON.stringify(err);
		} else {
			console.log('Results from GetGoalsByProfile: ' + response);
			bodyJson = JSON.stringify(response);
		}
		var responsePackage = {
			"statusCode": 200,
			"headers": {
				"GetGoalsByProfile": "Complete"
			},
			"body": bodyJson,
			"isBase64Encoded": false
		};
		closePool();	
		callback(null, responsePackage);
	});		
  } else if (event.httpMethod == 'POST') {
	console.log('POST method called');  
	VaccinesByProfileSave (event, function(err, response) {
		if (err) {
			console.log('Error from VaccinesByProfileSave: ' + err);
			bodyJson = JSON.stringify(err);
		} else {
			console.log('Results from VaccinesByProfileSave: ' + response);
			bodyJson = JSON.stringify(response);
		}
		var responsePackage = {
			"statusCode": 200,
			"headers": {
				"VaccinesByProfile": "Complete"
			},
			"body": bodyJson,
			"isBase64Encoded": false
		};
		closePool();	
		callback(null, responsePackage);
	});		

  } else {
	console.log('Wrong method called');  
	closePool();	
	callback('Wrong method called', null);
	  
  }
}

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

//Feature 2: Finds profiles without GeoCoords -->  gets GeoCoords from Google Maps --> update GeoCoords 
//MM 02-07-2018 This function finds any restaurants without GeoCoords - cloned from findRestaurantsWithoutGeoCoords 
function GetGoalsByProfile (event, callback) {
	var connection = new getLogosConnection();
	var sql = "SELECT goalid, version, goalname, goaltype, goalnumber, goalunit, goalunitvalue, daysperweek, daysperweekvalue, reward, rewardtiming, " +
	"rewardtimingvalue, activeflag FROM logoshealth.goal where activeflag = 'Y'";

	var resultsItem;
	var resultsSubItem;
	var populars = [];
	var popularsItem = [];
	var skip = false;
	var curID;
	var getStats = false;
	var weeks = [];
	var days = [];
		
	if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
	  && event.queryStringParameters.profileid !== "") {
		sql = sql + " and profileid = " + event.queryStringParameters.profileid + " order by createddate desc";
	} else {
		skip = true;
		callback('Invalid query parameters', null);					
	}

	if(event.queryStringParameters !== undefined && event.queryStringParameters.getStats !== undefined  
		&& event.queryStringParameters.getStats !== "") {
		  if (event.queryStringParameters.getStats == "Y") {
			  getStats = true;
		  }
	  } 
	  
	if (skip == false) {
	  console.log('GetGoalsByProfile Retrieve SQL: ' + sql);	
	  connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('GetGoalsByProfile: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results !== null && results.length > 0) {
				console.log('GetGoalsByProfile - Result length count: ' + results.length);

				for (var j = 0; j < results.length; j++) {				
					resultsItem = {
						'recordid':results[j].goalid,
    					'version':results[j].version,
						'goalname':results[j].goalname,
						'goaltype':results[j].goaltype,
						'goalnumber':results[j].goalnumber,
						'goalunit':results[j].goalunit,
						'goalunitvalue':results[j].goalunitvalue,
						'daysperweek':results[j].daysperweek,
						'daysperweekvalue':results[j].daysperweekvalue,
						'goalnumber':results[j].goalnumber,
						'reward':results[j].reward,
						'rewardtiming':results[j].goalnumber,
						'rewardtimingvalue':results[j].goalnumber,
						'activeflag':results[j].activeflag,
						'weeks':[]
					};
					populars.push(resultsItem);						
				}	
				if (!getStats) {
					closeConnection(connection); //all is done so releasing the resources	
					console.log('Final Results: ', populars);	
					callback(null, populars);					
				} else {
					closeConnection(connection);
					var goalsCount = populars.length;
					var goalsActual = 0;
					//var objWeek = {};
					var blnNextLoop = false;
					var weeksTotal = 0;
					for (var j = 0; j < populars.length; j++) {				
						var SQLWeeks = 	"SELECT goal_trackingid, week_start, week_end, days_met from logoshealth.goal_tracking where goalid = " + populars[j].recordid;
						console.log("SQLWeeks: " + SQLWeeks);
						getWeeksInfo(SQLWeeks, j, function(error, results) {
							if (error) {
								console.log('GetGoalsByProfile: The Error is: ', error);
								//closeConnection(connection); //all is done so releasing the resources
								callback(error, null);
							} else {
								populars[results.index].weeks = results.weeks;
								console.log('GetGoalsByProfile - GetStats - Get Weeks: ' + results.index + ': ', populars[results.index].weeks);								
								weeksTotal = weeksTotal + populars[results.index].weeks.length;
								console.log('Weeks Total: ' + weeksTotal);
								goalsActual = goalsActual + 1;
								console.log("Goals Actual - Week: " + goalsActual);
								if (goalsActual == goalsCount) {
									console.log("Goals Actual = GoalsCount Week: " + goalsActual);
									var objDay = {};
									var weeksActual = 0;
									var daysTotal = 0;
									var goalCountDays = populars.length;
									console.log('Weeks Total Final: ' + weeksTotal);
									for (var j = 0; j < populars.length; j++) {			
										var weeksActualDays = 0;
										for (var k = 0; k < populars[j].weeks.length; k++) {				
											var SQLDays = 	"SELECT goal_tracking_dayid, day, total, daily_goal_met from logoshealth.goal_tracking_day where " +
											  "goal_trackingid = " + populars[j].weeks[k].recordid;	
											
											getDaysInfo(SQLDays, j, k, function(error, results) {
												if (error) {
													console.log('GetGoalsByProfile - getDaysInfo Return: The Error is: ', error);
													callback(error, null);
												} else {
													populars[results.indexGoal].weeks[results.indexWeek].days = results.days;
													daysTotal = daysTotal + populars[results.indexGoal].weeks[results.indexWeek].days.length;
													weeksActual = weeksActual + 1;
													if (weeksActual == weeksTotal) {
														console.log('Days Total Final: ' + daysTotal);												
														callback(null, populars);  //Ultimate success for retrieving goals, weeks, and days statistics												
													} else {
														console.log('Weeks Total: ' + weeksTotal + ', Weeks Actual: ' + weeksActual );																								
													}
												}											  
											});
										}
									}
								}
							}
						});
					}
				}
			}
		}
	  });
	}
}

function VaccinesByProfileSave (event, callback) {
	var jsonObject = JSON.parse(event.body);
	var jsonObj2 = JSON.parse(jsonObject);
	var attCount = 0;
	var expectedCount = 0;
	var executedCount = 0;
	var sql;
	var skip = false;

	console.log('VaccinesByProfileSave: ', jsonObj2);
	if (jsonObj2.schedules !== null && jsonObj2.schedules.length > 0) {
		for (var i = 0; i < jsonObj2.schedules.length ; i++) {
			skip = false;
			sql = "Update logoshealth.vaccine_schedule set ";
			attCount = 0;
			if (jsonObj2.schedules[i].startdate !==undefined) {
				attCount = attCount + 1;
				sql = sql + "datereceived='" + jsonObj2.schedules[i].startdate +"', "
			}
			if (jsonObj2.schedules[i].physician !==undefined) {
				attCount = attCount + 1;
				sql = sql + "medicalcontacttext='" + jsonObj2.schedules[i].physician +"', "
			}
			if (attCount > 0){
				if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
					&& event.queryStringParameters.profileid !== "") {
					  sql = sql + "modifiedby = " + event.queryStringParameters.profileid + 
					  " where vaccine_scheduleid = " + jsonObj2.schedules[i].recordid;
					  expectedCount = expectedCount + 1;
					  //console.log('Set expected in loop - expected = ' + expectedCount + ' i = ' + i);
				} else {
					skip = true;
					callback('Invalid query parameters', null);					
				}
				if (!skip) {
					executeSQL(sql, function(err, response) {
						if (err) {
							callback(err, null);
						} else {
							executedCount = executedCount + 1;	
							if (executedCount == expectedCount) {
								callback(null, response);
							} else {
								console.log('I = ' + i + ' Expected: ' + expectedCount + ' Executed: ' + executedCount);
							}
						}
					});		
				}			
			}
		}

		skip = false;
		attCount = 0;
		sql = "Update logoshealth.vaccine set ";
		if (jsonObj2.active !==undefined) {
			attCount = attCount + 1;
			sql = sql + "activeflag='" + jsonObj2.active +"', "
		}
		if (jsonObj2.confirmed !==undefined) {
			attCount = attCount + 1;
			sql = sql + "confirmedflag='" + jsonObj2.confirmed +"', "
		}

		if (attCount > 0) {
			if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
				&& event.queryStringParameters.profileid !== "") {
				  sql = sql + "modifiedby = " + event.queryStringParameters.profileid + 
				  " where vaccineid = " + jsonObj2.recordid;
				  expectedCount = expectedCount + 1;
				  //console.log('Set expected Main record - expected = ' + expectedCount);
			} else {
				skip = true;
				callback('Invalid query parameters', null);					
			}
			if (!skip) {
				executeSQL(sql,  function(err, response) {
					if (err) {
						callback(err, null);
					} else {
						executedCount = executedCount + 1;	
						if (executedCount == expectedCount) {
							callback(null, response);
						} else {
							console.log('Main Record Expected: ' + expectedCount + ' Executed: ' + executedCount);
						}
				}
				});		
			}
		} else {
			if (executedCount == expectedCount) {
				callback(null, 'Success');
			}				
		}		

	} else {
		sql = "Update logoshealth.vaccine set ";
		if (jsonObj2.active !==undefined) {
			attCount = attCount + 1;
			sql = sql + "activeflag='" + jsonObj2.active +"', "
		}
		if (jsonObj2.confirmed !==undefined) {
			attCount = attCount + 1;
			sql = sql + "confirmedflag='" + jsonObj2.confirmed +"', "
		}
		if (jsonObj2.startdate !==undefined) {
			attCount = attCount + 1;
			sql = sql + "vaccinedate='" + jsonObj2.startdate +"', "
		}
		if (jsonObj2.physician !==undefined) {
			attCount = attCount + 1;
			sql = sql + "medicalcontacttext='" + jsonObj2.physician +"', "
		}
		if (attCount > 0) {
			if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
				&& event.queryStringParameters.profileid !== "") {
				  sql = sql + "modifiedby = " + event.queryStringParameters.profileid + 
				  " where vaccineid = " + jsonObj2.recordid;
				  expectedCount = expectedCount + 1;
			} else {
				skip = true;
				callback('Invalid query parameters', null);					
			}
			if (!skip) {
				executeSQL(sql,  function(err, response) {
					if (err) {
						callback(err, null);
					} else {
						callback(null, response);
					}
				});		
			}
		}
	}
}

function executeSQL (sql, callback) {
	console.log('executeSQL: ' + sql);
	pool.getConnection(function(err, conn) {
		if (err) {
			console.log('Execute SQL error: ', err);
		} else {
			conn.query(sql, function (error, results, fields) {
				if (error) {
					console.log('executeSQL: The Error is: ', error);
					conn.release();
					callback(error, null);
				} else {
					conn.release();
					callback(null, 'Success');
				}
			});	
		}
	});
}

function getWeeksInfo (sql, index, callback) {
	var weeks = [];
	var returnObj = {
		'index':index,
		'weeks':weeks
	}

	console.log('getWeeksInfo: ' + sql);
	pool.getConnection(function(err, conn) {
		if (err) {
			console.log('getWeeksInfo: ', err);
		} else {
			conn.query(sql, function (error, results, fields) {
				if (error) {
					console.log('getWeeksInfo executeSQL: The Error is: ', error);
					conn.release();
					callback(error, null);
				} else {
					for (var k = 0; k < results.length; k++) {				
						var objWeek = {
							'recordid':results[k].goal_trackingid,
							'week_start':results[k].week_start,
							'week_end':results[k].week_end,
							'days_met':results[k].days_met,
							'days':[]
						}
						//console.log('Results obj: ' + results[k].goal_trackingid);
						//console.log('k: ' + k);
						//console.log('objWeek: ' + objWeek.recordid);
						weeks.push(objWeek);								
					}

					returnObj.weeks = weeks;	
					console.log('getWeeksInfo Final Return Obj: ', returnObj)				
					conn.release();
					callback(null, returnObj);
				}
			});	
		}
	});
}

function getDaysInfo (sql, indexGoal, indexWeek, callback) {
	var days = [];
	var returnObj = {
		'indexGoal':indexGoal,
		'indexWeek':indexWeek,
		'days':days
	}

	console.log('getDaysInfo executeSQL: ' + sql);
	pool.getConnection(function(err, conn) {
		if (err) {
			console.log('getDaysInfo: ', err);
		} else {
			conn.query(sql, function (error, results, fields) {
				if (error) {
					console.log('getDaysInfo executeSQL: The Error is: ', error);
					conn.release();
					callback(error, null);
				} else {
					for (var k = 0; k < results.length; k++) {				
						var objDay = {
							'recordid':results[k].goal_tracking_dayid,
							'day':results[k].day,
							'total':results[k].total,
							'daily_goal_met':results[k].daily_goal_met
						}
						//console.log('Results obj: ' + results[k].goal_trackingid);
						//console.log('k: ' + k);
						//console.log('objWeek: ' + objWeek.recordid);
						days.push(objDay);								
					}

					returnObj.days = days;	
					console.log('geDaysInfo Final Return Obj: ', returnObj)				
					conn.release();
					callback(null, returnObj);
				}
			});	
		}
	});
}

function closePool() {
	pool.end();
}
