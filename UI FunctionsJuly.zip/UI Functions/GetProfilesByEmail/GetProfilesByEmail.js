'use strict';

var mysql = require('mysql');

exports.handler = (event, context, callback) => {
	var bodyJson;
	console.log('event: ', event);
	console.log('context: ', context);	
	getProfileIdsFromEmail (event, function(err, response) {
		if (err) {
			console.log('Error from getProfileIdsFromEmail: ' + err);
			bodyJson = JSON.stringify(err);
		} else {
			console.log('Results from getProfileIdsFromEmail: ' + response);
			bodyJson = JSON.stringify(response);
		}
		var responsePackage = {
			"statusCode": 200,
			"headers": {
				"getProfileIdsFromEmail": "Complete"
			},
			"body": bodyJson,
			"isBase64Encoded": false
		};
		callback(null, responsePackage);
	});		
}

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

//Feature 2: Finds profiles without GeoCoords -->  gets GeoCoords from Google Maps --> update GeoCoords 
//MM 02-07-2018 This function finds any restaurants without GeoCoords - cloned from findRestaurantsWithoutGeoCoords 
function getProfileIdsFromEmail (event, callback) {
	var connection = new getLogosConnection();
	var sql = "select profileid, concat(upper(substr(firstname, 1, 1)),  lower(substr(firstname, 2, length(firstname) - 1))) " + 
	"as firstname, photopath from logoshealth.profile where activeflag = 'Y' and accountid =" +
	"(select accountid from logoshealth.Account where activeflag = 'Y'";
	var resultsItem;
	var populars = [];
	var skip = false;
	
	if(event.queryStringParameters !== undefined && event.queryStringParameters.email !== undefined  && event.queryStringParameters.email !== "") {
		sql = sql + " and email = '" + event.queryStringParameters.email + "') order by profileid";
	} else {
		skip = true;
		callback('Invalid query parameters', null);					
	}

	if (skip == false) {
	  connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('getProfileIdsFromEmail: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results !== null && results.length > 0) {
				console.log('getProfileIdsFromEmail - Result length count: ' + results.length);
                for (var j = 0; j < results.length; j++) {				
					resultsItem = {
						'profileid':results[j].profileid,
    					'title':results[j].firstname,
						'image':results[j].photopath
					};
					populars.push(resultsItem);
				}	
				closeConnection(connection); //all is done so releasing the resources	
				callback(null, populars);					
			} else {
				closeConnection(connection); //all is done so releasing the resources	
				callback('No data found', null);					
			}
		}
	  });
	}	
}	
