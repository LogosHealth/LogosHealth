'use strict';

var mysql = require('mysql');
var moment = require('moment');

exports.handler = (event, context, callback) => {
	var bodyJson;
	console.log('event: ', event);
	//console.log('event method: ', event.httpMethod);
	//console.log('context: ', context);	

  if (event.httpMethod == 'GET') { 
	console.log('GET method called');  
	VaccinesByProfile (event, function(err, response) {
		if (err) {
			console.log('Error from VaccinesByProfile: ' + err);
			bodyJson = JSON.stringify(err);
		} else {
			console.log('Results from VaccinesByProfile: ' + response);
			bodyJson = JSON.stringify(response);
		}
		var responsePackage = {
			"statusCode": 200,
			"headers": {
				"VaccinesByProfile": "Complete"
			},
			"body": bodyJson,
			"isBase64Encoded": false
		};
		callback(null, responsePackage);
	});		
  } else if (event.httpMethod == 'POST') {
	console.log('POST method called');  
	VaccinesByProfileSave (event, function(err, response) {
		if (err) {
			console.log('Error from VaccinesByProfileSave: ' + err);
			bodyJson = JSON.stringify(err);
		} else {
			console.log('Results from VaccinesByProfileSave: ' + response);
			bodyJson = JSON.stringify(response);
		}
		var responsePackage = {
			"statusCode": 200,
			"headers": {
				"VaccinesByProfile": "Complete"
			},
			"body": bodyJson,
			"isBase64Encoded": false
		};
		callback(null, responsePackage);
	});		

  } else {
	console.log('Wrong method called');  
	callback('Wrong method called', null);
	  
  }
}

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

//Feature 2: Finds profiles without GeoCoords -->  gets GeoCoords from Google Maps --> update GeoCoords 
//MM 02-07-2018 This function finds any restaurants without GeoCoords - cloned from findRestaurantsWithoutGeoCoords 
function VaccinesByProfile (event, callback) {
	var connection = new getLogosConnection();
	var sql = "SELECT v.vaccineid, v.profileid, d.dictionarycode as vaccinename, v.vaccinedate, v.medicalcontacttext, v.confirmedflag, " +
	"vt.interval, vt.recommendedagelow, vt.recommendedagehigh, vt.recommendedageunits, vt.notes, vs.vaccine_scheduleid, vs.datereceived, vs.medicalcontacttext as medcontact " +
	"FROM logoshealth.dictionary d, logoshealth.vaccine v left join logoshealth.vaccine_schedule vs on v.vaccineid = vs.vaccineid " +
	"left join logoshealth.vaccine_template vt on vs.vaccine_templateid = vt.vaccine_templateid where d.dictionaryid = v.vaccinenameid and v.activeflag = 'Y'";

	var resultsItem;
	var resultsSubItem;
	var populars = [];
	var popularsItem = [];
	var skip = false;
	var curID;
	
	if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
	  && event.queryStringParameters.profileid !== "") {
		sql = sql + " and profileid = " + event.queryStringParameters.profileid + " order by v.profileid, d.dictionarycode, vt.interval, vs.datereceived";
	} else {
		skip = true;
		callback('Invalid query parameters', null);					
	}

	if (skip == false) {
	  connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('VaccinesByProfile: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results !== null && results.length > 0) {
				console.log('VaccinesByProfile - Result length count: ' + results.length);

				for (var j = 0; j < results.length; j++) {				
					if (j==0) {
						curID = results[j].vaccineid;
					}
					if (curID !==results[j].vaccineid) {
						populars.push(resultsItem);
						popularsItem = [];
						curID = results[j].vaccineid;
					}

					if (results[j].vaccine_scheduleid !== null) {
						resultsSubItem = {
							'recordid':results[j].vaccine_scheduleid,
							'interval':results[j].interval,
							'agerangelow':results[j].recommendedagelow,
							'agerangehigh':results[j].recommendedagehigh,
							'agerangeunit':results[j].recommendedageunits,
							'notes':results[j].notes,
							'startdate':moment(results[j].datereceived).format('MM/DD/YYYY'),
							'physician':results[j].medcontact
						}	
						popularsItem.push(resultsSubItem);
					}

					resultsItem = {
						'recordid':results[j].vaccineid,
    					'name':results[j].vaccinename,
						'startdate':moment(results[j].vaccinedate).format('MM/DD/YYYY'),
						'physician':results[j].medicalcontacttext,
						'confirmed':results[j].confirmedflag,
						'schedules':popularsItem
					};
					if (j==results.length-1) {
						populars.push(resultsItem);						
					}
				}	
				closeConnection(connection); //all is done so releasing the resources	
				console.log('Final Results: ', populars)
				for (var j = 0; j < populars.length; j++) {
					if (populars[j].schedules.length > 0) {
						console.log('Final Schedules: ', populars[j].schedules);						
					} 
				}	
				callback(null, populars);					
			} else {
				closeConnection(connection); //all is done so releasing the resources	
				callback('No data found', null);					
			}
		}
	  });
	}	
}	

function VaccinesByProfileSave (event, callback) {
	var jsonObject = JSON.parse(event.body);
	var jsonObj2 = JSON.parse(jsonObject);
	var attCount = 0;
	var expectedCount = 0;
	var executedCount = 0;
	var sql;
	var skip = false;

	console.log('VaccinesByProfileSave: ', jsonObj2);
	if (jsonObj2.schedules !== null && jsonObj2.schedules.length > 0) {
		for (var i = 0; i < jsonObj2.schedules.length ; i++) {
			skip = false;
			sql = "Update logoshealth.vaccine_schedule set ";
			attCount = 0;
			if (jsonObj2.schedules[i].startdate !==undefined) {
				attCount = attCount + 1;
				sql = sql + "datereceived='" + jsonObj2.schedules[i].startdate +"', "
			}
			if (jsonObj2.schedules[i].physician !==undefined) {
				attCount = attCount + 1;
				sql = sql + "medicalcontacttext='" + jsonObj2.schedules[i].physician +"', "
			}
			if (attCount > 0){
				if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
					&& event.queryStringParameters.profileid !== "") {
					  sql = sql + "modifiedby = " + event.queryStringParameters.profileid + 
					  " where vaccine_scheduleid = " + jsonObj2.schedules[i].recordid;
					  expectedCount = expectedCount + 1;
					  //console.log('Set expected in loop - expected = ' + expectedCount + ' i = ' + i);
				} else {
					skip = true;
					callback('Invalid query parameters', null);					
				}
				if (!skip) {
					executeSQL(sql, function(err, response) {
						if (err) {
							callback(err, null);
						} else {
							executedCount = executedCount + 1;	
							if (executedCount == expectedCount) {
								callback(null, response);
							} else {
								console.log('I = ' + i + ' Expected: ' + expectedCount + ' Executed: ' + executedCount);
							}
						}
					});		
				}			
			}
		}

		skip = false;
		attCount = 0;
		sql = "Update logoshealth.vaccine set ";
		if (jsonObj2.active !==undefined) {
			attCount = attCount + 1;
			sql = sql + "activeflag='" + jsonObj2.active +"', "
		}
		if (jsonObj2.confirmed !==undefined) {
			attCount = attCount + 1;
			sql = sql + "confirmedflag='" + jsonObj2.confirmed +"', "
		}

		if (attCount > 0) {
			if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
				&& event.queryStringParameters.profileid !== "") {
				  sql = sql + "modifiedby = " + event.queryStringParameters.profileid + 
				  " where vaccineid = " + jsonObj2.recordid;
				  expectedCount = expectedCount + 1;
				  //console.log('Set expected Main record - expected = ' + expectedCount);
			} else {
				skip = true;
				callback('Invalid query parameters', null);					
			}
			if (!skip) {
				executeSQL(sql,  function(err, response) {
					if (err) {
						callback(err, null);
					} else {
						executedCount = executedCount + 1;	
						if (executedCount == expectedCount) {
							callback(null, response);
						} else {
							console.log('Main Record Expected: ' + expectedCount + ' Executed: ' + executedCount);
						}
				}
				});		
			}
		} else {
			if (executedCount == expectedCount) {
				callback(null, 'Success');
			}				
		}		

	} else {
		sql = "Update logoshealth.vaccine set ";
		if (jsonObj2.active !==undefined) {
			attCount = attCount + 1;
			sql = sql + "activeflag='" + jsonObj2.active +"', "
		}
		if (jsonObj2.confirmed !==undefined) {
			attCount = attCount + 1;
			sql = sql + "confirmedflag='" + jsonObj2.confirmed +"', "
		}
		if (jsonObj2.startdate !==undefined) {
			attCount = attCount + 1;
			sql = sql + "vaccinedate='" + jsonObj2.startdate +"', "
		}
		if (jsonObj2.physician !==undefined) {
			attCount = attCount + 1;
			sql = sql + "medicalcontacttext='" + jsonObj2.physician +"', "
		}
		if (attCount > 0) {
			if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
				&& event.queryStringParameters.profileid !== "") {
				  sql = sql + "modifiedby = " + event.queryStringParameters.profileid + 
				  " where vaccineid = " + jsonObj2.recordid;
				  expectedCount = expectedCount + 1;
			} else {
				skip = true;
				callback('Invalid query parameters', null);					
			}
			if (!skip) {
				executeSQL(sql,  function(err, response) {
					if (err) {
						callback(err, null);
					} else {
						callback(null, response);
					}
				});		
			}
		}
	}
}

function executeSQL (sql, callback) {
	var connection = new getLogosConnection();

	console.log('executeSQL: ' + sql);

	connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('executeSQL: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
			closeConnection(connection); //all is done so releasing the resources
			callback(null, 'Success');
		}
	  });		
}
