'use strict';

//var dbUtil = require('./utils/DBUtils');
//var helper = require('./utils/LogosHelper');
//var deepstream = require('./utils/DeepstreamUtils');
var moment = require('moment-timezone');
var mysql = require('mysql');
var request = require('request');
var async = require('async');
var restGeo = [];


var googleMapsClient = require('@google/maps').createClient({
  key: 'AIzaSyAee__HtugospcGV7XzDUiD0AZsA37sbBc'
});

exports.handler = (event, context, callback) => {
	var results;
    console.log('LogScheduledEvent');
    //console.log('Received event:', JSON.stringify(event, null, 2));
	findRestaurantsWithoutGeoCoords (results, callback); 
	findProfilesWithoutGeoCoords (results, callback);
	callback(null, 'Finished');
};

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

//Scheduled Jobs 

//Feature 1: Finds restaurants without GeoCoords -->  gets GeoCoords from Google Maps --> update GeoCoords 
//MM 02-06-2018 This function finds any restaurants without GeoCoords
function findRestaurantsWithoutGeoCoords (results, callback) {
	var connection = getLogosConnection();
	var sql = "select restaurantid, address, city, state, zipcode from logoshealth.restaurant where latitude is null and badaddress <> 'Y'";
	var restGeoItem;
	var strAddress;
	var restaurantid;
	
	connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('DBUtil.findRestaurantsWithoutGeoCoords : The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
        } else {
            if (results !== null && results.length > 0) {
                for (var res in results) {
					restGeoItem = {
						'restaurantid':results[res].restaurantid,
    						'address':results[res].address,
    						'city':results[res].city,
						'zipcode':results[res].zipcode
					};
					restGeo.push(restGeoItem);
   					//console.log('restGeoItem --->', restGeoItem);
   					//console.log('restGeo Length --->', restGeo.length);	
				}
				closeConnection(connection); //all is done so releasing the resources	

				if(restGeo !== null && restGeo.length > 0) {
					for (var i = 0; i < restGeo.length; i++) {
						strAddress = restGeo[i].address + ', ' + restGeo[i].city + ', ' + restGeo[i].zipcode;
						restaurantid = restGeo[i].restaurantid;
						console.log('strAddress --->', strAddress);
						getGeoCoords(strAddress, restaurantid, function(err, response) {
    							if (err) {
        							console.log(err);
    							} else {
								if (response.restaurantid !== undefined) {
									updateGeoCoords('restaurant', response, function(updateErr, updateResponse) {
    										if (updateErr) {
        										console.log('Update Error: ', updateErr);
    										} else {
        										console.log('UpdateResponse: ',  updateResponse);
										}
									});
								}	else {
	        							console.log('bad address, but doesnt error');																	
								}
    							}
						});
					}	
				}
			}	else {
				closeConnection(connection); //all is done so releasing the resources					
			}
		}
    });	
}	

//MM 02-06-2018 This function get GeoCoords from addresses and returns the GeoCoords or a badaddress flag when the address is bad
function getGeoCoords(strAddress, restaurantid, callback) {
	var geodata;
	
	googleMapsClient.geocode({
  			address: strAddress
			}, 	function(err, response) {
				if (!err) {
					console.log('Response Status: ' + response.json.status);
					if (response.json.status == 'OK') {
						geodata = {
                				"restaurantid": restaurantid,
							"status": response.json.status,
							"formattedAddress": response.json.results[0].formatted_address,
                				"latitude": response.json.results[0].geometry.location.lat,
                				"longitude": response.json.results[0].geometry.location.lng,
							"type": response.json.results[0].geometry.location_type
            				};	
						callback(null, geodata);
					} else if (response.json.status == 'ZERO_RESULTS') {
						geodata = {
                				"restaurantid": restaurantid,
							"badaddress": 'Y'
            				};		
						callback(null, geodata);
					}	else {
						console.log('Response Status fallout - ' + response.json.status);
						callback(response.json.status, null);						
					}
  				} else {
					console.log('Check Error');
					callback(err, null);
				}
		});
}

//MM 02-07-2018 This function updates GeoCoords to the proper table and record
function updateGeoCoords (tablename, geodata, callback) {
	var connection = getLogosConnection();
	var sql; 

	if (tablename == 'restaurant') {
		if(geodata.latitude !== undefined) {
			sql = "update logoshealth.restaurant set latitude = " + geodata.latitude + ", longitude = " + geodata.longitude + " where restaurantid = " + geodata.restaurantid;
		} else if (geodata.badaddress !== undefined) {
			sql = "update logoshealth.restaurant set badaddress = 'Y' where restaurantid = " + geodata.restaurantid;			
		} else {
			callback('Bad Geodata', null);		
		}
	} else if (tablename == 'profile') {
		if(geodata.latitude !== undefined) {
			sql = "update logoshealth.profile set latitude = " + geodata.latitude + ", longitude = " + geodata.longitude + " where profileid = " + geodata.profileid;
		} else if (geodata.badaddress !== undefined) {
			sql = "update logoshealth.profile set badaddress = 'Y' where profileid = " + geodata.profileid;			
		} else {
			callback('Bad Geodata', null);		
		}		
	} else {
		callback('Bad Table', null);
	}
	
	console.log('SQL --->' + sql);
	connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('updateGeoCoords : The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results.affectedRows > 0)  {
				closeConnection(connection); //all is done so releasing the resources	
				callback(null, 'Success');
			}	else {
				closeConnection(connection); //all is done so releasing the resources
				callback('No data update', null);
			}
		}
    });	
}	

//Feature 2: Finds profiles without GeoCoords -->  gets GeoCoords from Google Maps --> update GeoCoords 
//MM 02-07-2018 This function finds any restaurants without GeoCoords - cloned from findRestaurantsWithoutGeoCoords 
function findProfilesWithoutGeoCoords (results, callback) {
	var connection = getLogosConnection();
	var sql = "select profileid, streetaddress, city, state, zipcode from logoshealth.profile where latitude is null and badaddress <> 'Y'";
	var restGeoItem;
	var strAddress;
	var profileid;
	
	connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('findProfilesWithoutGeoCoords : The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
        } else {
            if (results !== null && results.length > 0) {
                for (var res in results) {
					restGeoItem = {
						'profileid':results[res].profileid,
    						'address':results[res].streetaddress,
    						'city':results[res].city,
						'zipcode':results[res].zipcode
					};
					restGeo.push(restGeoItem);
   					//console.log('restGeoItem --->', restGeoItem);
   					//console.log('restGeo Length --->', restGeo.length);	
				}
				closeConnection(connection); //all is done so releasing the resources	

				if(restGeo !== null && restGeo.length > 0) {
					for (var i = 0; i < restGeo.length; i++) {
						strAddress = restGeo[i].address + ', ' + restGeo[i].city + ', ' + restGeo[i].zipcode;
						profileid = restGeo[i].profileid;
						console.log('strAddress --->', strAddress);
						getProfileGeoCoords(strAddress, profileid, function(err, response) {
    							if (err) {
        							console.log(err);
    							} else {
								if (response.profileid !== undefined) {
									updateGeoCoords('profile', response, function(updateErr, updateResponse) {
    										if (updateErr) {
        										console.log('Update Error: ', updateErr);
    										} else {
        										console.log('UpdateResponse: ',  updateResponse);
										}
									});
								}	else {
	        							console.log('bad address, but doesnt error');																	
								}
    							}
						});
					}	
				}
			}	else {
				closeConnection(connection); //all is done so releasing the resources					
			}
		}
    });	
}	

//MM 02-07-2018 This function get GeoCoords from addresses and returns the GeoCoords or a badaddress flag when the address is bad for profiles - cloned from getGeoCoords
function getProfileGeoCoords(strAddress, profileid, callback) {
	var geodata;
	
	googleMapsClient.geocode({
  			address: strAddress
			}, 	function(err, response) {
				if (!err) {
					console.log('Response Status: ' + response.json.status);
					if (response.json.status == 'OK') {
						geodata = {
                				"profileid": profileid,
							"status": response.json.status,
							"formattedAddress": response.json.results[0].formatted_address,
                				"latitude": response.json.results[0].geometry.location.lat,
                				"longitude": response.json.results[0].geometry.location.lng,
							"type": response.json.results[0].geometry.location_type
            				};	
						callback(null, geodata);
					} else if (response.json.status == 'ZERO_RESULTS') {
						geodata = {
                				"profileid": profileid,
							"badaddress": 'Y'
            				};		
						callback(null, geodata);
					}	else {
						console.log('Response Status fallout - ' + response.json.status);
						callback(response.json.status, null);						
					}
  				} else {
					console.log('Check Error');
					callback(err, null);
				}
		});
}
