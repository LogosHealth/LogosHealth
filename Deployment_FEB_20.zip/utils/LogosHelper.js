/**
 * LogosHealth Application Utils. 
 * All global re-usable/utility functions listed here. Class could be expanded to cover my utils
 * JSON parsing is main 
 * Copyright Logos Health, Inc
 * 
 */

var aws = require('aws-sdk');
var request = require('request');
var dbUtil = require('./DBUtils');

/**
 * Create a new build response.
 * @param {object} [values]Session Attributes to use in add in response object
 * @param {object} Speech output
 * 
 * @public
 */
exports.buildResponse = function buildResponse(sessionAttributes, speechletResponse) {
	console.log(' LogosHelper.buildResponse >>>>>>');
	return {
        version: '1.0',
        sessionAttributes,
        response: speechletResponse,
    };
    
};

/**
 * Returns APP ID for Logos Health.
 * @param {object} none
 * @return {string} Context APP ID
 * 
 * @public
 */
exports.getAppLinkName = function getAppLinkName(event) {
	console.log(' LogosHelper.buildResponse >>>>>>');
	var appId = 'amzn1.ask.skill.43a6c098-7243-4e50-9017-d080c86eee32';
    appId = getAccountLinkName(event);
	return appId;
    
};

/**
 * Returns APP ID for Logos Health.
 * @param {object} none
 * @return {string} Context APP ID
 * 
 * @public
 */
exports.getUserName = function getUserName(callback) {
	console.log(' LogosHelper.getUserName >>>>>>');
    var userName = identifyUser(callback);
	return userName;
    
};

/**
 * Returns APP ID for Logos Health.
 * @param {object} none
 * @return {string} Context APP ID
 * 
 * @public
 */
exports.processSessionEnd = function processSessionEnd(callback) {
	console.log(' LogosHelper.processSessionEnd >>>>>>');
    handleSessionEndRequest(callback);
};


/**
 * Provides a speech response to Alexa using JSON format.
 * @param {object|string} Title of the Speech card
 * @param {object|string} Speech output text 
 * @param {object|string} To prompt speech out text
 * @param {object|string} Whether session to be end or not
 * @return {object} A JSON object constructed with speech out text
 * @public
 */
exports.buildSpeechletResponse = function buildSpeechletResponse(title, output, repromptText, shouldEndSession) {
  	console.log(' LogosHelper.buildSpeechletResponse >>>>>>');
  	return {
        outputSpeech: {
            type: 'PlainText',
            text: output,
        },
        card: {
            type: 'Simple',
            title: `${title}`,
            content: `${output}`,
        },
        reprompt: {
            outputSpeech: {
                type: 'PlainText',
                text: repromptText,
            },
        },
        shouldEndSession,
    };
};

/**
 * Method to create an App Link to from a new request.
 * @param {object|string} Event
 * @param {object|string} Context object 
 * @param {object|string} Request
 * @param {object|string} App ID
 * @return {object} Applink ID once successfully created or ERROR
 * @public
 */
exports.createApplink = function createApplink(event, context, request, appId) {
  	console.log(' LogosHelper.createApplink >>>>>>');
  	//TODO: implement code to create an App link from caller
};

/**
 * Debugs class instantiation.
 * @param {none} 
 * @return {boolean} Function could be called
 * @public
 */
exports.checkClassAccess = function checkClassAccess() {
  	console.log(' LogosHelper.checkClassAccess >>>>>>');
  	return true;
};

/**
 * Debugs class instantiation.
 * @param {none} 
 * @return {boolean} Function could be called
 * @public
 */
exports.displayWelcomeMsg = function displayWelcomeMsg(callback, accountid) {
  	console.log(' LogosHelper.checkClassAccess >>>>>>');
  	getWelcomeResponse(callback, accountid);
};

exports.createProfile = function createProfile(event, context, intent, session, callback) {
  	console.log(' LogosHelper.createProfile >>>>>>');
  	handleCreateLogosHealthProfile(event, context, intent, session, callback);
};

exports.openProfile = function openProfile(event, context, intent, session, callback) {
  	console.log(' LogosHelper.openProfile >>>>>>');
  	handleOpenLogosHealthProfile(event, context, intent, session, callback);
};

function getAccountLinkName (event) {
	var appName = "";
	var amznProfileURL = 'https://api.amazon.com/user/profile?access_token=';
    amznProfileURL += event.session.user.accessToken;
    request(amznProfileURL, function(error, response, body) {
        if (response.statusCode == 200) {
             var profile = JSON.parse(body);
             console.log('printing profile' + profile);
             appName = profile.name.split(" ")[0];
             console.log("LogosHelper >>>> :Hello, " + profile.name.split(" ")[0]);
                
         } else {
                console.log("LogosHelper >>>> : I can't connect to Amazon Profile Service right now, try again later");
                appName = 'NO_ID';
                
         }
     });
     
}

function getWelcomeResponse(callback, accountid ) {
    // If we wanted to initialize the session to have some attributes we could add those here.
    var sessionAttributes = {currentProcessor: 0,
    							logosaccountid: accountid };
    var cardTitle = 'LogosHealth App';

    var speechOutput = 'Logos Health personal health records.  Who am I speaking with today?", "Welcome';

    var repromptText = 'What can I help you with?';
    var shouldEndSession = false;
    
    callback(sessionAttributes, buildSpeechResponse(cardTitle, speechOutput, repromptText, shouldEndSession));

}

function buildSpeechResponse(title, output, repromptText, shouldEndSession) {
  	console.log(' LogosHelper.buildSpeechResponse >>>>>>');
  	return {
        outputSpeech: {
            type: 'PlainText',
            text: output,
        },
        card: {
            type: 'Simple',
            title: `${title}`,
            content: `${output}`,
        },
        reprompt: {
            outputSpeech: {
                type: 'PlainText',
                text: repromptText,
            },
        },
        shouldEndSession,
    };
}

function identifyUser(callback) {
    // If we wanted to initialize the session to have some attributes we could add those here.
    console.log(' Identifying User >>>>>>');
    var sessionAttributes = {currentProcessor: 1};
    var cardTitle = 'LogosHealth App';
    var userName = dbUtil.verifyUserProfile();
    var speechOutput = "";
    
    if (userName === null || userName.length == 0) {
    	speechOutput = 'Hello I could not found your profile. Would like to create one?';
    } else {
    	speechOutput = 'Hello '+userName+ ' How are you today? How can I help you?';
    }

    var repromptText = 'Menu Options';
    var shouldEndSession = false;
    
    callback(sessionAttributes, buildSpeechResponse(cardTitle, speechOutput, repromptText, shouldEndSession));

}

function handleSessionEndRequest(callback) {
    var cardTitle = 'Session Ended';
    var speechOutput = 'Have a nice day!';
    // Setting this to true ends the session and exits the skill.
    var shouldEndSession = true;

    callback({}, buildSpeechResponse(cardTitle, speechOutput, null, shouldEndSession));
}

function handleCreateLogosHealthProfile (event, context, intent, session, callback) {
    //TODO: Implementation
    
    var sessionAttributes = {};
    var cardTitle = 'Open Profile';

    var speechOutput = 'Hello, your create profile request has been initiated", "Provide inputs';

    var repromptText = 'Creating a profile';
    var shouldEndSession = false;
    
    //TODO: Implement Create Profile DB logic here
    //dbUtil.createHealthProfile(passparams);
    
    callback(sessionAttributes, buildSpeechResponse(cardTitle, speechOutput, repromptText, shouldEndSession));
}

function handleOpenLogosHealthProfile (event, context, intent, session, callback) {
    
    var sessionAttributes = {};
    var cardTitle = 'Open Profile';

    var speechOutput = 'Hello Marty, How are you today?", "Welcome to Logos Health App';

    var repromptText = 'Opening a profile';
    var shouldEndSession = false;
    
    var accounts = dbUtil.getAllUserAccounts();
    
    console.log(" The Accounts retrieved from Database >>>>"+accounts);

    callback(sessionAttributes, buildSpeechResponse(cardTitle, speechOutput, repromptText, shouldEndSession));
}

