'use strict';

var mysql = require('mysql');

exports.handler = (event, context, callback) => {
	var bodyJson;
	console.log('event: ', event);
	console.log('context: ', context);	
	AllergiesByProfile (event, function(err, response) {
		if (err) {
			console.log('Error from AllergiesByProfile: ' + err);
			bodyJson = JSON.stringify(err);
		} else {
			console.log('Results from AllergiesByProfile: ' + response);
			bodyJson = JSON.stringify(response);
		}
		var responsePackage = {
			"statusCode": 200,
			"headers": {
				"AllergiesByProfile": "Complete"
			},
			"body": bodyJson,
			"isBase64Encoded": false
		};
		callback(null, responsePackage);
	});		
}

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

//Feature 2: Finds profiles without GeoCoords -->  gets GeoCoords from Google Maps --> update GeoCoords 
//MM 02-07-2018 This function finds any restaurants without GeoCoords - cloned from findRestaurantsWithoutGeoCoords 
function AllergiesByProfile (event, callback) {
	var connection = new getLogosConnection();
	var sql = "SELECT medicaleventid, medicalevent, eventdescription, startdatetext, allergyseverity, medicallyconfirmed, " + 
	"confirmedflag FROM logoshealth.medicalevent where  isallergy = 'Y'";
	var resultsItem;
	var populars = [];
	var skip = false;
	
	if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
	  && event.queryStringParameters.profileid !== "") {
		sql = sql + " and profileid = " + event.queryStringParameters.profileid + " order by medicaleventid desc";
	} else {
		skip = true;
		callback('Invalid query parameters', null);					
	}

	if (skip == false) {
	  connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('AllergiesByProfile: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results !== null && results.length > 0) {
				console.log('AllergiesByProfile - Result length count: ' + results.length);
                for (var j = 0; j < results.length; j++) {				
					resultsItem = {
						'recordid':results[j].medicaleventid,
    					'name':results[j].medicalevent,
						'description':results[j].eventdescription,
						'startdate':results[j].startdatetext,
						'severity':results[j].allergyseverity,
						'medicallyconfirmed':results[j].medicallyconfirmed,
						'confirmed':results[j].confirmedflag
					};
					populars.push(resultsItem);
				}	
				closeConnection(connection); //all is done so releasing the resources	
				callback(null, populars);					
			} else {
				closeConnection(connection); //all is done so releasing the resources	
				callback('No data found', null);					
			}
		}
	  });
	}	
}	
