'use strict';

var mysql = require('mysql');
var moment = require('moment-timezone');
var timezone = "";

exports.handler = (event, context, callback) => {
	var bodyJson;
	console.log('event: ', event);
	console.log('context: ', context);	
	if (event.httpMethod == 'GET') { 
		console.log('GET method called');  
		NutritionByProfile (event, function(err, response) {
			if (err) {
				console.log('Error from NutritionByProfile: ' + err);
				bodyJson = JSON.stringify(err);
			} else {
				console.log('Results from NutritionByProfile: ' + response);
				bodyJson = JSON.stringify(response);
			}
			var responsePackage = {
				"statusCode": 200,
				"headers": {
					"NutritionByProfile": "Complete"
				},
				"body": bodyJson,
				"isBase64Encoded": false
			};
			callback(null, responsePackage);
		});		
	  } else if (event.httpMethod == 'POST') {
		console.log('POST method called');  
		NutritionByProfileSave (event, function(err, response) {
			if (err) {
				console.log('Error from NutritionByProfileSave: ' + err);
				bodyJson = JSON.stringify(err);
			} else {
				console.log('Results from NutritionByProfileSave: ' + response);
				bodyJson = JSON.stringify(response);
			}
			var responsePackage = {
				"statusCode": 200,
				"headers": {
					"NutritionByProfile": "Complete"
				},
				"body": bodyJson,
				"isBase64Encoded": false
			};
			callback(null, responsePackage);
		});		
	  } else {
		console.log('Wrong method called');  
		callback('Wrong method called', null);  
	  }	
}

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

//Feature 2: Finds profiles without GeoCoords -->  gets GeoCoords from Google Maps --> update GeoCoords 
//MM 02-07-2018 This function finds any restaurants without GeoCoords - cloned from findRestaurantsWithoutGeoCoords 
function NutritionByProfile (event, callback) {
	var connection = new getLogosConnection();
	var sql = "SELECT foodid, profileid, food, meal, amount, calories, dateofmeasure, activeflag, sort_order FROM logoshealth.food where activeflag = 'Y'";
	var sql2 = "select timezone from logoshealth.profile where profileid = ";
	var strOrder;
	var foodItem;
	var dayItem;
	var meals = [];
	var mealsSort = [];
	var populars = [];
	var skip = false;
	var strTimeZone = "";
	
	if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
	  && event.queryStringParameters.profileid !== "") {
		sql = sql + " and profileid = " + event.queryStringParameters.profileid + " order by dateofmeasure desc";
		sql2 = sql2 + event.queryStringParameters.profileid;
	} else {
		skip = true;
		callback('Invalid query parameters', null);					
	}

	if (skip == false) {
		connection.query(sql2, function (error, results, fields) {
        	if (error) {
            	console.log('NutritionByProfile: The Error is: ', error);
				closeConnection(connection); //all is done so releasing the resources
				callback(error, null);
			} else {
				if (results[0].timezone !== undefined && results[0].timezone !== null && results[0].timezone !== "") {
					strTimeZone = results[0].timezone;
					var strTimeAbbr = moment.tz(strTimeZone).zoneAbbr();
					var strOffset = "";
/*					console.log ('Timezone: ' + strTimeZone + ', Abbr: ' + strTimeAbbr);
					switch (strTimeAbbr) {
						case 'PST': 
							strOffset = '-08:00';
						break;
						case 'ALDT': 
							strOffset = '-08:00';
						break;
						case 'PDT': 
							strOffset = '-07:00';
						break;
						case 'MST': 
							strOffset = '-07:00';
						break;
						case 'MDT': 
							strOffset = '-06:00';
						break;
						case 'CST': 
							strOffset = '-06:00';
						break;
						case 'CDT': 
							strOffset = '-05:00';
						break;
						case 'EST': 
							strOffset = '-05:00';
						break;
						case 'EDT': 
							strOffset = '-04:00';
						break;
						case 'ALST': 
							strOffset = '-09:00';
						break;
						case 'HST': 
							strOffset = '-10:00';
						break;
						default: 
							strOffset = "";
					}
				} else {
					strOrder = " order by DATE_FORMAT(dateofmeasure, '%Y %m %d') desc, sort_order";
				}
				if (strOrder == "" && strOffset !== "") {
					strOrder = " order by DATE_FORMAT(CONVERT_TZ(dateofmeasure,'GMT','" + strTimeAbbr +"'), '%Y %m %d') desc, sort_order";
//					strOrder = " order by DATE_FORMAT(CONVERT_TZ(dateofmeasure,'+00:00','" + strOffset +"'), '%Y %m %d') desc, sort_order";
				} else {
					strOrder = " order by DATE_FORMAT(dateofmeasure, '%Y %m %d') desc, sort_order";
				}
				sql = sql + strOrder;
*/
				console.log('NutritionByProfile Get Final SQL: ' + sql);
				connection.query(sql, function (error, results, fields) {
					if (error) {
						console.log('NutritionByProfile: The Error is: ', error);
						closeConnection(connection); //all is done so releasing the resources
						callback(error, null);
					} else {
						if (results !== null && results.length > 0) {
							console.log('NutritionByProfile - Result length count: ' + results.length);
							var dayofmeasure;
							var dayofmeasureold;
							for (var j = 0; j < results.length; j++) {
								if (strTimeZone !== "") {
									dayofmeasure = moment(results[j].dateofmeasure).tz(strTimeZone).format('MMM-DD-YY');
								} else {
									dayofmeasure = moment(results[j].dateofmeasure).format('MMM-DD-YY');
								}				
								if (dayofmeasureold !== dayofmeasure){
									//console.log('Day of measure Switch old: '+ dayofmeasureold + ', dayofmeasure new: ' + dayofmeasure);
									if (j >0) {
										for (var l = 1; l < 6; l++) {
											for (var k = 0; k < meals.length; k++) {
												if (Number(meals[k].sort_order) == Number(l)) {
													mealsSort.push(meals[k]);
													//console.log('MealsSort push: day of measure: ' + dayofmeasureold +'food id: ' + meals[k].recordid + 
													  //', meal' + meals[k].meal + ', sort_order: ' + meals[k].sort_order);
												}
											}
										}

										dayItem = {
											'dayofmeasure': dayofmeasureold,
											'meals': mealsSort 
										}
										populars.push(dayItem);
										dayofmeasureold = dayofmeasure
										meals = [];
										mealsSort = [];
									} else {
										dayofmeasureold = dayofmeasure
									}
								}
								foodItem = {
									'recordid':results[j].foodid,
									'food':results[j].food,
									'meal':results[j].meal,
									'amount':results[j].amount,
									'calories':results[j].calories,
									'dateofmeasure':results[j].dateofmeasure,
									'active':results[j].activeflag,
									'profileid':results[j].profileid,
									'sort_order':results[j].sort_order
								};
								meals.push(foodItem);
								if (j == results.length - 1) {
									for (var k = 0; k < meals.length; k++) {
										for (var l = 1; l < 6; l++) {
											if (meals[k].sort_order == l) {
												mealsSort.push(meals[k]);
											}
										}
									}
								dayItem = {
										'dayofmeasure': dayofmeasure,
										'meals': mealsSort 
									}
									populars.push(dayItem);
								}
							}	
							closeConnection(connection); //all is done so releasing the resources	
							callback(null, populars);					
						} else {
							closeConnection(connection); //all is done so releasing the resources	
							callback('No data found', null);					
						}
					}
				  });
				}  			
			}	
		});
	}	
}	

function NutritionByProfileSave (event, callback) {
	var connection = new getLogosConnection();

	var jsonObject = JSON.parse(event.body);
	var jsonObj2 = JSON.parse(jsonObject);
	var blnInactivate = false;
	var blnNewRecord = false;
	var sql;
	var sql1;
	var sql2;
	var blnSkip = false;
	var dtNow = new Date();
	var dtSave = moment(dtNow);
	var dayofmeasure;
	var strTimeZone;
	var expectedCount;
	var actualCount = 0;

	console.log('NutritionByProfileSave: ', jsonObj2);
	console.log('NutritionByProfileSave meals count: ', jsonObj2.meals.length);

	expectedCount = jsonObj2.meals.length;
	for (var j = 0; j < jsonObj2.meals.length; j++) {
		if (jsonObj2.meals[j].timezone !==undefined && jsonObj2.meals[j].timezone !=="") {
			timezone = jsonObj2.meals[j].timezone;
		}	

		if (jsonObj2.meals[j].active !==undefined && jsonObj2.meals[j].active !=="") {
			if (jsonObj2.meals[j].active == "N") {
				blnInactivate = true;
				console.log ('NutritionByProfileSave - Delete');
			} else if (jsonObj2.meals[j].recordid == undefined || jsonObj2.meals[j].recordid == null || jsonObj2.meals[j].recordid == "") {
				blnNewRecord = true;
				console.log ('NutritionByProfileSave - Insert');
			} else {
				console.log ('NutritionByProfileSave - Update');
			}
		} else {
			callback('Invalid data', null);
			blnSkip = true;	
		}

		if (blnInactivate) {
			sql = "Update logoshealth.food set activeflag = 'N', modifiedby = " + jsonObj2.meals[j].userid + " where foodid = " + jsonObj2.meals[j].recordid;
		} else if (blnNewRecord) {
			sql1 = "Insert into logoshealth.food (";
			sql2 = "values (";

			if (jsonObj2.dayofmeasure !== undefined && jsonObj2.dayofmeasure !== null && jsonObj2.dayofmeasure !== "") {
				dayofmeasure = jsonObj2.dayofmeasure;
			} else {
				dayofmeasure = dtSave;
			}
		
			console.log("DayofMeasure: " + dayofmeasure);
			//console.log("DayofMeasure formatted: " + dayofmeasure.format("YYYY-MM-DD HH:mm"));

			if (jsonObj2.meals[j].food !==undefined) {
				sql1 = sql1 + "food, "
				sql2 = sql2 + "'" + jsonObj2.meals[j].food + "', ";
			}
			if (jsonObj2.meals[j].meal !==undefined) {
				sql1 = sql1 + "meal, "
				sql2 = sql2 + "'" + jsonObj2.meals[j].meal + "', ";
			}
			if (jsonObj2.meals[j].amount !==undefined) {
				sql1 = sql1 + "amount, "
				sql2 = sql2 + "'" + jsonObj2.meals[j].amount + "', ";
			}
			if (jsonObj2.meals[j].calories !==undefined) {
				sql1 = sql1 + "calories, "
				sql2 = sql2 + "'" + jsonObj2.meals[j].calories + "', ";
			}

			if (jsonObj2.meals[j].profileid !==undefined && jsonObj2.meals[j].userid !==undefined) {
				sql1 = sql1 + "profileid, createdby, modifiedby, dateofmeasure) ";
				sql2 = sql2 + jsonObj2.meals[j].profileid + ", " + jsonObj2.meals[j].userid + ", " + 
				jsonObj2.meals[j].userid + ", '"+  dayofmeasure + "')";
				sql = sql1 + sql2;			
			} else {
				callback('Invalid data', null);	
				blnSkip = true;	
			}
		} else {
			sql = "update logoshealth.food set ";
			if (jsonObj2.meals[j].food !==undefined) {
				sql = sql + "food = " + "'" + jsonObj2.meals[j].food + "', ";
			}
			if (jsonObj2.meals[j].meal !==undefined) {
				sql = sql + "meal = " + "'" + jsonObj2.meals[j].meal + "', ";
			}
			if (jsonObj2.meals[j].amount !==undefined) {
				sql = sql + "amount = " + "'" + jsonObj2.meals[j].amount + "', ";
			}
			if (jsonObj2.meals[j].calories !==undefined) {
				sql = sql + "calories = " + "'" + jsonObj2.meals[j].calories + "', ";
			}
			if (jsonObj2.meals[j].userid !==undefined && jsonObj2.meals[j].recordid !==undefined) {
				sql = sql + "modifiedby = " + jsonObj2.meals[j].userid + " where foodid = " + jsonObj2.meals[j].recordid;
			} else {
				callback('Invalid data', null);	
				blnSkip = true;	
			}
		}
	
		if (!blnSkip) {
			console.log('NutritionByProfileSave - Final SQL: ' + sql);
			connection.query(sql,  function (err, results, fields) {
				if (err) {
					actualCount = actualCount + 1;
					closeConnection(connection); //all is done so releasing the resources	
					callback(err, null);
				} else {
					actualCount = actualCount + 1;
					if (actualCount == expectedCount) {
						closeConnection(connection); //all is done so releasing the resources
						callback("Success", null);	
					} else {
						console.log ("ExpectedCount: " + expectedCount + ", actualCount: " + actualCount);
					}
				}
			});			
		} else {
			console.log('Skipped');
		}
	}	
}
