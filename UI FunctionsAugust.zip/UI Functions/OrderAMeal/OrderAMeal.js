'use strict';

var mysql = require('mysql');
var moment = require('moment');

exports.handler = (event, context, callback) => {
	var bodyJson;
	console.log('event: ', event);
	//console.log('event method: ', event.httpMethod);
	//console.log('context: ', context);	

  if (event.httpMethod == 'GET') { 
	console.log('GET method called');  
	OrderAMeal (event, function(err, response) {
		if (err) {
			console.log('Error from OrderAMeal: ' + err);
			bodyJson = JSON.stringify(err);
		} else {
			console.log('Results from OrderAMeal: ' + response);
			bodyJson = JSON.stringify(response);
		}
		var responsePackage = {
			"statusCode": 200,
			"headers": {
				"OrderAMeal": "Complete"
			},
			"body": bodyJson,
			"isBase64Encoded": false
		};
		callback(null, responsePackage);
	});		
  } else if (event.httpMethod == 'POST') {
	console.log('POST method called');  
	OrderAMealSave (event, function(err, response) {
		if (err) {
			console.log('Error from OrderAMealSave: ' + err);
			bodyJson = JSON.stringify(err);
		} else {
			console.log('Results from OrderAMealSave: ' + response);
			bodyJson = JSON.stringify(response);
		}
		var responsePackage = {
			"statusCode": 200,
			"headers": {
				"OrderAMeal": "Complete"
			},
			"body": bodyJson,
			"isBase64Encoded": false
		};
		callback(null, responsePackage);
	});		

  } else {
	console.log('Wrong method called');  
	callback('Wrong method called', null);
	  
  }
}

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

//Feature 2: Finds profiles without GeoCoords -->  gets GeoCoords from Google Maps --> update GeoCoords 
//MM 02-07-2018 This function finds any restaurants without GeoCoords - cloned from findRestaurantsWithoutGeoCoords 
function OrderAMeal (event, callback) {
	var connection = new getLogosConnection();
	var resultsItem;
	var populars = [];
	var popularsItem = [];
	var skip = false;
	var curID;

	var sql = "select r.restaurantid, r.restaurantname, r.address, r.city, r.phone, mi.menuitemid, mi.name, mi.description, mi.cost, mi.calories, " +
			"mi.totalfat, mi.saturatedfat, mi.transfat, mi.sodium, mi.carbs, mi.caloriesfromfat, mi.protein, mi.cholesterol, mi.dietaryfiber, mi.sugars, mi.photopath " + 
			"from logoshealth.menuitem mi, logoshealth.restaurant2menuitem r2m, logoshealth.menuitem_foodcategory mifc, logoshealth.restaurant r, " +
			"logoshealth.home2restaurant h2r, logoshealth.profile p, logoshealth.foodpreference fp,logoshealth.foodcategorypreference fcp, logoshealth.dietpreference dp, " +
			"logoshealth.dictionary d1, logoshealth.dictionary d2, logoshealth.dictionary d3 " +   
			"where mi.menuitemid = r2m.menuitemid and r2m.restaurantid = r.restaurantid and r.restaurantid = h2r.restaurantid and h2r.profileid = p.profileid " + 
			"and p.profileid = fp.profileid and p.profileid = fcp.profileid and p.profileid = dp.profileid and mi.menuitemid = mifc.menuitemid and fp.deliveryrange = d1.dictionaryid " +
			"and fp.maxcost = d2.dictionaryid and fp.deliveryoption = d3.dictionaryid " +
			/*restaurant - gets active restaurants that are open and witin the preferred search range*/
			"and r.active = 'Y' and r.opennow = 'Y' and h2r.searchrange = d1.dictionarycode " +
			/*diet preferences - active configuration, calories * mealsperentree > calories of the entree */
			"and dp.activeflag = 'Y'and mi.calories < (dp.targetcaloriesvalue* dp.mealsperentreevalue) " + 
			/*diet preferences*/
			"and (dp.iswhitemeat = 'N' or (dp.iswhitemeat = 'Y' and mi.iswhitemeat = 'Y')) " +
			"and (dp.ischicken = 'N' or (dp.ischicken = 'Y' and mi.ischicken = 'Y')) " +
			"and (dp.isvegetarian = 'N' or (dp.isvegetarian = 'Y' and mi.isvegetarian = 'Y')) " +
			"and (dp.isvegetariannoegg = 'N' or (dp.isvegetariannoegg = 'Y' and mi.isvegetariannoegg = 'Y')) " +
			"and (dp.isvegan = 'N' or (dp.isvegan = 'Y' and mi.isvegan = 'Y')) " +
			"and (dp.isvegan = 'N' or (dp.isvegan = 'Y' and mi.isvegan = 'Y')) " +
			"and (dp.ispescatarian = 'N' or (dp.ispescatarian = 'Y' and mi.ispescatarian = 'Y')) " +
			"and (dp.isavoiddairy = 'N' or (dp.isavoiddairy = 'Y' and mi.isavoiddairy = 'Y')) " +
			"and (dp.isglutenfree = 'N' or (dp.isglutenfree = 'Y' and mi.isglutenfree = 'Y')) " +
			"and (dp.islowcarb = 'N' or (dp.islowcarb = 'Y' and mi.islowcarb = 'Y')) " +
			"and (dp.ishearthealthy = 'N' or (dp.ishearthealthy = 'Y' and mi.ishearthealthy = 'Y')) " +
			"and (dp.islowsodium = 'N' or (dp.islowsodium = 'Y' and mi.islowsodium = 'Y')) " +
			"and (dp.islowglycemicindex = 'N' or (dp.islowglycemicindex = 'Y' and mi.islowglycemicindex = 'Y')) " +
			"and (dp.ishalal = 'N' or (dp.ishalal = 'Y' and mi.ishalal = 'Y')) " +
			"and (dp.iskosher = 'N' or (dp.iskosher = 'Y' and mi.iskosher = 'Y')) " +
			"and (dp.haspeanutallergy = 'N' or (dp.haspeanutallergy = 'Y' and mi.nopeanut = 'Y')) " +
			"and (dp.hasnutallergy = 'N' or (dp.hasnutallergy = 'Y' and mi.nonut = 'Y')) " +
			"and (dp.hasfishallergy = 'N' or (dp.hasfishallergy = 'Y' and mi.nofish = 'Y')) " +
			"and (dp.hasshellfishallergy = 'N' or (dp.hasshellfishallergy = 'Y' and mi.noshellfish = 'Y')) " +
			/*food preferences - cost, delivery vs. carryout vs. both*/
			"and fp.activeflag = 'Y' and (d2.dictionarycode = 'No Limit' or (d2.dictionarycode >= mi.cost)) " +
			"and ((r.delivery_option = 'Yes' and (d3.dictionarycode = 'Delivery' or d3.dictionarycode = 'Both')) " + 
			"or (r.delivery_option = 'No' and (d3.dictionarycode = 'Carry Out' or d3.dictionarycode = 'Both'))) " +
			/*menuitem - food type (entrees)*/
			"and mi.category in ('entree', 'soup', 'salad') " +
			/*foodcategorypreferences - food type (entrees)*/
			"and mifc.foodcategoryid in (select foodcategoryid from logoshealth.foodcategorypreference where answervalue = 'Y' and ";

	
	if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
	  && event.queryStringParameters.profileid !== "") {
		sql = sql + "profileid = " + event.queryStringParameters.profileid + ") and p.profileid = " + event.queryStringParameters.profileid + " ";
		if(event.queryStringParameters.recordid !== undefined) {
			if (event.queryStringParameters.iscategory == 'Y') {
				sql = sql + "and mifc.foodcategoryid = " + event.queryStringParameters.recordid + " ";
			} else {
				sql = sql + "and r.restaurantid = " + event.queryStringParameters.recordid + " ";
			}
		} else if (event.queryStringParameters.term !== undefined) {
			sql = sql + "and (instr(mi.name, '" + event.queryStringParameters.term + "') > 0 or instr(mi.description, '" + 
			event.queryStringParameters.term + "') > 0 or instr(mi.keywords, '" + event.queryStringParameters.term + "') > 0) ";
		} 

		sql = sql +  "group by r.restaurantid, r.restaurantname, r.address, r.city, r.phone, mi.menuitemid, mi.name, mi.description, mi.cost, mi.calories " +
		"order by RAND () limit 100"; 
	} else {
		skip = true;
		callback('Invalid query parameters', null);					
	}

	if (skip == false) {
	  console.log('SQL: ', sql);	
	  connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('OrderAMeal: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results !== null && results.length > 0) {
				console.log('OrderAMeal - Result length count: ' + results.length);

				for (var j = 0; j < results.length; j++) {				
					resultsItem = {
						'recordid':results[j].menuitemid,
						'name':results[j].name,
						'description':results[j].description,
						'cost':results[j].cost,
						'calories':results[j].calories,
						'totalfat':results[j].totalfat,
						'saturatedfat':results[j].saturatedfat,
						'transfat':results[j].transfat,
						'sodium':results[j].sodium,
						'carbs':results[j].carbs,
						'caloriesfromfat':results[j].caloriesfromfat,
						'protein':results[j].protein,
						'cholesterol':results[j].cholesterol,
						'dietaryfiber':results[j].dietaryfiber,
						'sugars':results[j].sugars,						
						'restaurantid':results[j].restaurantid,
						'restaurantname':results[j].restaurantname,
						'address':results[j].address,
						'city':results[j].city,
						'phone':results[j].phone,
						'image':results[j].photopath
					};
					populars.push(resultsItem);						
				}	

				closeConnection(connection); //all is done so releasing the resources	
				console.log('Final Results: ', populars)
				callback(null, populars);					
			} else {
				closeConnection(connection); //all is done so releasing the resources	
				callback('No data found', null);					
			}
		}
	  });
	}	
}	

function OrderAMealSave (event, callback) {
	var jsonObject = JSON.parse(event.body);
	var jsonObj2 = JSON.parse(jsonObject);
	var attCount = 0;
	var expectedCount = 0;
	var executedCount = 0;
	var sql;
	var skip = false;

	console.log('VaccinesByProfileSave: ', jsonObj2);
	if (jsonObj2.schedules !== null && jsonObj2.schedules.length > 0) {
		for (var i = 0; i < jsonObj2.schedules.length ; i++) {
			skip = false;
			sql = "Update logoshealth.vaccine_schedule set ";
			attCount = 0;
			if (jsonObj2.schedules[i].startdate !==undefined) {
				attCount = attCount + 1;
				sql = sql + "datereceived='" + jsonObj2.schedules[i].startdate +"', "
			}
			if (jsonObj2.schedules[i].physician !==undefined) {
				attCount = attCount + 1;
				sql = sql + "medicalcontacttext='" + jsonObj2.schedules[i].physician +"', "
			}
			if (attCount > 0){
				if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
					&& event.queryStringParameters.profileid !== "") {
					  sql = sql + "modifiedby = " + event.queryStringParameters.profileid + 
					  " where vaccine_scheduleid = " + jsonObj2.schedules[i].recordid;
					  expectedCount = expectedCount + 1;
					  //console.log('Set expected in loop - expected = ' + expectedCount + ' i = ' + i);
				} else {
					skip = true;
					callback('Invalid query parameters', null);					
				}
				if (!skip) {
					executeSQL(sql, function(err, response) {
						if (err) {
							callback(err, null);
						} else {
							executedCount = executedCount + 1;	
							if (executedCount == expectedCount) {
								callback(null, response);
							} else {
								console.log('I = ' + i + ' Expected: ' + expectedCount + ' Executed: ' + executedCount);
							}
						}
					});		
				}			
			}
		}

		skip = false;
		attCount = 0;
		sql = "Update logoshealth.vaccine set ";
		if (jsonObj2.active !==undefined) {
			attCount = attCount + 1;
			sql = sql + "activeflag='" + jsonObj2.active +"', "
		}
		if (jsonObj2.confirmed !==undefined) {
			attCount = attCount + 1;
			sql = sql + "confirmedflag='" + jsonObj2.confirmed +"', "
		}

		if (attCount > 0) {
			if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
				&& event.queryStringParameters.profileid !== "") {
				  sql = sql + "modifiedby = " + event.queryStringParameters.profileid + 
				  " where vaccineid = " + jsonObj2.recordid;
				  expectedCount = expectedCount + 1;
				  //console.log('Set expected Main record - expected = ' + expectedCount);
			} else {
				skip = true;
				callback('Invalid query parameters', null);					
			}
			if (!skip) {
				executeSQL(sql,  function(err, response) {
					if (err) {
						callback(err, null);
					} else {
						executedCount = executedCount + 1;	
						if (executedCount == expectedCount) {
							callback(null, response);
						} else {
							console.log('Main Record Expected: ' + expectedCount + ' Executed: ' + executedCount);
						}
				}
				});		
			}
		} else {
			if (executedCount == expectedCount) {
				callback(null, 'Success');
			}				
		}		

	} else {
		sql = "Update logoshealth.vaccine set ";
		if (jsonObj2.active !==undefined) {
			attCount = attCount + 1;
			sql = sql + "activeflag='" + jsonObj2.active +"', "
		}
		if (jsonObj2.confirmed !==undefined) {
			attCount = attCount + 1;
			sql = sql + "confirmedflag='" + jsonObj2.confirmed +"', "
		}
		if (jsonObj2.startdate !==undefined) {
			attCount = attCount + 1;
			sql = sql + "vaccinedate='" + jsonObj2.startdate +"', "
		}
		if (jsonObj2.physician !==undefined) {
			attCount = attCount + 1;
			sql = sql + "medicalcontacttext='" + jsonObj2.physician +"', "
		}
		if (attCount > 0) {
			if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
				&& event.queryStringParameters.profileid !== "") {
				  sql = sql + "modifiedby = " + event.queryStringParameters.profileid + 
				  " where vaccineid = " + jsonObj2.recordid;
				  expectedCount = expectedCount + 1;
			} else {
				skip = true;
				callback('Invalid query parameters', null);					
			}
			if (!skip) {
				executeSQL(sql,  function(err, response) {
					if (err) {
						callback(err, null);
					} else {
						callback(null, response);
					}
				});		
			}
		}
	}
}

function executeSQL (sql, callback) {
	var connection = new getLogosConnection();

	console.log('executeSQL: ' + sql);

	connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('executeSQL: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
			closeConnection(connection); //all is done so releasing the resources
			callback(null, 'Success');
		}
	  });		
}
