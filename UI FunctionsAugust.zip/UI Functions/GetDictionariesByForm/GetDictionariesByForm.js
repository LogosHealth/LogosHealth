'use strict';

var mysql = require('mysql');
var pool;

exports.handler = (event, context, callback) => {
	var bodyJson;
	console.log('event: ', event);
	//console.log('event method: ', event.httpMethod);
	//console.log('context: ', context);	

	pool = mysql.createPool({
		connectionLimit: 100,
		connectTimeout: 5000,
		acquireTimeout: 5000,
		multipleStatements: true,
		host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
		port      : '3306',
		user     : 'logosadmin', //yet to encrypt password and read from properties
		password : 'L0g0sH3alth', //yet to encrypt password and read from properties
		database: 'logoshealth',
		debug: false
	});    

  if (event.httpMethod == 'GET') { 
	console.log('GET method called');  
	GetDictionariesByForm (event, function(err, response) {
		if (err) {
			console.log('Error from GetDictionariesByForm: ' + err);
			bodyJson = JSON.stringify(err);
		} else {
			console.log('Results from GetDictionariesByForm: ' + response);
			bodyJson = JSON.stringify(response);
		}
		var responsePackage = {
			"statusCode": 200,
			"headers": {
				"GetDictionariesByForm": "Complete"
			},
			"body": bodyJson,
			"isBase64Encoded": false
		};
		closePool();	
		callback(null, responsePackage);
	});		
  } else {
	console.log('Wrong method called');  
	closePool();	
	callback('Wrong method called', null);	  
  }
}

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

//Feature 2: Finds profiles without GeoCoords -->  gets GeoCoords from Google Maps --> update GeoCoords 
//MM 02-07-2018 This function finds any restaurants without GeoCoords - cloned from findRestaurantsWithoutGeoCoords 
function GetDictionariesByForm (event, callback) {
	var connection = new getLogosConnection();
	var sql = "SELECT formname, fieldname, sortIndex, isparent FROM logoshealth.form2field ";

	var resultsItem;
	var populars = [];
	var skip = false;
		
	if(event.queryStringParameters !== undefined && event.queryStringParameters.formName !== undefined  
	  && event.queryStringParameters.formName !== "") {
		sql = sql + "where formname = '" + event.queryStringParameters.formName + "' and level = 1 order by sortIndex";
	} else {
		skip = true;
		callback('Invalid query parameters', null);					
	}

	if (skip == false) {
	  console.log('GetDictionariesByForm Retrieve SQL: ' + sql);	
	  connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('GetDictionariesByForm: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results !== null && results.length > 0) {
				console.log('GetDictionariesByForm - Result length count: ' + results.length);

				for (var j = 0; j < results.length; j++) {				
					resultsItem = {
						'formname':results[j].formname,
    					'fieldname':results[j].fieldname,
						'sortIndex':results[j].sortIndex,
						'isparent':results[j].isparent,
						'dictionary':[] 
					};
					populars.push(resultsItem);						
				}	
				closeConnection(connection);
				var dictionaryCount = populars.length;
				var dictionaryActual = 0;
				var forSpecificItem = false;
				var specificItemSplit;
				var specificItemField;
				var specificItemId;
				var SQLDictionary;

				if(event.queryStringParameters !== undefined && event.queryStringParameters.specificItem !== undefined  
					&& event.queryStringParameters.specificItem !== "") {
					forSpecificItem = true;
					specificItemSplit = event.queryStringParameters.specificItem.split('=');
					specificItemField = specificItemSplit[0];
					specificItemId = specificItemSplit[1];
				}
			
				for (var j = 0; j < populars.length; j++) {
					if (!forSpecificItem) {
						SQLDictionary = "SELECT dictionaryid, fieldname, value, dictionarycode, codeddictionary from logoshealth.dictionary where fieldname = '" + 
						  populars[j].fieldname + "' and defaultvalueflag = 'Y' order by dictionarycode";  	
					} else {
						if (populars[j].fieldname.toLowerCase() == specificItemField.toLowerCase()) {
							SQLDictionary = "SELECT dictionaryid, fieldname, value, dictionarycode, codeddictionary from logoshealth.dictionary where fieldname = '" + 
							populars[j].fieldname + "' and dictionaryid = " + specificItemId + " and defaultvalueflag = 'Y' order by dictionarycode";  	  
						} else {
							SQLDictionary = "SELECT dictionaryid, fieldname, value, dictionarycode, codeddictionary from logoshealth.dictionary where fieldname = '" + 
							  populars[j].fieldname + "' and defaultvalueflag = 'Y' order by dictionarycode";  		
						}
					}				

					console.log("SQLDictionary: " + SQLDictionary);
					var self = this;
					getDictionaryInfo(SQLDictionary, j, populars[j], function(error, results) {
						if (error) {
							console.log('GetDictionariesByForm: The Error is: ', error);
							callback(error, null);
						} else {
							populars[results.index].dictionary = results.dictionary;
							console.log("GetDictionariesByForm Results dictionary: ", results.dictionary); 
							//parentid = results.dictionary.recordid;
							console.log('GetDictionariesByForm - Get Dictionary: ' + results.index + ': ', populars[results.index].dictionary);								
							dictionaryActual = dictionaryActual + 1;
							console.log("Dictionary Actual: " + dictionaryActual);
							if (dictionaryActual == dictionaryCount) {
								callback(null, populars);												
							} else {
								console.log('Dictionary Total: ' + dictionaryCount + ', Dictionary Actual: ' + dictionaryActual);																								
							}
						}											  
					});
				}
			} else {
				closeConnection(connection); //all is done so releasing the resources
				callback('No data found', null);	
			}
		}
	  });
	}
}

function getDictionaryInfo (sql, index, objDict, callback) {
	var connection = new getLogosConnection();
	var dictionary = [];
	var returnObj = {
		'index':index,
		'dictionary':dictionary
	}
	var objDictionary;
	var childFieldSQL;
	var resultsItem;
	var children = [];

	console.log('getDictionaryInfo: ' + sql);
	console.log('getDictionaryInfo objDict: ', objDict);

	pool.getConnection(function(err, conn) {
		if (err) {
			console.log('getDictionaryInfo: ', err);
		} else {
			conn.query(sql, function (error, results, fields) {
				if (error) {
					console.log('getDictionaryInfo executeSQL: The Error is: ', error);
					conn.release();
					callback(error, null);
				} else {
					for (var k = 0; k < results.length; k++) {				
						if(objDict.isparent == 'Y') {
							objDictionary = {
								'recordid':results[k].dictionaryid,
								'fieldname':results[k].fieldname,
								'value':results[k].value,
								'dictionarycode':results[k].dictionarycode,
								'codeddictionary':results[k].codeddictionary,
								'dictionary':[]
							}	
						} else {
							objDictionary = {
								'recordid':results[k].dictionaryid,
								'fieldname':results[k].fieldname,
								'value':results[k].value,
								'dictionarycode':results[k].dictionarycode,
								'codeddictionary':results[k].codeddictionary,
							}	
						}
						dictionary.push(objDictionary);								
					}

					if (objDict.isparent == 'Y') {
						conn.release();

						childFieldSQL = "SELECT fieldname, sortIndex from logoshealth.form2field where formname = '" + objDict.formname +
						"' and level = 2 and childOf = '" + objDict.fieldname + "' order by sortIndex";

						connection.query(childFieldSQL, function (error, results, fields) {
							if (error) {
								console.log('GetDictionariesByForm - getDictionaryInfo find child fields: The Error is: ', error);
								closeConnection(connection); //all is done so releasing the resources
								callback(error, null);						
							} else {
								if (results !== null && results.length > 0) {
									for (var j = 0; j < results.length; j++) {				
										resultsItem = {
											'fieldname':results[j].fieldname,
											'sortIndex':results[j].sortIndex,
											'dictionary':[] 
										};
										children.push(resultsItem);	
									}	
									closeConnection(connection);

									var dictionaryCount = children.length;
									var dictionaryActual = 0;
									var childSQL;
									for (var j = 0; j < children.length; j++) {
										childSQL = "SELECT dictionaryL2id, dictionaryid, fieldname, dictionarycode, defaultSelection from logoshealth.dictionaryL2 where fieldname = '" + 
										children[j].fieldname + "' and dictionaryid in (";
										for (var y = 0; y < dictionary.length; y++) {											
											if (y == dictionary.length -1) {
												childSQL = childSQL + dictionary[y].recordid + ") order by dictionaryid, defaultselection desc, dictionarycode "; 
											} else {
												childSQL = childSQL + dictionary[y].recordid + ", "; 
											} 	
										}
										var self = this;										
										getDictionaryChild(childSQL, j, dictionary, function(error, results) {
											if (error) {
												console.log('getDictionaryInfo - call to getDictionaryChild: The Error is: ', error);
												callback(error, returnObj);
											} else {
												//dictionary[results.index1].dictionary[results.index2] = results.dictionary;
												dictionaryActual = dictionaryActual + 1;
												if (dictionaryActual == dictionaryCount) {
													returnObj.dictionary = results;
													callback(null, returnObj);												
												} else {
													console.log('getDictionaryChild Dictionary Total: ' + dictionaryCount + ', Dictionary Actual: ' + dictionaryActual);																								
												}
											}	
										});																				
									}
								} else {
									returnObj.dictionary = dictionary;	
									console.log('getDictionaryInfo Final Return Obj - isParent but no children found: ', returnObj);				
									closeConnection(connection);
									callback(null, returnObj);				
								}		
							}	
						});								
					} else {
						returnObj.dictionary = dictionary;	
						console.log('getDictionaryInfo Final Return Obj: ', returnObj)				
						conn.release();
						callback(null, returnObj);
					}
				}
			});	
		}
	});
}

function getDictionaryChild (sql, index1, parentDictionary, callback) {
	var dictionary = [];

	console.log('getDictionaryChild: ' + sql);
	pool.getConnection(function(err, conn) {
		if (err) {
			console.log('getDictionaryChild: ', err);
			callback(err, null);
		} else {
			conn.query(sql, function (error, results, fields) {
				if (error) {
					console.log('getDictionaryChild executeSQL: The Error is: ', error);
					conn.release();
					callback(error, null);
				} else {
					for (var k = 0; k < results.length; k++) {				
						var objDictionary = {
							'recordid':results[k].dictionaryL2id,
							//'dictionaryid':results[k].dictionaryid,
							'fieldname':results[k].fieldname,
							'dictionarycode':results[k].dictionarycode,
							'defaultSelection':results[k].defaultSelection 
						}
						for (var l = 0; l < parentDictionary.length; l++) {
							if (parentDictionary[l].recordid == results[k].dictionaryid) {
								dictionary.push(objDictionary);
								parentDictionary[l].dictionary.push(objDictionary);
							}
						}
						//console.log('Child Dictionary Array: ', dictionary);
					}	
					console.log('getDictionaryChild Final Return Obj: ', parentDictionary)				
					conn.release();
					callback(null, parentDictionary);
				}
			});	
		}
	});
}

function closePool() {
	pool.end();
}
