'use strict';

var mysql = require('mysql');
var moment = require('moment-timezone');
var timezone = "";

exports.handler = (event, context, callback) => {
	var bodyJson;
	console.log('event: ', event);
	console.log('context: ', context);	
	if (event.httpMethod == 'GET') { 
		console.log('GET method called');  
		EventByProfile (event, function(err, response) {
			if (err) {
				console.log('Error from EventByProfile: ' + err);
				bodyJson = JSON.stringify(err);
			} else {
				console.log('Results from EventByProfile: ' + response);
				bodyJson = JSON.stringify(response);
			}
			var responsePackage = {
				"statusCode": 200,
				"headers": {
					"EventByProfile": "Complete"
				},
				"body": bodyJson,
				"isBase64Encoded": false
			};
			callback(null, responsePackage);
		});		
	  } else if (event.httpMethod == 'POST') {
		console.log('POST method called');  
		EventByProfileSave (event, function(err, response) {
			if (err) {
				console.log('Error from EventByProfileSave: ' + err);
				bodyJson = JSON.stringify(err);
			} else {
				console.log('Results from EventByProfileSave: ' + response);
				bodyJson = JSON.stringify(response);
			}
			var responsePackage = {
				"statusCode": 200,
				"headers": {
					"EventByProfile": "Complete"
				},
				"body": bodyJson,
				"isBase64Encoded": false
			};
			callback(null, responsePackage);
		});		
	  } else {
		console.log('Wrong method called');  
		callback('Wrong method called', null);  
	  }	
}

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

//Feature 2: Finds profiles without GeoCoords -->  gets GeoCoords from Google Maps --> update GeoCoords 
//MM 02-07-2018 This function finds any restaurants without GeoCoords - cloned from findRestaurantsWithoutGeoCoords 
function EventByProfile (event, callback) {
	var connection = new getLogosConnection();
	var sql = "SELECT medicaleventid, medicalevent, eventdescription, parenteventid, startdate, enddate, duration, " + 
	"continuing, recurring, medicallyconfirmed, visitid, activeflag, physicianid, profileid, confirmedflag FROM logoshealth.medicalevent where activeflag = 'Y'";
	var resultsItem;
	var populars = [];
	var skip = false;
	
	if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
	  && event.queryStringParameters.profileid !== "") {
		sql = sql + " and profileid = " + event.queryStringParameters.profileid + " order by startdate desc, medicaleventid desc";
	} else if (event.queryStringParameters !== undefined && event.queryStringParameters.eventid !== undefined  
		&& event.queryStringParameters.eventid !== "") {
			sql = sql + " and parenteventid = " + event.queryStringParameters.eventid + " order by startdate desc, medicaleventid desc";
	} else {
		skip = true;
		callback('Invalid query parameters', null);					
	}

	if (skip == false) {
	  console.log('Final SQL: ', sql);
	  connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('EventByProfile: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results !== null && results.length > 0) {
				console.log('EventByProfile - Result length count: ' + results.length);
                for (var j = 0; j < results.length; j++) {				
					resultsItem = {
						'recordid':results[j].medicaleventid,
 						'medicaleventid':results[j].medicaleventid,
 						'medicalevent':results[j].medicalevent,
 						'eventdescription':results[j].eventdescription,
						'parenteventid':results[j].parenteventid,
						'startdate':results[j].startdate,
						'enddate':results[j].enddate,
						'duration':results[j].duration,
						'continuing':results[j].continuing,
						'recurring':results[j].recurring,
						'medicallyconfirmed':results[j].medicallyconfirmed,
						'visitid':results[j].visitid,
						'activeflag':results[j].activeflag,
						'physicianid':results[j].physicianid,
						'profileid':results[j].profileid,
						'confirmedflag':results[j].confirmedflag
					};
					populars.push(resultsItem);				
				}	
				closeConnection(connection); //all is done so releasing the resources	
				callback(null, populars);					
			} else {
				closeConnection(connection); //all is done so releasing the resources	
				callback('No data found', null);					
			}
		}
	  });
	}	
}	

function EventByProfileSave (event, callback) {
	var connection = new getLogosConnection();

	var jsonObject = JSON.parse(event.body);
	var jsonObj2 = JSON.parse(jsonObject);
	var blnInactivate = false;
	var blnNewRecord = false;
	var sql;
	var sql1;
	var sql2;
	var blnSkip = false;
	var dtNow = new Date();
	var dtSave = moment(dtNow);
	
	console.log('EventByProfileSave: ', jsonObj2);
	if (jsonObj2.timezone !==undefined && jsonObj2.timezone !=="") {
		timezone = jsonObj2.timezone;
	}	
	
	if (jsonObj2.active !==undefined && jsonObj2.active !=="") {
		if (jsonObj2.active == "N") {
			blnInactivate = true;
		} else if (jsonObj2.recordid == undefined || jsonObj2.recordid == null || jsonObj2.recordid == "") {
			console.log('EventByProfileSave - Insert record expect recordid = ' + jsonObj2.recordid);
			blnNewRecord = true;
		}
	} else {
		callback('Invalid data', null);
		blnSkip = true;	
	}

	if (blnInactivate) {
		sql = "Update logoshealth.sleep set activeflag = 'N', modifiedby = " + jsonObj2.userid + " where sleepid = " + jsonObj2.recordid;
	} else if (blnNewRecord) {
		sql1 = "Insert into logoshealth.sleep (";
		sql2 = "values (";

		if (jsonObj2.hoursslept !==undefined) {
			sql1 = sql1 + "hoursslept, "
			sql2 = sql2 + jsonObj2.hoursslept + ", ";
		}
		if (jsonObj2.starttime !==undefined) {
			sql1 = sql1 + "starttime, "
			sql2 = sql2 + "'" + jsonObj2.starttime + "', ";
		}
		if (jsonObj2.waketime !==undefined) {
			sql1 = sql1 + "waketime, "
			sql2 = sql2 + "'" + jsonObj2.waketime + "', ";
		}
		if (jsonObj2.dateofmeasure !==undefined) {
			sql1 = sql1 + "dateofmeasure, "
			var dtDET = moment(jsonObj2.dateofmeasure);
			sql2 = sql2 + "'" + dtDET.format("YYYY-MM-DD HH:mm") + "', ";
			sql1 = sql1 + "profileid, createdby, modifiedby) ";
			sql2 = sql2 + jsonObj2.profileid + ", " + jsonObj2.userid + ", " + 
			  jsonObj2.userid + ")";
			sql = sql1 + sql2;  
		} else if (jsonObj2.profileid !==undefined && jsonObj2.userid !==undefined) {
			sql1 = sql1 + "profileid, createdby, modifiedby, dateofmeasure) ";
			sql2 = sql2 + jsonObj2.profileid + ", " + jsonObj2.userid + ", " + 
			  jsonObj2.userid + ", '"+  dtSave.utc().format("YYYY-MM-DD HH:mm") + "')";
			sql = sql1 + sql2;			
		} else {
			callback('Invalid data', null);	
			blnSkip = true;	
		}
	} else {
		sql = "update logoshealth.sleep set ";
		if (jsonObj2.hoursslept !==undefined) {
			sql = sql +  "hoursslept = " + jsonObj2.hoursslept + ", ";
		}
		if (jsonObj2.starttime !==undefined) {
			sql = sql + "starttime = '" + jsonObj2.starttime + "', ";
		}
		if (jsonObj2.waketime !==undefined) {
			sql = sql + "waketime = '" + jsonObj2.waketime + "', ";
		}

		if (jsonObj2.userid !==undefined && jsonObj2.recordid !==undefined) {
			sql = sql + "modifiedby = " + jsonObj2.userid + " where sleepid = " + jsonObj2.recordid;
		} else {
			callback('Invalid data', null);	
			blnSkip = true;	
		}
	}

	if (!blnSkip) {
		console.log('SleepByProfileSave - Final SQL: ' + sql);
		connection.query(sql,  function (err, results, fields) {
			if (err) {
				closeConnection(connection); //all is done so releasing the resources	
				callback(err, null);
			} else {
				closeConnection(connection); //all is done so releasing the resources
				callback(null, "Success");
			}
		});			
	} else {
		console.log('Skipped');
	}
}
