'use strict';

var mysql = require('mysql');
var moment = require('moment-timezone');
var timezone = "";

exports.handler = (event, context, callback) => {
	var bodyJson;
	console.log('event: ', event);
	console.log('context: ', context);	
	if (event.httpMethod == 'GET') { 
		console.log('GET method called');  
		WeightByProfile (event, function(err, response) {
			if (err) {
				console.log('Error from WeightByProfile: ' + err);
				bodyJson = JSON.stringify(err);
			} else {
				console.log('Results from WeightByProfile: ' + response);
				bodyJson = JSON.stringify(response);
			}
			var responsePackage = {
				"statusCode": 200,
				"headers": {
					"WeightByProfile": "Complete"
				},
				"body": bodyJson,
				"isBase64Encoded": false
			};
			callback(null, responsePackage);
		});		
	  } else if (event.httpMethod == 'POST') {
		console.log('POST method called');  
		WeightByProfileSave (event, function(err, response) {
			if (err) {
				console.log('Error from WeightByProfileSave: ' + err);
				bodyJson = JSON.stringify(err);
			} else {
				console.log('Results from WeightByProfileSave: ' + response);
				bodyJson = JSON.stringify(response);
			}
			var responsePackage = {
				"statusCode": 200,
				"headers": {
					"WeightByProfile": "Complete"
				},
				"body": bodyJson,
				"isBase64Encoded": false
			};
			callback(null, responsePackage);
		});		
	  } else {
		console.log('Wrong method called');  
		callback('Wrong method called', null);  
	  }	
}

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

//Feature 2: Finds profiles without GeoCoords -->  gets GeoCoords from Google Maps --> update GeoCoords 
//MM 02-07-2018 This function finds any restaurants without GeoCoords - cloned from findRestaurantsWithoutGeoCoords 
function WeightByProfile (event, callback) {
	var connection = new getLogosConnection();
	var sql = "SELECT weightid, profileid, weight, unitofmeasure, dateofmeasure, confirmedflag, activeflag " + 
	"FROM logoshealth.weight where activeflag = 'Y'";
	var resultsItem;
	var populars = [];
	var skip = false;
	
	if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
	  && event.queryStringParameters.profileid !== "") {
		sql = sql + " and profileid = " + event.queryStringParameters.profileid + " order by weightid desc";
	} else {
		skip = true;
		callback('Invalid query parameters', null);					
	}

	if (skip == false) {
	  connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('WeightByProfile: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results !== null && results.length > 0) {
				console.log('WeightByProfile - Result length count: ' + results.length);
                for (var j = 0; j < results.length; j++) {				
					resultsItem = {
						'recordid':results[j].weightid,
 						'weight':results[j].weight,
 						'unitofmeasure':results[j].unitofmeasure,
 						'confirmed':results[j].confirmedflag,
						'dateofmeasure':results[j].dateofmeasure,
						'active':results[j].activeflag,
						'profileid':results[j].profileid
					};
					populars.push(resultsItem);
				}	
				closeConnection(connection); //all is done so releasing the resources	
				callback(null, populars);					
			} else {
				closeConnection(connection); //all is done so releasing the resources	
				callback('No data found', null);					
			}
		}
	  });
	}	
}	

function WeightByProfileSave (event, callback) {
	var connection = new getLogosConnection();

	var jsonObject = JSON.parse(event.body);
	var jsonObj2 = JSON.parse(jsonObject);
	var blnInactivate = false;
	var blnNewRecord = false;
	var sql;
	var sql1;
	var sql2;
	var blnSkip = false;
	var dtNow = new Date();
	var dtSave = moment(dtNow);
	
	console.log('WeightByProfileSave: ', jsonObj2);
	if (jsonObj2.timezone !==undefined && jsonObj2.timezone !=="") {
		timezone = jsonObj2.timezone;
	}	
	
	if (jsonObj2.active !==undefined && jsonObj2.active !=="") {
		if (jsonObj2.active == "N") {
			blnInactivate = true;
		} else if (jsonObj2.recordid == undefined || jsonObj2.recordid == null || jsonObj2.recordid == "") {
			console.log('WeightByProfileSave - Insert record expect recordid = ' + jsonObj2.recordid);
			blnNewRecord = true;
		}
	} else {
		callback('Invalid data', null);
		blnSkip = true;	
	}

	if (blnInactivate) {
		sql = "Update logoshealth.weight set activeflag = 'N', modifiedby = " + jsonObj2.userid + " where weightid = " + jsonObj2.recordid;
	} else if (blnNewRecord) {
		sql1 = "Insert into logoshealth.weight (";
		sql2 = "values (";

		if (jsonObj2.weight !==undefined) {
			sql1 = sql1 + "weight, "
			sql2 = sql2 + jsonObj2.weight + ", ";
		}
		if (jsonObj2.unitofmeasure !==undefined) {
			sql1 = sql1 + "unitofmeasure, "
			sql2 = sql2 + "'" + jsonObj2.unitofmeasure + "', ";
		}
		if (jsonObj2.profileid !==undefined && jsonObj2.userid !==undefined) {
			sql1 = sql1 + "profileid, createdby, modifiedby, dateofmeasure) ";
			sql2 = sql2 + jsonObj2.profileid + ", " + jsonObj2.userid + ", " + 
			  jsonObj2.userid + ", '"+  dtSave.format("YYYY-MM-DD HH:mm") + "')";
			sql = sql1 + sql2;			
		} else {
			callback('Invalid data', null);	
			blnSkip = true;	
		}
	} else {		
		sql = "update logoshealth.weight set ";
		if (jsonObj2.weight !==undefined) {
			sql = sql + "weight = "+ jsonObj2.weight + ", ";
		}
		if (jsonObj2.unitofmeasure !==undefined) {
			sql = sql + "unitofmeasure = " + "'" + jsonObj2.unitofmeasure + "', ";
		}
		if (jsonObj2.userid !==undefined && jsonObj2.recordid !==undefined) {
			sql = sql + "modifiedby = " + jsonObj2.userid + " where weightid = " + jsonObj2.recordid;
		} else {
			callback('Invalid data', null);	
			blnSkip = true;	
		}
	}

	if (!blnSkip) {
		console.log('WeightByProfileSave - Final SQL: ' + sql);
		connection.query(sql,  function (err, results, fields) {
			if (err) {
				closeConnection(connection); //all is done so releasing the resources	
				callback(err, null);
			} else {
				closeConnection(connection); //all is done so releasing the resources
				callback("Success", null);
			}
		});			
	} else {
		console.log('Skipped');
	}
}
