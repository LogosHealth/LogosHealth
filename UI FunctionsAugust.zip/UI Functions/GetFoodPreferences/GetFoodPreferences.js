'use strict';

var mysql = require('mysql');
var pool;

exports.handler = (event, context, callback) => {
	var bodyJson;
	console.log('event: ', event);
	console.log('context: ', context);	

	pool = mysql.createPool({
		connectionLimit: 100,
		connectTimeout: 5000,
		acquireTimeout: 5000,
		multipleStatements: true,
		host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
		port      : '3306',
		user     : 'logosadmin', //yet to encrypt password and read from properties
		password : 'L0g0sH3alth', //yet to encrypt password and read from properties
		database: 'logoshealth',
		debug: false
	});    
	
	if (event.httpMethod == 'GET') { 
		GetFoodPreferences (event, function(err, response) {
			if (err) {
				console.log('Error from GetFoodPreferences: ' + err);
				bodyJson = JSON.stringify(err);
			} else {
				console.log('Results from GetFoodPreferences: ', response);
				bodyJson = JSON.stringify(response);
			}
			var responsePackage = {
				"statusCode": 200,
				"headers": {
					"GetFoodPreferences": "Complete"
				},
				"body": bodyJson,
				"isBase64Encoded": false
			};
			closePool();	
			callback(null, responsePackage);
		});
	} else if (event.httpMethod == 'POST') {
		GetFoodPreferencesSave (event, function(err, response) {
			if (err) {
				console.log('Error from GetFoodPreferencesSave: ' + err);
				bodyJson = JSON.stringify(err);
			} else {
				console.log('Results from GetFoodPreferencesSave: ', response);
				bodyJson = JSON.stringify(response);
			}
			var responsePackage = {
				"statusCode": 200,
				"headers": {
					"GetFoodPreferences": "Complete"
				},
				"body": bodyJson,
				"isBase64Encoded": false
			};
			closePool();	
			callback(null, responsePackage);
		});
	} else {
	console.log('Wrong method called');  
	closePool();	
	callback('Wrong method called', null);  
  }			
}

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

function closePool() {
	pool.end();
}

//MM 06-13-2018 This function aggregates food preferences, diet preferences, and foodcategory preferences 
function GetFoodPreferences (event, callback) {
	var results;
	var doneCount = 0;
	var resultsItem = {};
	var categoryPreference = [];
	var resultsArray = [];
	var profileID;
	var skip;
	
	if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
		&& event.queryStringParameters.profileid !== "") {

		  profileID = event.queryStringParameters.profileid;

		  getFoodPreferences (profileID, function(err, response) {
			if (err) {
				console.log('getFoodPreferences: ' + err);
				callback(err, null);							
			} else {
				resultsItem["foodpreferenceid"] = response[0].foodpreferenceid;
				resultsItem["maxcost"] = response[0].maxcost;
				resultsItem["deliveryrange"] = response[0].deliveryrange;
				resultsItem["deliveryoption"] = response[0].deliveryoption;
				resultsItem["familyfood"] = response[0].familyfood;
			}
			doneCount++;
			if (resultsItem["dietpreferenceid"] !== undefined) {
				resultsArray.push(resultsItem);
				console.log('Complete - getFoodPreferences - DoneCount Main = ' + doneCount);
			} else {
				console.log('Food done first');
			}
			if 	(doneCount === 3) {
				callback(null, resultsArray);
			}

		});		

		getDietPreferences (profileID, function(err, response) {
			if (err) {
				console.log('getDietPreferences: ' + err);			
				callback(err, null);							
			} else {
				resultsItem["dietpreferenceid"] = response[0].dietpreferenceid;
				resultsItem["calorielimit"] = response[0].calorielimit;
				resultsItem["mealsperentreevalue"] = response[0].mealsperentreevalue;
				resultsItem["iswhitemeat"] = response[0].iswhitemeat;
				resultsItem["ischicken"] = response[0].ischicken;
				resultsItem["isvegetarian"] = response[0].isvegetarian;
				resultsItem["isvegetariannoegg"] = response[0].isvegetariannoegg;
				resultsItem["isvegan"] = response[0].isvegan;
				resultsItem["ispescatarian"] = response[0].ispescatarian;
				resultsItem["isavoiddairy"] = response[0].isavoiddairy;
				resultsItem["isglutenfree"] = response[0].isglutenfree;
				resultsItem["islowcarb"] = response[0].islowcarb;
				resultsItem["ishearthealthy"] = response[0].ishearthealthy;
				resultsItem["islowsodium"] = response[0].islowsodium;
				resultsItem["islowglycemicindex"] = response[0].islowglycemicindex;
				resultsItem["ishalal"] = response[0].ishalal;
				resultsItem["iskosher"] = response[0].iskosher;
				resultsItem["haspeanutallergy"] = response[0].haspeanutallergy;
				resultsItem["hasnutallergy"] = response[0].hasnutallergy;
				resultsItem["hasfishallergy"] = response[0].hasfishallergy;
				resultsItem["hasshellfishallergy"] = response[0].hasshellfishallergy;
				resultsItem["familydiet"] = response[0].familydiet;
			}
			doneCount++;
			if (resultsItem["foodpreferenceid"] !== undefined) {
				resultsArray.push(resultsItem);
				console.log('Complete - getDietPreferences - DoneCount Main = ' + doneCount);
			} else {
				console.log("Diet done first");
			}
			if 	(doneCount === 3) {	
				callback(null, resultsArray);
			}
		});	
		
		var input = {
			profileID: profileID,
			retry: "No"
		}
		getCategoryPreferences (input, function(err, response) {
			if (err) {
				console.log('getCategoryPreferences: ' + err);			
				callback(err, null);							
			} else {
				console.log('getCategoryPreferences: ', response);
				categoryPreference = response;
				resultsArray.push(categoryPreference);
			}
			doneCount++;
			if 	(doneCount === 3) {
				callback(null, resultsArray);
			}
		});		
	} else {
		skip = true;
		callback('Invalid query parameters', null);					
	}
}

function getFoodPreferences (results, callback) {

	var connection = new getLogosConnection();
	var sql = "SELECT fp.foodpreferenceid, d1.dictionarycode as maxcost, d2.dictionarycode as deliveryrange, d3.dictionarycode as deliveryoption, fp.forfamily as familyfood " +
		"from logoshealth.foodpreference fp, logoshealth.dictionary d1, logoshealth.dictionary d2, logoshealth.dictionary d3 " +
		"where fp.activeflag = 'Y' and d1.dictionaryid = fp.maxcost and d2.dictionaryid = fp.deliveryrange and d3.dictionaryid = fp.deliveryoption " + 
		"and fp.activeflag = 'Y'";
	var resultsItem;
	var populars = [];
	var skip = false;
	
	sql = sql + " and profileid = " + results;
	var intResultID = results;

	console.log('getFoodPreferences - SQL: ' + sql);	
	connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('getFoodPreferences: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results !== null && results.length > 0) {
				console.log('getFoodPreferences - Result length count: ' + results.length);
                for (var j = 0; j < results.length; j++) {				
					resultsItem = {
						'foodpreferenceid':results[j].foodpreferenceid,
    					'maxcost':results[j].maxcost,
						'deliveryrange':results[j].deliveryrange,
						'deliveryoption':results[j].deliveryoption,
						'familyfood':results[j].familyfood
					};
					populars.push(resultsItem);
				}	
				closeConnection(connection); //all is done so releasing the resources	
				callback(null, populars);					
			} else {
				sql = "Insert into logoshealth.foodpreference (profileid, accountid, activeflag, createdby, modifiedby) values (" +
				intResultID + ", (select accountid from logoshealth.profile where profileid = " + intResultID + "), 'Y', " + intResultID +
				', ' + intResultID + ")" ;
				console.log('Insert Diet SQL - ' + sql);
				connection.query(sql, function (error, results, fields) {
					if (error) {
						console.log('getFoodPreferences Insert: The Error is: ', error);
						closeConnection(connection); //all is done so releasing the resources
						callback(error, null);
					} else {
						console.log('getFoodPreferences - Insert: ' + results.insertId);
						resultsItem = {
							'foodpreferenceid':results.insertId,
							'maxcost':"",
							'deliveryrange':"",
							'deliveryoption':"",
							'familyfood':"N"
						};
						populars.push(resultsItem);
						closeConnection(connection); //all is done so releasing the resources	
						callback(null, populars);					
					}	
				});
			}
		}	
	});
}	

function getDietPreferences (results, callback) {

	var connection = new getLogosConnection();
	var sql = "SELECT dp.dietpreferenceid, if(dp.targetcaloriesvalue = 1000000, 'No Limit', dp.targetcaloriesvalue) as calorielimit, " +
	"dp.mealsperentreevalue, dp.iswhitemeat, dp.ischicken, dp.isvegetarian, dp.isvegetariannoegg, dp.isvegan, dp.ispescatarian, " +
	"dp.isavoiddairy, dp.isglutenfree, dp.islowcarb, dp.ishearthealthy, dp.islowsodium, dp.islowglycemicindex, dp.ishalal, " +
	"dp.iskosher, dp.haspeanutallergy, dp.hasnutallergy, dp.hasfishallergy, dp.hasshellfishallergy, dp.forfamily as familydiet " +
	"FROM logoshealth.dietpreference dp where dp.activeflag = 'Y'";
	var resultsItem;
	var populars = [];
	var skip = false;
	
	sql = sql + " and profileid = " + results;
	var intResultID = results;

	console.log('getDietPreferences - SQL: ' + sql);	
	connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('getDietPreferences: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results !== null && results.length > 0) {
				console.log('getDietPreferences - Result length count: ' + results.length);
                for (var j = 0; j < results.length; j++) {				
					resultsItem = {
						'dietpreferenceid':results[j].dietpreferenceid,
    					'calorielimit':results[j].calorielimit,
						'mealsperentreevalue':results[j].mealsperentreevalue,
						'iswhitemeat':results[j].iswhitemeat,
						'ischicken':results[j].ischicken,
						'isvegetarian':results[j].isvegetarian,
						'isvegetariannoegg':results[j].isvegetariannoegg,
						'isvegan':results[j].isvegan,
						'ispescatarian':results[j].ispescatarian,
						'isavoiddairy':results[j].isavoiddairy,
						'isglutenfree':results[j].isglutenfree,
						'islowcarb':results[j].islowcarb,
						'ishearthealthy':results[j].ishearthealthy,
						'islowsodium':results[j].islowsodium,
						'islowglycemicindex':results[j].islowglycemicindex,
						'ishalal':results[j].ishalal,
						'iskosher':results[j].iskosher,
						'haspeanutallergy':results[j].haspeanutallergy,
						'hasnutallergy':results[j].hasnutallergy,
						'hasfishallergy':results[j].hasfishallergy,
						'hasshellfishallergy':results[j].hasshellfishallergy,
						'familydiet':results[j].familydiet
					};
					populars.push(resultsItem);
				}	
				closeConnection(connection); //all is done so releasing the resources	
				callback(null, populars);					
			} else {
				sql = "Insert into logoshealth.dietpreference (profileid, accountid, activeflag, createdby, modifiedby) values (" +
				intResultID + ", (select accountid from logoshealth.profile where profileid = " + intResultID + "), 'Y', " + intResultID +
				', ' + intResultID + ")" ;
				console.log('Insert Diet SQL - ' + sql);
				connection.query(sql, function (error, results, fields) {
					if (error) {
						console.log('getDietPreferences Insert: The Error is: ', error);
						closeConnection(connection); //all is done so releasing the resources
						callback(error, null);
					} else {
						console.log('getDietPreferences - Insert: ' + results.insertId);
						resultsItem = {
							'dietpreferenceid':results.insertId,
							'calorielimit':"",
							'mealsperentreevalue':"1",
							'iswhitemeat':"N",
							'ischicken':"N",
							'isvegetarian':"N",
							'isvegetariannoegg':"N",
							'isvegan':"N",
							'ispescatarian':"N",
							'isavoiddairy':"N",
							'isglutenfree':"N",
							'islowcarb':"N",
							'ishearthealthy':"N",
							'islowsodium':"N",
							'islowglycemicindex':"N",
							'ishalal':"N",
							'iskosher':"N",
							'haspeanutallergy':"",
							'hasnutallergy':"",
							'hasfishallergy':"",
							'hasshellfishallergy':"",
							'familydiet':"N"
						};
						populars.push(resultsItem);
						closeConnection(connection); //all is done so releasing the resources	
						callback(null, populars);					
					}	
				});
			}
		}	
	});
}	

function getCategoryPreferences (results, callback) {
	var connection = new getLogosConnection();
	var sql = "select fcp.foodcategorypreferenceid, fcp.categoryname, fcp.ismaster, fc.master_category, fcp.answervalue from logoshealth.foodcategorypreference fcp, " +
	"logoshealth.foodcategory fc where fcp.foodcategoryid = fc.foodcategoryid ";	
	var resultsItem;
	var populars = [];
	var insertCount = 0;

	sql = sql + "and fcp.profileid = " + results.profileID + " order by fc.master_category, fcp.ismaster desc, fcp.categoryname";
	var intResultID = results.profileID;
	var varRetry = results.retry;

	console.log('getCategoryPreferences - SQL: ' + sql);	
	connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('getCategoryPreferences: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results !== null && results.length > 0) {
				console.log('getCategoryPreferences - Result length count: ' + results.length);
                for (var j = 0; j < results.length; j++) {				
					resultsItem = {
						'foodcategorypreferenceid':results[j].foodcategorypreferenceid,
    					'categoryname':results[j].categoryname,
						'ismaster':results[j].ismaster,
						'master_category':results[j].master_category,
						'answervalue':results[j].answervalue
					};
					populars.push(resultsItem);
				}	
				closeConnection(connection); //all is done so releasing the resources	
				callback(null, populars);					
			} else {
				console.log('Results.retry: ' + varRetry);
				if (varRetry == "No") {
					var categories = ['American', 'Asian', 'Latin American', 'Mediterranean and European', 'zOther'];
					for (var j = 0; j < categories.length; j++) {				
						sql = "INSERT INTO logoshealth.foodcategorypreference (foodcategoryid, profileid, accountid,  ismaster, answer, createdby, modifiedby) " + 
						"(SELECT foodcategoryid, " + intResultID + ", (SELECT accountid from logoshealth.profile where profileid = " + intResultID + 
						"), 'N', 172, " + intResultID + ", " + intResultID + " FROM logoshealth.foodcategory WHERE master_category = '" + categories[j] + "')";
						console.log('Insert Category SQL - ' + sql);						
						connection.query(sql, function (error, results, fields) {
							if (error) {
								console.log('getCategoryPreferences Insert: The Error is: ', error);
								closeConnection(connection); //all is done so releasing the resources
								callback(error, null);
							} else {
								insertCount = insertCount + 1;
								if (insertCount == categories.length) {
									closeConnection(connection); //all is done so releasing the resources
									var input = {
										profileID: intResultID,
										retry: "Yes"
									}
									getCategoryPreferences(input, callback); 			
								}
							}	
						});
								
					};

				} else {
					closeConnection(connection); //all is done so releasing the resources	
					callback('Food Category Failed', null);
				}


			}
		}	
	});
}	

function GetFoodPreferencesSave (event, callback) {
	var jsonObject = JSON.parse(event.body);
	var jsonObj2 = JSON.parse(jsonObject);
	var dietSQL;
	var dietWhere;
	var foodSQL;
	var foodWhere;	
	var profileID;
	var skip = false;
	var updateExpected = 0;
	var updateActual = 0;

	
	console.log('getFoodPreferencesSave: ', jsonObj2);
	console.log('getFoodPreferencesSave Items: ', jsonObj2.categories.items);

	if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
		&& event.queryStringParameters.profileid !== "") {
			profileID  = event.queryStringParameters.profileid;
	} else {
		skip = true;
		callback('Invalid query parameters', null);					
	}

	if (!skip) {
		//MM - 6-22-18 Get the expected number of record updates for this JSON pkg.  Will use the expected number to compare to the actual for successful callback
		if (jsonObj2.dietpreferenceid !== undefined && jsonObj2.dietpreferenceid > 0) {
			updateExpected = updateExpected + 1;
			console.log('Diet Preference - add count 1' + " total: " + updateExpected);
		}	
		if (jsonObj2.foodpreferenceid !== undefined && jsonObj2.foodpreferenceid > 0) {
			updateExpected = updateExpected + 1;
			console.log('Food Preference - add count 1' + " total: " + updateExpected);
		}
		if (jsonObj2.categories.items.length > 0) {
			updateExpected = updateExpected + jsonObj2.categories.items.length; 
			console.log('Food Categories - add count: ' + jsonObj2.categories.items.length + " total: " + updateExpected);
		}	

		if (jsonObj2.dietpreferenceid !== undefined) {
			console.log('Diet Preference Save');
			dietWhere = "WHERE dietpreferenceid = " + jsonObj2.dietpreferenceid;
			dietSQL = "UPDATE logoshealth.dietpreference SET ";

			if (jsonObj2.calorielimit !== undefined) {
				dietSQL =  dietSQL + "calories = (SELECT dictionaryid from logoshealth.dictionary where fieldname = 'calories' and value = '" + jsonObj2.calorielimit + "'), ";
			} 
			if (jsonObj2.mealsperentreevalue !== undefined) {
				dietSQL =  dietSQL + "mealsperentree = (SELECT dictionaryid from logoshealth.dictionary where fieldname = 'mealsperentree' and value = '" + 
				  jsonObj2.mealsperentreevalue + "'), ";
			} 
			if (jsonObj2.iswhitemeat !== undefined) {
				if (jsonObj2.iswhitemeat == true) {
					dietSQL =  dietSQL + "iswhitemeat = 'Y', ";		
				} else if (jsonObj2.iswhitemeat == false) {
					dietSQL =  dietSQL + "iswhitemeat = 'N', ";		
				}
			} 
			if (jsonObj2.ischicken !== undefined) {
				if (jsonObj2.ischicken == true) {
					dietSQL =  dietSQL + "ischicken = 'Y', ";		
				} else if (jsonObj2.ischicken == false) {
					dietSQL =  dietSQL + "ischicken = 'N', ";		
				}
			} 
			if (jsonObj2.isvegetarian !== undefined) {
				if (jsonObj2.isvegetarian == true) {
					dietSQL =  dietSQL + "isvegetarian = 'Y', ";		
				} else if (jsonObj2.isvegetarian == false) {
					dietSQL =  dietSQL + "isvegetarian = 'N', ";		
				}
			} 
			if (jsonObj2.isvegetariannoegg !== undefined) {
				if (jsonObj2.isvegetariannoegg == true) {
					dietSQL =  dietSQL + "isvegetariannoegg = 'Y', ";		
				} else if (jsonObj2.isvegetariannoegg == false) {
					dietSQL =  dietSQL + "isvegetariannoegg = 'N', ";		
				}
			} 
			if (jsonObj2.isvegan !== undefined) {
				if (jsonObj2.isvegan == true) {
					dietSQL =  dietSQL + "isvegan = 'Y', ";		
				} else if (jsonObj2.isvegan == false) {
					dietSQL =  dietSQL + "isvegan = 'N', ";		
				}
			} 
			if (jsonObj2.ispescatarian !== undefined) {
				if (jsonObj2.ispescatarian == true) {
					dietSQL =  dietSQL + "ispescatarian = 'Y', ";		
				} else if (jsonObj2.ispescatarian == false) {
					dietSQL =  dietSQL + "ispescatarian = 'N', ";		
				}
			} 
			if (jsonObj2.isavoiddairy !== undefined) {
				if (jsonObj2.isavoiddairy == true) {
					dietSQL =  dietSQL + "isavoiddairy = 'Y', ";		
				} else if (jsonObj2.isavoiddairy == false) {
					dietSQL =  dietSQL + "isavoiddairy = 'N', ";		
				}
			} 
			if (jsonObj2.isglutenfree !== undefined) {
				if (jsonObj2.isglutenfree == true) {
					dietSQL =  dietSQL + "isglutenfree = 'Y', ";		
				} else if (jsonObj2.isglutenfree == false) {
					dietSQL =  dietSQL + "isglutenfree = 'N', ";		
				}
			} 
			if (jsonObj2.islowcarb !== undefined) {
				if (jsonObj2.islowcarb == true) {
					dietSQL =  dietSQL + "islowcarb = 'Y', ";		
				} else if (jsonObj2.islowcarb == false) {
					dietSQL =  dietSQL + "islowcarb = 'N', ";		
				}
			} 
			if (jsonObj2.ishearthealthy !== undefined) {
				if (jsonObj2.ishearthealthy == true) {
					dietSQL =  dietSQL + "ishearthealthy = 'Y', ";		
				} else if (jsonObj2.ishearthealthy == false) {
					dietSQL =  dietSQL + "ishearthealthy = 'N', ";		
				}
			} 
			if (jsonObj2.islowsodium !== undefined) {
				if (jsonObj2.islowsodium == true) {
					dietSQL =  dietSQL + "islowsodium = 'Y', ";		
				} else if (jsonObj2.islowsodium == false) {
					dietSQL =  dietSQL + "islowsodium = 'N', ";		
				}
			} 
			if (jsonObj2.islowglycemicindex !== undefined) {
				if (jsonObj2.islowglycemicindex == true) {
					dietSQL =  dietSQL + "islowglycemicindex = 'Y', ";		
				} else if (jsonObj2.islowglycemicindex == false) {
					dietSQL =  dietSQL + "islowglycemicindex = 'N', ";		
				}
			} 
			if (jsonObj2.ishalal !== undefined) {
				if (jsonObj2.ishalal == true) {
					dietSQL =  dietSQL + "ishalal = 'Y', ";		
				} else if (jsonObj2.ishalal == false) {
					dietSQL =  dietSQL + "ishalal = 'N', ";		
				}
			} 
			if (jsonObj2.iskosher !== undefined) {
				if (jsonObj2.iskosher == true) {
					dietSQL =  dietSQL + "iskosher = 'Y', ";		
				} else if (jsonObj2.iskosher == false) {
					dietSQL =  dietSQL + "iskosher = 'N', ";		
				}
			} 
			if (jsonObj2.familydiet !== undefined) {
				if (jsonObj2.familydiet == true) {
					dietSQL =  dietSQL + "forfamily = 'Y', ";		
				} else if (jsonObj2.familydiet == false) {
					dietSQL =  dietSQL + "forfamily = 'N', ";		
				} else {
					dietSQL =  dietSQL + "forfamily = '" + jsonObj2.familydiet + "', ";							
				}
			} 
			dietSQL =  dietSQL + "modifiedby = " + profileID + " " + dietWhere;

			console.log("Diet SQL Final: " + dietSQL);
			executeSQL(dietSQL,  function(err, response) {
				if (err) {
					callback(err, null);
				} else {
					updateActual = updateActual + 1;
					console.log("Diet SQL updateActual: " + updateActual + ", updateExpected: " + updateExpected);
					if (updateActual == updateExpected) {
						callback(null, response);
					}
				}
			});		
		} 
	
		if (jsonObj2.foodpreferenceid !== undefined) {
			console.log('Food Preference Save');
			foodWhere = "WHERE foodpreferenceid = " + jsonObj2.foodpreferenceid;
			foodSQL = "UPDATE logoshealth.foodpreference SET ";

			if (jsonObj2.maxcost !== undefined) {
				foodSQL =  foodSQL + "maxcost = (SELECT dictionaryid from logoshealth.dictionary where fieldname = 'maxcost' and value = '" + jsonObj2.maxcost + "'), ";
			} 
			if (jsonObj2.deliveryrange !== undefined) {
				foodSQL =  foodSQL + "deliveryrange = (SELECT dictionaryid from logoshealth.dictionary where fieldname = 'deliveryrange' and value = '" + 
				  jsonObj2.deliveryrange + "'), ";
			} 
			if (jsonObj2.deliveryoption !== undefined) {
				foodSQL =  foodSQL + "deliveryoption = (SELECT dictionaryid from logoshealth.dictionary where fieldname = 'deliveryoption' and value = '" + 
				  jsonObj2.deliveryoption + "'), ";
			} 
			if (jsonObj2.familyfood !== undefined) {
				if (jsonObj2.familyfood == true) {
					foodSQL =  foodSQL + "forfamily = 'Y', ";		
				} else if (jsonObj2.familyfood == false) {
					foodSQL =  foodSQL + "forfamily = 'N', ";		
				} else {
					foodSQL =  foodSQL + "forfamily = '" + jsonObj2.familyfood + "', ";							
				}
			} 
			foodSQL =  foodSQL + "modifiedby = " + profileID + " " + foodWhere;

			//console.log("Food SQL Final: " + dietSQL);
			executeSQL(foodSQL,  function(err, response) {
				if (err) {
					callback(err, null);
				} else {
					updateActual = updateActual + 1;
					console.log("Food SQL updateActual: " + updateActual + ", updateExpected: " + updateExpected);
					if (updateActual == updateExpected) {
						callback(null, response);
					}
				}
			});		
		}

		if (jsonObj2.categories.items.length > 0) {
			var masters = [];
			var masterKey = [];
			var catAnswer;
			var catSQL;

			var master = {
				'answervalue': "untouched",
				'category': "American",
				'foodcategorypreferenceid': 0,
				'childUpgrade': false,
				'childDowngrade': false				
			}
			masters.push(master);
			masterKey["American"] = 0;
			var masterAsian = {
				'answervalue': "untouched",
				'category': "Asian",
				'foodcategorypreferenceid': 0,
				'childUpgrade': false,
				'childDowngrade': false				
			}
			masters.push(masterAsian);
			masterKey["Asian"] = 1;			
			var masterLA = {
				'answervalue': "untouched",
				'category': "Latin American",
				'foodcategorypreferenceid': 0,
				'childUpgrade': false,
				'childDowngrade': false				
			}
			masters.push(masterLA);
			masterKey["Latin American"] = 2;						
			var masterME = {
				'answervalue': "untouched",
				'category': "Mediterranean and European",
				'foodcategorypreferenceid': 0,
				'childUpgrade': false,
				'childDowngrade': false				
			}
			masters.push(masterME);
			masterKey["Mediterranean and European"] = 3;						
			
			console.log('Begin Food Category Updates!!!');
			//MM 6-22-18 First loop - Identify Master Categories that have been updated and change value in Array
			for (var j = 0; j < jsonObj2.categories.items.length; j++) {
				console.log('jsonObj2.categories.items[j]:', jsonObj2.categories.items[j]);
				if (jsonObj2.categories.items[j].ismaster == 'Y') {
					masters[masterKey[jsonObj2.categories.items[j].master_category]].answervalue = jsonObj2.categories.items[j].answervalue; 
					console.log('Captured Master Answer Value: ' + masters[masterKey[jsonObj2.categories.items[j].master_category]].answervalue);
					masters[masterKey[jsonObj2.categories.items[j].master_category]].foodcategorypreferenceid = jsonObj2.categories.items[j].foodcategorypreferenceid;
					console.log('Captured Master ID: ' + masters[masterKey[jsonObj2.categories.items[j].master_category]].foodcategorypreferenceid);
				}
			}

			//MM 6-22-18 2nd loop - Update Child records - if child record has different value than master, set Master to choose
			for (var j = 0; j < jsonObj2.categories.items.length; j++) {
				catAnswer = 0;
				if (jsonObj2.categories.items[j].ismaster == 'N') {
					if (jsonObj2.categories.items[j].answervalue == 'Y') {
						catAnswer = 171  //dictionary code for answer value of Yes
						if (jsonObj2.categories.items[j].master_category !== 'zOther') {
							masters[masterKey[jsonObj2.categories.items[j].master_category]].childUpgrade = true;
						}	
					} else if (jsonObj2.categories.items[j].answervalue == 'N') {
						catAnswer = 172 //dictionary code for answer value of No 
						if (jsonObj2.categories.items[j].master_category !== 'zOther') {
							masters[masterKey[jsonObj2.categories.items[j].master_category]].childDowngrade = true;
						}
					}
					if (catAnswer > 0) {
					  if (jsonObj2.categories.items[j].master_category !== 'zOther') {
						
						//check to see if the master has been updated and is different than the current child
						if (masters[masterKey[jsonObj2.categories.items[j].master_category]].answervalue !== "untouched" &&
						  masters[masterKey[jsonObj2.categories.items[j].master_category]].answervalue !== jsonObj2.categories.items[j].answervalue) {
							masters[masterKey[jsonObj2.categories.items[j].master_category]].answervalue = "choose";
						}
					  }
						catSQL = "update logoshealth.foodcategorypreference set answer = " + catAnswer + ", modifiedby = " + profileID + 
						  " where foodcategorypreferenceid = " + jsonObj2.categories.items[j].foodcategorypreferenceid;
						executeSQL(catSQL,  function(err, response) {
							if (err) {
								callback(err, null);
							} else {
								updateActual = updateActual + 1;
								console.log("Food SQL updateActual: " + updateActual + ", updateExpected: " + updateExpected);
								if (updateActual == updateExpected) {
									callback(null, response);
								}
							}
						});		
					}
				}
			}
			
			//MM 6-22-18 last loop - Update Master records - to choose when appropriate or both master and children together when appropriate
			//console.log('Masters length: ' + masters.length);
			for (var j = 0; j < masters.length; j++) {
				catSQL = "";
				console.log("Master[j]: ", masters[j]);
				//console.log('Update Food Cat - Starting loop 3');
				if (masters[j].answervalue == "choose") {
					console.log('Update Food Cat - Starting loop 3');
					catSQL = "update logoshealth.foodcategorypreference set answer = 173, modifiedby = " + profileID + " where foodcategorypreferenceid = " + 
					  masters[j].foodcategorypreferenceid; 			
				} else if (masters[j].answervalue == "Y") {
					catSQL = "update logoshealth.foodcategorypreference set answer = 171, modifiedby = " + profileID + " where profileid = " +  profileID + 
					  " and foodcategoryid in (select foodcategoryid from logoshealth.foodcategory where master_category = '" + masters[j].category  +"')";			
				} else if (masters[j].childDowngrade && masters[j].childUpgrade){
					updateExpected = updateExpected + 1;
					console.log("Add count Upgrade & Downgrade: " + updateExpected);
					catSQL = "update logoshealth.foodcategorypreference set answer = 173, modifiedby = " + profileID + " where profileid = " + profileID + 
					  " and categoryname = '" + masters[j].category + "'"; 								
				} else if (masters[j].childDowngrade == false && masters[j].childUpgrade) {
					updateExpected = updateExpected + 1;
					console.log("Add count Upgrade Only: " + updateExpected);
					catSQL = "update logoshealth.foodcategorypreference set answer = 173, modifiedby = " + profileID + " where profileid = " + profileID + 
					  " and categoryname = '" + masters[j].category + "'"; 								
				} else if ((masters[j].childDowngrade && masters[j].childUpgrade == false) || masters[j].answervalue == "N") {
					if (masters[j].answervalue !== "N") {
						updateExpected = updateExpected + 1;
					}
					console.log("Add count Downgrade Only: " + updateExpected);
					var connection = new getLogosConnection();
					var resultCount;
					var sqlCount = "select count(*) as yesCount, '" + masters[j].category + "' as idHolder from logoshealth.foodcategorypreference " +
					  "where answervalue = 'Y' and foodcategoryid in (" +
					  "select foodcategoryid from logoshealth.foodcategory where master_category = '" + masters[j].category  +"') and profileid = " + profileID;			

					connection.query(sqlCount, function (error, results, fields) {
						if (error) {
							console.log('executeSQL: The Error is: ', error);
							closeConnection(connection);
							callback(error, null);
						} else {
							resultCount = results[0].yesCount;
							if (resultCount == 0) {
								var cat2SQL = "update logoshealth.foodcategorypreference set answer = 172, modifiedby = " + profileID + " where profileid = " + profileID + 
								  " and categoryname = '" + results[0].idHolder + "'";
								  closeConnection(connection);
								  executeSQL(cat2SQL,  function(err, response) {
									if (err) {
										callback(err, null);
									} else {
										updateActual = updateActual + 1;
										console.log("FoodCat SQL updateActual from downgrade no loop: " + updateActual + ", updateExpected: " + updateExpected);
										if (updateActual == updateExpected) {
											callback(null, response);
										}
									}
								});
							} else {
								var cat2SQL = "update logoshealth.foodcategorypreference set answer = 173, modifiedby = " + profileID + " where profileid = " + profileID + 
								  " and categoryname = '" + results[0].idHolder + "'"; 								
								closeConnection(connection); //all is done so releasing the resources
								executeSQL(cat2SQL,  function(err, response) {
									if (err) {
										callback(err, null);
									} else {
										updateActual = updateActual + 1;
										console.log("FoodCat SQL updateActual from downgrade choose loop: " + updateActual + ", updateExpected: " + updateExpected);
										if (updateActual == updateExpected) {
											callback(null, response);
										}
									}
								});
			
							}
						}
					  });


				}
				if (catSQL !== "") {
					executeSQL(catSQL,  function(err, response) {
						if (err) {
							callback(err, null);
						} else {
							updateActual = updateActual + 1;
							console.log("FoodCat SQL updateActual: " + updateActual + ", updateExpected: " + updateExpected);
							if (updateActual == updateExpected) {
								callback(null, response);
							}
						}
					});
				}
			}				
		}
	}
}

function executeSQL (sql, callback) {
	console.log('executeSQL: ' + sql);
	pool.getConnection(function(err, conn) {
		if (err) {
			console.log('Execute SQL error: ', err);
		} else {
			conn.query(sql, function (error, results, fields) {
				if (error) {
					console.log('executeSQL: The Error is: ', error);
					conn.release();
					callback(error, null);
				} else {
					conn.release();
					callback(null, 'Success');
				}
			});	
		}
	});
}
