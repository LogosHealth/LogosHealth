'use strict';

var mysql = require('mysql');
var moment = require('moment-timezone');
var timezone = "";

exports.handler = (event, context, callback) => {
	var bodyJson;
	console.log('event: ', event);
	console.log('context: ', context);	
	if (event.httpMethod == 'GET') { 
		console.log('GET method called');  
		TasksByProfile (event, function(err, response) {
			if (err) {
				console.log('Error from TasksByProfile: ' + err);
				bodyJson = JSON.stringify(err);
			} else {
				console.log('Results from TasksByProfile: ' + response);
				bodyJson = JSON.stringify(response);
			}
			var responsePackage = {
				"statusCode": 200,
				"headers": {
					"TasksByProfile": "Complete"
				},
				"body": bodyJson,
				"isBase64Encoded": false
			};
			callback(null, responsePackage);
		});		
	  } else if (event.httpMethod == 'POST') {
		console.log('POST method called');  
		TasksByProfileSave (event, function(err, response) {
			if (err) {
				console.log('Error from TasksByProfileSave: ' + err);
				bodyJson = JSON.stringify(err);
			} else {
				console.log('Results from TasksByProfileSave: ' + response);
				bodyJson = JSON.stringify(response);
			}
			var responsePackage = {
				"statusCode": 200,
				"headers": {
					"TasksByProfile": "Complete"
				},
				"body": bodyJson,
				"isBase64Encoded": false
			};
			callback(null, responsePackage);
		});		
	  } else {
		console.log('Wrong method called');  
		callback('Wrong method called', null);  
	  }	
}

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

//Feature 2: Finds profiles without GeoCoords -->  gets GeoCoords from Google Maps --> update GeoCoords 
//MM 02-07-2018 This function finds any restaurants without GeoCoords - cloned from findRestaurantsWithoutGeoCoords 
function TasksByProfile (event, callback) {
	var connection = new getLogosConnection();
	var sql = "SELECT taskid, profileid, taskname, tasktime, reps, goalname, goalid, dateofmeasure, activeflag, " + 
	"confirmedflag FROM logoshealth.task where  activeflag = 'Y'";
	var resultsItem;
	var populars = [];
	var skip = false;
	
	if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
	  && event.queryStringParameters.profileid !== "") {
		sql = sql + " and profileid = " + event.queryStringParameters.profileid + " order by exerciseid desc";
	} else {
		skip = true;
		callback('Invalid query parameters', null);					
	}

	if (skip == false) {
	  connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('TasksByProfile: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results !== null && results.length > 0) {
				console.log('TasksByProfile - Result length count: ' + results.length);
                for (var j = 0; j < results.length; j++) {				
					resultsItem = {
						'recordid':results[j].taskid,
    					'taskname':results[j].taskname,
						'tasktime':results[j].tasktime,
						'reps':results[j].reps,
						'goalname':results[j].goalname,
						'goalid':results[j].goalid,
						'dateofmeasure':results[j].dateofmeasure,
						'active':results[j].activeflag,
						'profileid':results[j].profileid,
						'confirmed':results[j].confirmedflag
					};
					populars.push(resultsItem);
				}	
				closeConnection(connection); //all is done so releasing the resources	
				callback(null, populars);					
			} else {
				closeConnection(connection); //all is done so releasing the resources	
				callback('No data found', null);					
			}
		}
	  });
	}	
}	

function TasksByProfileSave (event, callback) {
	var connection = new getLogosConnection();

	var jsonObject = JSON.parse(event.body);
	var jsonObj2 = JSON.parse(jsonObject);
	var blnInactivate = false;
	var blnNewRecord = false;
	var sql;
	var sql1;
	var sql2;
	var blnSkip = false;
	var dtNow = new Date();
	var dtSave = moment(dtNow);
	
	console.log('TasksByProfileSave: ', jsonObj2);
	if (jsonObj2.timezone !==undefined && jsonObj2.timezone !=="") {
		timezone = jsonObj2.timezone;
	}	
	
	if (jsonObj2.active !==undefined && jsonObj2.active !=="") {
		if (jsonObj2.active == "N") {
			blnInactivate = true;
		} else if (jsonObj2.recordid == undefined || jsonObj2.recordid == null || jsonObj2.recordid == "") {
			console.log('TasksByProfileSave - Insert record expect recordid = ' + jsonObj2.recordid);
			blnNewRecord = true;
		}
	} else {
		callback('Invalid data', null);
		blnSkip = true;	
	}

	if (blnInactivate) {
		sql = "Update logoshealth.task set activeflag = 'N', modifiedby = " + jsonObj2.userid + " where taskid = " + jsonObj2.recordid;
	} else if (blnNewRecord) {
		sql1 = "Insert into logoshealth.task (";
		sql2 = "values (";
		if (jsonObj2.goalname !==undefined) {
			sql1 = sql1 + "goalname, "
			sql2 = sql2 + "'" + jsonObj2.goalname + "', ";
		}
		if (jsonObj2.reps !==undefined) {
			sql1 = sql1 + "reps, "
			sql2 = sql2 + jsonObj2.reps + ", ";
		}
		if (jsonObj2.tasktime !==undefined) {
			sql1 = sql1 + "tasktime, "
			sql2 = sql2 + "'" + jsonObj2.tasktime + "', ";
		}
		if (jsonObj2.taskname !==undefined) {
			sql1 = sql1 + "taskname, "
			sql2 = sql2 + "'" + jsonObj2.taskname + "', ";
		}
		if (jsonObj2.dateofmeasure !==undefined) {
			sql1 = sql1 + "dateofmeasure, "
			var dtDET = moment(jsonObj2.dateofmeasure);
			sql2 = sql2 + "'" + dtDET.format("YYYY-MM-DD HH:mm") + "', ";
			sql1 = sql1 + "profileid, createdby, modifiedby) ";
			sql2 = sql2 + jsonObj2.profileid + ", " + jsonObj2.userid + ", " + 
			  jsonObj2.userid + ")";
			sql = sql1 + sql2;  
		} else if (jsonObj2.taskname !==undefined && jsonObj2.profileid !==undefined && jsonObj2.userid !==undefined) {
			sql1 = sql1 + "taskname, profileid, createdby, modifiedby, dateofmeasure) ";
			sql2 = sql2 + "'" + jsonObj2.taskname + "', " + jsonObj2.profileid + ", " + jsonObj2.userid + ", " + 
			  jsonObj2.userid + ", '"+  dtSave.format("YYYY-MM-DD HH:mm") + "')";
			sql = sql1 + sql2;			
		} else {
			callback('Invalid data', null);	
			blnSkip = true;	
		}
	} else {
		sql = "update logoshealth.task set ";
		if (jsonObj2.goalname !==undefined) {
			sql = sql + "goalname = '" + jsonObj2.goalname  + "', ";
		}
		if (jsonObj2.reps !==undefined) {
			sql = sql + "reps = " + jsonObj2.reps  + ", ";
		}
		if (jsonObj2.tasktime !==undefined) {
			sql = sql + "tasktime = '" + jsonObj2.tasktime  + "', ";
		}
		if (jsonObj2.userid !==undefined && jsonObj2.recordid !==undefined) {
			sql = sql + "modifiedby = " + jsonObj2.userid + " where taskid = " + jsonObj2.recordid;
		} else {
			callback('Invalid data', null);	
			blnSkip = true;	
		}
	}

	if (!blnSkip) {
		console.log('TasksByProfileSave - Final SQL: ' + sql);
		connection.query(sql,  function (err, results, fields) {
			if (err) {
				closeConnection(connection); //all is done so releasing the resources	
				callback(err, null);
			} else {
				var recordid;
				if(blnNewRecord) {
					console.log('Insert recordid: ' + results.insertId);
					recordid = results.insertId;
				} else {
					recordid = jsonObj2.recordid;
				}
				closeConnection(connection); //all is done so releasing the resources

				var qnaObj = {
					"profileid": jsonObj2.profileid,
					"answerTable": "task", 
					"tableid": recordid 
				}
				checkGoal (qnaObj, function(error, results) {
					if (error) {
						console.log ("Error in CheckGoal: " + error);
						callback(null, "Success but error in Check Goal: " + error);
					} else {
						console.log ("Results from CheckGoal: " + results);
						callback(null, "Success in Check Goal results = " + results);
					}
				});	
			}
		});			
	} else {
		console.log('Skipped');
	}
}

function checkGoal(qnaObj, callback) {
	var connection = getLogosConnection();
	var vSQL;
	var profileId = 0;
	var goalType;
	var goalObj = {};
	var goals = [];
	
	profileId = qnaObj.profileid;

	goalType = qnaObj.answerTable;

	vSQL="SELECT goalid, version, goalname, goalnumber, goalunitvalue, daysperweekvalue, reward, rewardtimingvalue FROM logoshealth.goal where activeflag = 'Y' and goaltype = '" + 
	  goalType + "' and profileid = " + profileId;

	console.log('checkGoal SQL:' + vSQL);  
	connection.query(vSQL, function (error, results, fields) {    	
		if (error) {
            console.log('ExerciseByProfileSave.checkGoal connection Error. the Error is: ', error);
			closeConnection(connection);
			callback(error, null);
    	} else {
			//console.log('DBUtils.checkGoal connection results gound. results length is : '+results.length);
			if (results !== null && results.length > 0) {
				for (var i = 0; i < results.length; i++) {
					goalObj = {
						"goalid": results[i].goalid,
						"version": results[i].version,						
						"goalname": results[i].goalname,
						"goalnumber": results[i].goalnumber,
						"goalunitvalue": results[i].goalunitvalue,
						"daysperweekvalue": results[i].daysperweekvalue,
						"reward": results[i].reward,
						"rewardtimingvalue": results[i].rewardtimingvalue						
					};
					goals.push(goalObj);
				}
				console.log('Goals obj', goals);
				closeConnection(connection);
				compareToActiveGoal(qnaObj, goals, callback);							

			} else {
				closeConnection(connection);
				callback(null, 'No active goal');
			}			
		}
	});
}

//MM 6-27-18 Checks to see if there is an active goal for which current interview could apply.  When active goals, capture meta-data in object and goto compareToActiveGoal
function compareToActiveGoal(qnaObj, goals, callback) {
	var connection = getLogosConnection();
	var vSQL;
	var sqlFields;
	var profileId = 0;
	var objType;
	var resultsObj = {};
	var goalMatch = false;
	var hasGoalName = false;
	var hasProgressData = false;
	var unitValue;
	var units;
	var goalIndex;
	var unHappyPath;
	
	profileId = qnaObj.profileid;

	objType = qnaObj.answerTable;
	sqlFields = "taskname, tasktime, reps, goalid, goalname, dateofmeasure";

	vSQL="SELECT " + sqlFields + " FROM logoshealth." + objType + " where " + objType + "id = " + qnaObj.tableid;  

	console.log('DBUtils.compareToActiveGoal SQL: ' + vSQL);
	connection.query(vSQL, function (error, results, fields) {    	
		if (error) {
            console.log('DBUtils.compareToActiveGoal connection Error. the Error is: ', error);
			closeConnection(connection);
			callback(error, null);
		} else {
			if (results !== null && results.length > 0) {
				if (objType == 'task') {
					resultsObj = {
						"taskname": results[0].taskname,
						"tasktime": results[0].tasktime,
						"reps": results[0].reps,
						"goalid": results[0].goalid,
						"goalname": results[0].goalname,
						"dateofmeasure": results[0].dateofmeasure												
					};
					closeConnection(connection);

					for (var i = 0; i < goals.length; i++) {
						if (resultsObj.goalid !==null && resultsObj.goalid > 0) {
							if (resultsObj.goalid == goals[i].goalid) {
								goalMatch = true;
								console.log('Goal Match loop1: goalMatch: ' + goalMatch);
								goalIndex = i;
							}
						} else if (resultsObj.goalname !==null && resultsObj.goalname !=="" && !goalMatch) {
							hasGoalName = true;
							if (resultsObj.goalname.substring(0, 3).toLowerCase() == goals[i].goalname.substring(0, 3).toLowerCase()) {
								goalMatch = true;
								console.log('Goal Match loop2: goalMatch: ' + goalMatch);
								goalIndex = i;
							}	
						}
					}
					console.log('Goal Match after for loop in task: goalMatch: ' + goalMatch);					
					if (!goalMatch && hasGoalName) {
						callback(null, 'Goal Name does not match active goal');
					} else if (!goalMatch) {
						callback(null, 'Goal Name does not match active goal2');
					} else {
						console.log('Begin Switch');
						switch (goals[goalIndex].goalunitvalue)
						{
							case 'Minutes': 
								var timeSplit;
								if (resultsObj.tasktime !== undefined && resultsObj.tasktime !==null) {
									timeSplit = resultsObj.tasktime.split(" ");                                 
									unitValue = Number(timeSplit[0].trim());                             
								}
								if (timeSplit[1] !== undefined) {
									units = timeSplit[1].trim();                            
								} else {
									units = "";
								}
								console.log('compareToActiveGoal Minutes - unitValue: ' + unitValue + ', units: ' + units);
								if (unitValue !==NaN && unitValue > 0) {
									hasProgressData = true;
									if (units.substring(0, 4).toLowerCase() == 'hour') {
										unitValue = unitValue * 60;
									}
								} else {
									unHappyPath =  "You have completed the exercise entry.  You can review and confirm this entry in the LogosHealth visual app. " +
									"Please note no time from this entry could be applied to your daily progress for goal, " + 
									goals[goalIndex].goalname + ".  Main menu.  What would you like to do? For a list of options, simply say Menu.";
								}	
						   	break;
												
						   	case 'Number': 
							   unitValue = Number(resultsObj.reps);                            
							   console.log('compareToActiveGoal - reps: ' + unitValue);
							   if (unitValue !==NaN && unitValue > 0) {
								hasProgressData = true;
							} else {
								unHappyPath =  "You have completed the exercise entry.  You can review and confirm this entry in the LogosHealth visual app. " +
								"Please note no count from this entry could be applied to your daily progress for goal, " + 
								goals[goalIndex].goalname + ".  Main menu.  What would you like to do? For a list of options, simply say Menu.";
							}							   
						   	break;
						
							default: 
						    	console.log("compareToActiveGoal - No term in switch found for " + goals[goalIndex].goalunitvalue + " default called");
						   		hasProgressData = false;
						}

						if (hasProgressData) {
							//threadCount2 = threadCount2 + 1;
							//console.log('ThreadCount2: ' + threadCount2);						
							GetGoalTrackingWeek(goals[goalIndex], function(err, response) {
								if (err) {
									callback(err, null);
								} else {
									var gtResponse = response;
									console.log('Track SetGoalTrackingDay line 589');
									//threadCount3 = threadCount3 + 1;
									//console.log('ThreadCount3: ' + threadCount3);
									console.log('Check resultsObj: ', resultsObj);
									SetGoalTrackingDay(qnaObj, gtResponse, goals[goalIndex], unitValue, resultsObj.dateofmeasure, function(err, response) {
										if (err) {
											callback(err, null);
										} else {
											callback(null, response);
										}	
									});
								}                                   
							});
						} else {
							callback(null, 'No meaningful progress captured');
						}
					}					
				} else {
					closeConnection(connection);
					callback(null, 'No meaningful progress captured2');
				}			
			}
		}
	});
}

//MM 6-27-18 Gets GoalTracking Week and returns the goal_trackingid
function GetGoalTrackingWeek(goal, callback) {
	var connection = getLogosConnection();
	var vSQL;
	var dtNow =new Date();
	var momentNow = moment(dtNow);
	var todayStr;
	var dayoftheweek;
	var offSet;
	var endofWeek;

	if (timezone !== "") {
		todayStr = momentNow.tz(timezone).format('YYYY-MM-DD');
		dayoftheweek = momentNow.tz(timezone).format('dddd');
	} else {
		todayStr = momentNow.format('YYYY-MM-DD');
		dayoftheweek = momentNow.format('dddd');
	}


	if (dayoftheweek == 'Sunday') {
		offSet = 6
	} else if (dayoftheweek == 'Monday') {
		offSet = 5		
	} else if (dayoftheweek == 'Tuesday') {
		offSet = 4				
	} else if (dayoftheweek == 'Wednesday') {
		offSet = 3				
	} else if (dayoftheweek == 'Thursday') {
		offSet = 2				
	} else if (dayoftheweek == 'Friday') {
		offSet = 1				
	} else if (dayoftheweek == 'Saturday') {
		offSet = 0				
	}

	if (timezone !== "") {
		endofWeek = moment(momentNow).tz(timezone).add(offSet, 'days');
	} else {
		endofWeek = moment(momentNow).add(offSet, 'days');
	}
	vSQL="SELECT goal_trackingid, days_met FROM logoshealth.goal_tracking where goalid = " + goal.goalid + " and '" + todayStr + "'  >= week_start and '" +
	todayStr + "' <= week_end";

	console.log('GetGoalTrackingWeek SQL: ' + vSQL);
	connection.query(vSQL, function (error, results, fields) {    	
		if (error) {
            //console.log('DBUtils.GetGoalTrackingWeek connection Error. the Error is: ', error);
			closeConnection(connection);
			callback(error, null);
    	} else {
			//console.log('DBUtils.checkGoal connection results gound. results length is : '+results.length);
			if (results !== null && results.length > 0) {
				var gtResults = {
					"goaltrackingid": results[0].goal_trackingid,
					"days_met":	results[0].days_met
				};
				closeConnection(connection);
				console.log('GetGoalTrackingWeek Results - ', gtResults);
				if (gtResults.goaltrackingid !==null && gtResults.goaltrackingid > 0) {
					callback(null, gtResults); 				
				} else {
					callback('ALERT! Goal tracking record not found for ' + todayStr, null); 							
				}
			} else {
				var weekInsertSQL = "insert into logoshealth.goal_tracking (goalid, goalversion, week_start, week_end, createdby, modifiedby) values (" +
				goal.goalid + ", " + goal.version + ", '" + todayStr + "', '" + endofWeek.format('YYYY-MM-DD') + "', 2, 2)";

				console.log('GetGoalTrackingWeek Insert SQL - ', weekInsertSQL);
				connection.query(weekInsertSQL, function (error, results, fields) {    	
					if (error) {
						console.log('DBUtils.GetGoalTrackingWeek connection Error. the Error is: ', error);
						closeConnection(connection);
						callback('ALERT! Goal tracking record not found for ' + todayStr + ' Insert failed.', null); 							
					} else {
						closeConnection(connection);
						var gtResults = {
							"goaltrackingid": results.insertId,
							"days_met":	0
						};

						if (gtResults.goaltrackingid !==null && gtResults.goaltrackingid > 0) {
							callback(null, gtResults); 				
						} else {
							callback('ALERT! Goal tracking record not found for ' + todayStr +  ' Insert failed2.', null); 							
						}
					}
				});
			}			
		}
	});
}

//MM 6-28-18 Gets GoalTracking Week and returns the goal_trackingid
function SetGoalTrackingDay(session, goalTrackingObj, goal, unit, dom, callback) {
	var connection = getLogosConnection();
	var vSQL;
	var dtNow =new Date();
	var momentNow = moment(dtNow);
	var todayStr;
	var GTDInsertSQL;
	var strDailyMet;
	var strDailyExceed = 'N';
	var gtdid;
	var gtdTotal;
	var gtdDailyMetBefore;
	var weeklyMetBefore = 'N';
	var weeklyMet = 'N';
	var weeklyExceed = 'N';
	var newTotal;
	var GTDUpdateSQL;
	var weeklyCount;

	console.log('Dom: ' + dom);
	if (dom !== undefined && dom !== null && dom !== "") {
		if (timezone !== "") {
			todayStr = moment(dom).tz(timezone).format('dddd');
		} else {
			todayStr = moment(dom).format('dddd');
		}	
	} else {
		if (timezone !== "") {
			todayStr = momentNow.tz(timezone).format('dddd');
		} else {
			todayStr = momentNow.format('dddd');
		}	
	}

	console.log('Start SetGoalTrackingDay todayStr: ' + todayStr);

	if (Number(goalTrackingObj.days_met) == Number(goal.daysperweekvalue)) {
		weeklyMetBefore = 'Y';
		weeklyMet = 'Y';
	} else if (Number(goalTrackingObj.days_met) > Number(goal.daysperweekvalue)) {
		weeklyMetBefore = 'Y';
		weeklyMet = 'Y';
		weeklyExceed = 'Y';
	}

	vSQL="SELECT goal_tracking_dayid, total, daily_goal_met FROM logoshealth.goal_tracking_day where goal_trackingid = " + 
	goalTrackingObj.goaltrackingid + " and day = '" + todayStr + "'";

	console.log('SetGoalTrackingDay SQL: ' + vSQL);
	connection.query(vSQL, function (error, results, fields) {    	
		if (error) {
            //console.log('DBUtils.GetGoalTrackingWeek connection Error. the Error is: ', error);
			closeConnection(connection);
			callback(error, null);
    	} else {
			//console.log('DBUtils.checkGoal connection results gound. results length is : '+results.length);
			if (results !== null && results.length > 0) {
				gtdid = results[0].goal_tracking_dayid;
				gtdTotal = results[0].total;
				gtdDailyMetBefore = results[0].daily_goal_met;
				newTotal = Number(gtdTotal) + Number(unit);
				GTDUpdateSQL = "update logoshealth.goal_tracking_day set total = " + newTotal;
				if (Number(newTotal) >= Number(goal.goalnumber)) {
					strDailyMet = 'Y';
				} else {
					strDailyMet = 'N';					
				}				
				if (Number(newTotal)/Number(goal.goalnumber) >= 1.25) {
					strDailyExceed = 'Y';
				} 							
				if (gtdDailyMetBefore == 'N' && strDailyMet == 'Y') {
					GTDUpdateSQL = GTDUpdateSQL + ", daily_goal_met = 'Y'";
				}
				GTDUpdateSQL = GTDUpdateSQL + ", modifiedby = " + session.profileid + " where goal_tracking_dayid = " + gtdid;

				console.log('SetGoalTrackingDay Update SQL: ' + GTDUpdateSQL);
				connection.query(GTDUpdateSQL, function (error, results, fields) {    	
					if (error) {
						//console.log('DBUtils.GetGoalTrackingWeek connection Error. the Error is: ', error);
						closeConnection(connection);
						callback(error, null);
					} else {
						if (gtdDailyMetBefore == 'N' && strDailyMet == 'Y') {
						//Add to weekly progress counter
							if (goalTrackingObj.days_met !==null && goalTrackingObj.days_met > 0) {
								weeklyCount = Number(goalTrackingObj.days_met) + 1;
							} else {
								weeklyCount = 1;
							}
							var GTWeeklySQL = "update logoshealth.goal_tracking set days_met = " + weeklyCount + ", modifiedby = " + session.profileid +
							 " where goal_trackingid = " + goalTrackingObj.goaltrackingid;
							console.log('SetGoalTrackingDay UpdateGTSQL from update: ' + GTWeeklySQL);
							connection.query(GTWeeklySQL, function (error, results, fields) {    	
								if (error) {
									//console.log('DBUtils.GetGoalTrackingWeek connection Error. the Error is: ', error);
									closeConnection(connection);
									callback(error, null);
								} else {
									closeConnection(connection);
									if (weeklyCount == goal.daysperweekvalue) {
										weeklyMet = 'Y';
									} else if (weeklyCount > goal.daysperweekvalue) {
										weeklyExceed = 'Y';
									}														
									var DTResponse = {
										"dailyMet": strDailyMet,
										"dailyExceed": strDailyExceed, 
										"dailyMetBefore": 'N',
										"weeklyMet": weeklyMet,
										"weeklyExceed": weeklyExceed, 
										"weeklyMetBefore": weeklyMetBefore,
										"newTotal": newTotal,
										"weeklyCount": weeklyCount
									};
									callback(null, DTResponse);	
								}								
							});						
						} else {
							closeConnection(connection);
							if (goalTrackingObj.days_met !==null && goalTrackingObj.days_met > 0) {
								var noProgressCount = goalTrackingObj.days_met;
							} else {
								var noProgressCount = 0;
							}
							var DTResponse = {
								"dailyMet": strDailyMet,
								"dailyExceed": strDailyExceed, 
								"dailyMetBefore": gtdDailyMetBefore,
								"weeklyMet": weeklyMet,
								"weeklyExceed": weeklyExceed, 
								"weeklyMetBefore": weeklyMetBefore,
								"newTotal": newTotal,
								"weeklyCount": noProgressCount
							};
							callback(null, DTResponse);	
						}
					}				
				});
			} else {
				if (Number(unit) >= Number(goal.goalnumber)) {
					strDailyMet = 'Y';
					//increaseDailyMet = true;
				} else {
					strDailyMet = 'N';					
				}
				GTDInsertSQL = "insert into logoshealth.goal_tracking_day (goal_trackingid, day, total, daily_goal_met, createdby, modifiedby) values (" +
				  goalTrackingObj.goaltrackingid + ", '" + todayStr + "', " + unit + ", '" + strDailyMet + "', " + session.profileid +
				", " + session.profileid + ")";
				console.log('SetGoalTrackingDay InsertSQL: ' + GTDInsertSQL);
				connection.query(GTDInsertSQL, function (error, results, fields) {    	
					if (error) {
						//console.log('DBUtils.GetGoalTrackingWeek connection Error. the Error is: ', error);
						closeConnection(connection);
						callback(error, null);
					} else {
						if (strDailyMet == 'Y') {
							if (goalTrackingObj.days_met !==null && goalTrackingObj.days_met > 0) {
								weeklyCount = Number(goalTrackingObj.days_met) + 1;
							} else {
								weeklyCount = 1;
							}
							var GTWeeklySQL = "update logoshealth.goal_tracking set days_met = " + weeklyCount + ", modifiedby = " + session.profileid +
							 " where goal_trackingid = " + goalTrackingObj.goaltrackingid;
							console.log('SetGoalTrackingDay GTWeeklySQL: ' + GTWeeklySQL);
							connection.query(GTWeeklySQL, function (error, results, fields) {    	
								if (error) {
									//console.log('DBUtils.GetGoalTrackingWeek connection Error. the Error is: ', error);
									closeConnection(connection);
									callback(error, null);
								} else {
									closeConnection(connection);
									if (weeklyCount == goal.daysperweekvalue) {
										weeklyMet = 'Y';
									} else if (weeklyCount > goal.daysperweekvalue) {
										weeklyExceed = 'Y';
									}														
									var DTResponse = {
										"dailyMet": strDailyMet,
										"dailyExceed": strDailyExceed, 
										"dailyMetBefore": 'N',
										"weeklyMet": weeklyMet,
										"weeklyExceed": weeklyExceed, 
										"weeklyMetBefore": weeklyMetBefore,
										"newTotal": unit,
										"weeklyCount": weeklyCount
									};
									callback(null, DTResponse);	
								}								
							});
						} else {
							closeConnection(connection);						
							var DTResponse = {
								"dailyMet": strDailyMet,
								"dailyExceed": strDailyExceed, 
								"dailyMetBefore": 'N',
								"weeklyMet": weeklyMet,
								"weeklyExceed": weeklyExceed, 
								"weeklyMetBefore": weeklyMetBefore,
								"newTotal": unit,
								"weeklyCount": weeklyCount
							};
							callback(null, DTResponse);	
						}
					}				
				});
			}			
		}
	});
}
