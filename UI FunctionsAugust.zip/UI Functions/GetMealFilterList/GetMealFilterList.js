'use strict';

var mysql = require('mysql');
var moment = require('moment');

exports.handler = (event, context, callback) => {
	var bodyJson;
	console.log('event: ', event);
	//console.log('event method: ', event.httpMethod);
	//console.log('context: ', context);	

  if (event.httpMethod == 'GET') { 
	console.log('GET method called');  
	GetMealFilterList (event, function(err, response) {
		if (err) {
			console.log('Error from GetMealFilterList: ' + err);
			bodyJson = JSON.stringify(err);
		} else {
			console.log('Results from GetMealFilterList: ' + response);
			bodyJson = JSON.stringify(response);
		}
		var responsePackage = {
			"statusCode": 200,
			"headers": {
				"GetMealFilterList": "Complete"
			},
			"body": bodyJson,
			"isBase64Encoded": false
		};
		callback(null, responsePackage);
	});		
  } else {
	console.log('Wrong method called');  
	callback('Wrong method called', null);
	  
  }
}

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

//Feature 2: Finds profiles without GeoCoords -->  gets GeoCoords from Google Maps --> update GeoCoords 
//MM 02-07-2018 This function finds any restaurants without GeoCoords - cloned from findRestaurantsWithoutGeoCoords 
function GetMealFilterList (event, callback) {
	var connection = new getLogosConnection();
	var resultsItem;
	var populars = [];
	var popularsItem = [];
	var skip = false;
	var curID;
	var sql;
	var sqlProfile;
	var sqlProfile2;
	
	var sql1 = "select foodcategoryid as recordid, categoryname as name, 'Y' as iscategory " + 
	"from logoshealth.foodcategorypreference where answervalue = 'Y' ";

	var sql2 = "union select r.restaurantid as recordid, r.restaurantname as name, 'N' as iscategory " + 
	"from logoshealth.restaurant r, logoshealth.home2restaurant h2r, logoshealth.dictionary d1, logoshealth.profile p " +
	"where r.active = 'Y' and r.opennow = 'Y' and r.restaurantid = h2r.restaurantid and h2r.profileid = p.profileid " +
	"and h2r.searchrange = d1.dictionarycode ";
	
	var sql3 = "group by r.restaurantid, r.restaurantname";

	if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
	  && event.queryStringParameters.profileid !== "") {

		sqlProfile = "and profileid = " + event.queryStringParameters.profileid + " ";
		sqlProfile2 = "and p.profileid = " + event.queryStringParameters.profileid + " ";
		sql = sql1 + sqlProfile + sql2 + sqlProfile2 + sql3;
	} else {
		skip = true;
		callback('Invalid query parameters', null);					
	}

	if (skip == false) {
	  connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('GetMealFilterList: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results !== null && results.length > 0) {
				console.log('GetMealFilterList - Result length count: ' + results.length);

				for (var j = 0; j < results.length; j++) {				
					resultsItem = {
						'recordid':results[j].recordid,
						'name':results[j].name,
						'iscategory':results[j].iscategory
					};
					populars.push(resultsItem);						
				}	

				closeConnection(connection); //all is done so releasing the resources	
				console.log('Final Results: ', populars)
				callback(null, populars);					
			} else {
				closeConnection(connection); //all is done so releasing the resources	
				callback('No data found', null);					
			}
		}
	  });
	}	
}	

function executeSQL (sql, callback) {
	var connection = new getLogosConnection();

	console.log('executeSQL: ' + sql);

	connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('executeSQL: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
			closeConnection(connection); //all is done so releasing the resources
			callback(null, 'Success');
		}
	  });		
}
