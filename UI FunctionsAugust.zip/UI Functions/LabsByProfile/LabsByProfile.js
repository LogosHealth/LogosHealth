'use strict';

var mysql = require('mysql');
var moment = require('moment-timezone');
var timezone = "";

exports.handler = (event, context, callback) => {
	var bodyJson;
	console.log('event: ', event);
	console.log('context: ', context);	
	if (event.httpMethod == 'GET') { 
		console.log('GET method called');  
		LabsByProfile (event, function(err, response) {
			if (err) {
				console.log('Error from LabsByProfile: ' + err);
				bodyJson = JSON.stringify(err);
			} else {
				console.log('Results from LabsByProfile: ' + response);
				bodyJson = JSON.stringify(response);
			}
			var responsePackage = {
				"statusCode": 200,
				"headers": {
					"LabsByProfile": "Complete"
				},
				"body": bodyJson,
				"isBase64Encoded": false
			};
			callback(null, responsePackage);
		});		
	  } else if (event.httpMethod == 'POST') {
		console.log('POST method called');  
		LabsByProfileSave (event, function(err, response) {
			if (err) {
				console.log('Error from LabsByProfileSave: ' + err);
				bodyJson = JSON.stringify(err);
			} else {
				console.log('Results from LabsByProfileSave: ' + response);
				bodyJson = JSON.stringify(response);
			}
			var responsePackage = {
				"statusCode": 200,
				"headers": {
					"LabsByProfile": "Complete"
				},
				"body": bodyJson,
				"isBase64Encoded": false
			};
			callback(null, responsePackage);
		});		
	  } else {
		console.log('Wrong method called');  
		callback('Wrong method called', null);  
	  }	
}

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

//Feature 2: Finds profiles without GeoCoords -->  gets GeoCoords from Google Maps --> update GeoCoords 
//MM 02-07-2018 This function finds any restaurants without GeoCoords - cloned from findRestaurantsWithoutGeoCoords 
function LabsByProfile (event, callback) {
	var connection = new getLogosConnection();
	var sql = "SELECT labid, profileid, labname, labnametext, labresult, labunit, labunittext, lowerrange, upperrange, dateofmeasure, " +
	  "confirmedflag, activeflag FROM logoshealth.lab where activeflag = 'Y'";
	var resultsItem;
	var populars = [];
	var skip = false;
	
	if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
	  && event.queryStringParameters.profileid !== "") {
		sql = sql + " and profileid = " + event.queryStringParameters.profileid;
	} else {
		skip = true;
		callback('Invalid query parameters', null);					
	}

	if(event.queryStringParameters !== undefined && event.queryStringParameters.labname !== undefined  
		&& event.queryStringParameters.labname !== "") {
		  sql = sql + " and labname = " + event.queryStringParameters.labname;
	}

	sql = sql + " order by labid desc";

	if (skip == false) {
	  connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('LabsByProfile: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results !== null && results.length > 0) {
				console.log('LabsByProfile - Result length count: ' + results.length);
                for (var j = 0; j < results.length; j++) {				
					resultsItem = {
						'recordid':results[j].labid,
 						'labname':results[j].labname,
 						'labnametext':results[j].labnametext,
 						'labresult':results[j].labresult,
 						'labunit':results[j].labunit,
 						'labunittext':results[j].labunittext,
 						'lowerrange':results[j].lowerrange,
 						'upperrange':results[j].upperrange,
						'dateofmeasure':results[j].dateofmeasure,
						'active':results[j].activeflag,
						'confirmed':results[j].confirmedflag,
						'profileid':results[j].profileid
					};
					populars.push(resultsItem);
				}	
				closeConnection(connection); //all is done so releasing the resources	
				callback(null, populars);					
			} else {
				closeConnection(connection); //all is done so releasing the resources	
				callback('No data found', null);					
			}
		}
	  });
	}	
}	

function LabsByProfileSave (event, callback) {
	var connection = new getLogosConnection();

	var jsonObject = JSON.parse(event.body);
	var jsonObj2 = JSON.parse(jsonObject);
	var blnInactivate = false;
	var blnNewRecord = false;
	var sql;
	var sql1;
	var sql2;
	var blnSkip = false;
	var dtNow = new Date();
	var dtSave = moment(dtNow);
	
	console.log('LabsByProfileSave: ', jsonObj2);
	if (jsonObj2.timezone !==undefined && jsonObj2.timezone !=="") {
		timezone = jsonObj2.timezone;
	}	
	
	if (jsonObj2.active !==undefined && jsonObj2.active !=="") {
		if (jsonObj2.active == "N") {
			blnInactivate = true;
		} else if (jsonObj2.recordid == undefined || jsonObj2.recordid == null || jsonObj2.recordid == "") {
			console.log('LabsByProfileSave - Insert record expect recordid = ' + jsonObj2.recordid);
			blnNewRecord = true;
		}
	} else {
		callback('Invalid data', null);
		blnSkip = true;	
	}

	if (blnInactivate) {
		sql = "Update logoshealth.lab set activeflag = 'N', modifiedby = " + jsonObj2.userid + " where labid = " + jsonObj2.recordid;
	} else if (blnNewRecord) {
		sql1 = "Insert into logoshealth.lab (";
		sql2 = "values (";

		if (jsonObj2.labnametext !==undefined) {
			sql1 = sql1 + "labnametext, "; 
			sql2 = sql2 +  "'" + jsonObj2.labnametext + "', ";
		}
		if (jsonObj2.labname !==undefined) {
			sql1 = sql1 + "labname, "; 
			sql2 = sql2 + jsonObj2.labname + ", ";
		}
		if (jsonObj2.labresult !==undefined) {
			sql1 = sql1 + "labresult, "; 
			sql2 = sql2 + "'" + jsonObj2.labresult + "', ";
		}
		if (jsonObj2.labunit !==undefined) {
			sql1 = sql1 + "labunit, "; 
			sql2 = sql2 + jsonObj2.labunit + ", ";
		}
		if (jsonObj2.labunittext !==undefined) {
			sql1 = sql1 + "labunittext, "; 
			sql2 = sql2 + "'" + jsonObj2.labunittext + "', ";
		}
		if (jsonObj2.lowerrange !==undefined) {
			sql1 = sql1 + "lowerrange, ";
			sql2 = sql2 + "'" + jsonObj2.lowerrange + "', ";
		}
		if (jsonObj2.upperrange !==undefined) {
			sql1 = sql1 + "upperrange, "; 
			sql2 = sql2 + "'" + jsonObj2.upperrange + "', ";
		}
		if (jsonObj2.confirmed !==undefined) {
			sql1 = sql1 + "confirmedflag, "; 
			sql2 = sql2 + "'" + jsonObj2.confirmed + "', ";
		}
		if (jsonObj2.profileid !==undefined && jsonObj2.userid !==undefined) {
			sql1 = sql1 + "profileid, createdby, modifiedby, dateofmeasure) ";
			sql2 = sql2 + jsonObj2.profileid + ", " + jsonObj2.userid + ", " + 
			  jsonObj2.userid + ", '"+  dtSave.format("YYYY-MM-DD HH:mm") + "')";
			sql = sql1 + sql2;			
		} else {
			callback('Invalid data', null);	
			blnSkip = true;	
		}
	} else {
		sql = "update logoshealth.lab set ";
		if (jsonObj2.labname !==undefined) {
			sql = sql + "labname = " + jsonObj2.labname + ", ";
		}
		if (jsonObj2.labnametext !==undefined) {
			sql = sql + "labnametext = " + "'" + jsonObj2.labnametext + "', ";
		}
		if (jsonObj2.labresult !==undefined) {
			sql = sql + "labresult = " + "'" + jsonObj2.labresult + "', ";
		}
		if (jsonObj2.labunit !==undefined) {
			sql = sql + "labunit = " + jsonObj2.labunit + ", ";
		}
		if (jsonObj2.labunittext !==undefined) {
			sql = sql + "labunittext = " + "'" + jsonObj2.labunittext + "', ";
		}
		if (jsonObj2.lowerrange !==undefined) {
			sql = sql + "lowerrange = " + "'" + jsonObj2.lowerrange + "', ";
		}
		if (jsonObj2.upperrange !==undefined) {
			sql = sql + "upperrange = " + "'" + jsonObj2.upperrange + "', ";
		}
		if (jsonObj2.confirmed !==undefined) {
			sql = sql + "confirmedflag = " + "'" + jsonObj2.confirmed + "', ";
		}
		if (jsonObj2.userid !==undefined && jsonObj2.recordid !==undefined) {
			sql = sql + "modifiedby = " + jsonObj2.userid + " where labid = " + jsonObj2.recordid;
		} else {
			callback('Invalid data', null);	
			blnSkip = true;	
		}
	}

	if (!blnSkip) {
		console.log('LabsByProfileSave - Final SQL: ' + sql);
		connection.query(sql,  function (err, results, fields) {
			if (err) {
				closeConnection(connection); //all is done so releasing the resources	
				callback(err, null);
			} else {
				closeConnection(connection); //all is done so releasing the resources
				callback("Success", null);
			}
		});			
	} else {
		console.log('Skipped');
	}
}
