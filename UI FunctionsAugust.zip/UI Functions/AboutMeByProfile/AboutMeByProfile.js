'use strict';

var mysql = require('mysql');
var moment = require('moment-timezone');
var timezone = "";
var pool;


exports.handler = (event, context, callback) => {
	var bodyJson;
	console.log('event: ', event);
	console.log('context: ', context);	

	pool = mysql.createPool({
		connectionLimit: 100,
		connectTimeout: 5000,
		acquireTimeout: 5000,
		multipleStatements: true,
		host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
		port      : '3306',
		user     : 'logosadmin', //yet to encrypt password and read from properties
		password : 'L0g0sH3alth', //yet to encrypt password and read from properties
		database: 'logoshealth',
		debug: false
	});    

	if (event.httpMethod == 'GET') { 
		console.log('GET method called');  
		AboutMeByProfile (event, function(err, response) {
			if (err) {
				console.log('Error from AboutMeByProfile: ' + err);
				bodyJson = JSON.stringify(err);
			} else {
				console.log('Results from AboutMeByProfile: ' + response);
				bodyJson = JSON.stringify(response);
			}
			var responsePackage = {
				"statusCode": 200,
				"headers": {
					"AboutMeByProfile": "Complete"
				},
				"body": bodyJson,
				"isBase64Encoded": false
			};
			closePool();	
			callback(null, responsePackage);
		});		
	  } else if (event.httpMethod == 'POST') {
		console.log('POST method called');  
		AboutMeByProfileSave (event, function(err, response) {
			if (err) {
				console.log('Error from AboutMeByProfileSave: ' + err);
				bodyJson = JSON.stringify(err);
			} else {
				console.log('Results from AboutMeByProfileSave: ' + response);
				bodyJson = JSON.stringify(response);
			}
			var responsePackage = {
				"statusCode": 200,
				"headers": {
					"AboutMeByProfile": "Complete"
				},
				"body": bodyJson,
				"isBase64Encoded": false
			};
			closePool();	
			callback(null, responsePackage);
		});		
	  } else {
		console.log('Wrong method called');  
		closePool();	
		callback('Wrong method called', null);  
	  }	
}

//Connection Mgmt Functions
function getLogosConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

function closePool() {
	pool.end();
}

//Feature 2: Finds profiles without GeoCoords -->  gets GeoCoords from Google Maps --> update GeoCoords 
//MM 02-07-2018 This function finds any restaurants without GeoCoords - cloned from findRestaurantsWithoutGeoCoords 
function AboutMeByProfile (event, callback) {
	var connection = new getLogosConnection();
	var sql = "SELECT p.profileid, p.accountid, pp.physicalprofileid, p.firstname, p.lastname, p.ssn, p.primaryflag, p.streetaddress, p.city, " +
	"p.state, p.zipcode, p.latitude, p.longitude, p.timezone, p.phonenumber, p.email, p.emergencycontact, p.emergencycontactphone, p.emergencycontactrelation, " + 
	"p.insurancename, p.insurancenumber, p.relationtoprimary, p.biologicalparent, p.medicalconsent, " + 
	"pp.birthdate, pp.age, pp.bloodtype, pp.rhfactor, pp.gender, pp.ethnicity, pp.species, pp.breed, p.activeflag, pp.confirmedflag " + 
	"FROM logoshealth.profile p, logoshealth.physicalprofile pp where p.profileid = pp.profileid and p.activeflag = 'Y'";

	var resultsItem;
	var raceItem;
	var primaryItem;
	var populars = [];
	var races = [];
	var skip = false;
	
	if(event.queryStringParameters !== undefined && event.queryStringParameters.profileid !== undefined  
	  && event.queryStringParameters.profileid !== "") {
		sql = sql + " and p.profileid = " + event.queryStringParameters.profileid;
	} else {
		skip = true;
		callback('Invalid query parameters', null);					
	}

	if (skip == false) {
	  console.log('Final SQL: ' + sql);
	  connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('AboutMeByProfile: The Error is: ', error);
			closeConnection(connection); //all is done so releasing the resources
			callback(error, null);
        } else {
            if (results !== null && results.length > 0) {
				//console.log('AboutMeByProfile - Result length count: ' + results.length);
				resultsItem = {
					'profileid':results[0].profileid,
					'accountid':results[0].accountid,
 					'physicalprofileid':results[0].physicalprofileid,
 					'firstname':results[0].firstname,
 					'lastname':results[0].lastname,
					'ssn':results[0].ssn,
					'primaryflag':results[0].primaryflag,
					'streetaddress':results[0].streetaddress,
					'city':results[0].city,
					'state':results[0].state,
					'zipcode':results[0].zipcode,
					'latitude' :results[0].latitude,
					'longitude' :results[0].longitude,
					'timezone':results[0].timezone,
					'phonenumber':results[0].phonenumber,
					'email':results[0].email,
					'emergencycontact':results[0].emergencycontact,
					'emergencycontactphone':results[0].emergencycontactphone,
					'emergencycontactrelation':results[0].emergencycontactrelation,
					'insurancename':results[0].insurancename,
					'insurancenumber':results[0].insurancenumber,
					'relationtoprimary':results[0].relationtoprimary,
					'biologicalparent':results[0].biologicalparent,
					'medicalconsent':results[0].medicalconsent,
					'birthdate':results[0].birthdate,
					'age':results[0].age,
					'bloodtype':results[0].bloodtype,
					'rhfactor':results[0].rhfactor,
					'gender':results[0].gender,
					'ethnicity':results[0].ethnicity,
					'species':results[0].species,
					'breed':results[0].breed,
					'active':results[0].activeflag,
					'confirmed':results[0].confirmedflag,
				};

				var sqlRace = "SELECT r.raceid, r.racecode, r.confirmedflag from logoshealth.race r where profileid = " + event.queryStringParameters.profileid +
				 " and r.activeflag = 'Y'";
				connection.query(sqlRace, function (error, results, fields) {
					if (error) {
						console.log('AboutMeByProfile: The Error is: ', error);
						closeConnection(connection); //all is done so releasing the resources
						callback(error, null);			
					} else {
						if (results !== null && results.length > 0) {
							for (var j = 0; j < results.length; j++) {
								raceItem = {
									'raceid':results[j].raceid,
									'racecode':results[j].racecode,	
									'confirmed':results[j].confirmedflag,	
								}
								races.push(raceItem); 
							}
							resultsItem.races = races;
						}	
						var sqlWeight = "select weightid, weight, unitofmeasure, confirmedflag from logoshealth.weight where profileid = " + event.queryStringParameters.profileid +
							" and activeflag = 'Y' order by createddate desc limit 1";
						connection.query(sqlWeight, function (error, results, fields) {
							if (error) {
								console.log('AboutMeByProfile - Get Weight: The Error is: ', error);
								closeConnection(connection); //all is done so releasing the resources
								callback(error, null);			
							} else {
								if (results !== null && results.length > 0) {
									var weightItem = {
										'weightid':results[0].weightid,
										'weight':results[0].weight,			   
										'unitofmeasure':results[0].unitofmeasure,		
										'confirmed':results[0].confirmedflag,	   
									}
									resultsItem.latestweight = weightItem;
								}
								var sqlHeight = "select heightid, height, feet, inches, confirmedflag from logoshealth.height where profileid = " + event.queryStringParameters.profileid +
								" and activeflag = 'Y' order by createddate desc limit 1";
								connection.query(sqlHeight, function (error, results, fields) {
									if (error) {
										console.log('AboutMeByProfile - Get Height: The Error is: ', error);
										closeConnection(connection); //all is done so releasing the resources
										callback(error, null);			
									} else {
										if (results !== null && results.length > 0) {
											var heightItem = {
												'heightid':results[0].heightid,
												'height':results[0].height,			   
												'feet':results[0].feet,		
												'inches':results[0].inches,		
												'confirmed':results[0].confirmedflag,	   
											}
											resultsItem.latestheight = heightItem;
										}
										if (resultsItem.primaryflag == 'N') {
											var sqlPrimary = "select profileid, firstname, streetaddress, city, state, zipcode, latitude, longitude, timezone, " +
											  "insurancename, insurancenumber from logoshealth.profile where primaryflag = 'Y' and activeflag = 'Y' and accountid = " +
											  resultsItem.accountid;
											connection.query(sqlPrimary, function (error, results, fields) {
												if (error) {
													console.log('AboutMeByProfile: The Error is: ', error);
													closeConnection(connection); //all is done so releasing the resources
													callback(error, null);			
												} else {
													primaryItem = {
														'profileid':results[0].profileid,
														'firstname':results[0].firstname,						
														'streetaddress':results[0].streetaddress,						
														'city':results[0].city,						
														'state':results[0].state,						
														'zipcode':results[0].zipcode,						
														'latitude':results[0].latitude,						
														'longitude':results[0].longitude,						
														'timezone':results[0].timezone,						
														'insurancename':results[0].insurancename,						
														'insurancenumber':results[0].insurancenumber,						
													}
													resultsItem.primaryuser = primaryItem;
													populars.push(resultsItem);
													closeConnection(connection); //all is done so releasing the resources	
													callback(null, populars);											
												}
											});	
										} else {
											populars.push(resultsItem);
											closeConnection(connection); //all is done so releasing the resources	
											callback(null, populars);									
										}
									}
								});
							}
						});	
					}
				});
			} else {
				closeConnection(connection); //all is done so releasing the resources	
				callback('No data found', null);					
			}
		}
	  });
	}	
}	

function AboutMeByProfileSave (event, callback) {
	var connection = new getLogosConnection();

	var jsonObject = JSON.parse(event.body);
	var jsonObj2 = JSON.parse(jsonObject);
	var blnInactivate = false;
	var blnNewRecord = false;
	var sqlMain;
	var sqlMain1;
	var sqlMain2;
	var sqlPP;
	var sqlPP1;
	var sqlPP2;
	var sqlLW;
	var sqlLW1;
	var sqlLW2;
	var sqlLH;
	var sqlLH1;
	var sqlLH2;
	var sqlRace;
	var sqlRace1;
	var sqlRace2;
	var sqls = [];
	var blnSkip = false;
	var dtNow = new Date();
	var dtSave = moment(dtNow);
	
	console.log('AboutMeByProfileSave: ', jsonObj2);
	if (jsonObj2.timezone !==undefined && jsonObj2.timezone !=="") {
		timezone = jsonObj2.timezone;
	}	
	
	if (jsonObj2.active !==undefined && jsonObj2.active !=="") {
		if (jsonObj2.active == "N") {
			blnInactivate = true;
		} else if (jsonObj2.profileid == undefined || jsonObj2.profileid == null || jsonObj2.profileid == "") {
			console.log('AboutMeByProfileSave - Insert record profileid = ' + jsonObj2.profileid);
			blnNewRecord = true;
		} else {
			console.log('Update for profileid: ' + jsonObj2.profileid + ' activeflag = ' + jsonObj2.active);
		}
	} else {
		callback('Invalid data', null);
		blnSkip = true;	
	}

	if (blnInactivate) {
		sqlMain = "Update logoshealth.profile set activeflag = NULL, modifiedby = " + jsonObj2.userid + " where profileid = " + jsonObj2.profileid;
		sqls.push(sqlMain);
		sqlPP = "Update logoshealth.physicalprofile set activeflag = 'N', modifiedby = " + jsonObj2.userid + " where physicalprofileid = " + jsonObj2.physicalprofileid;
		sqls.push(sqlPP);

		if (jsonObj2.latestweight !== undefined) {
			sqlLH = "Update logoshealth.weight set activeflag = 'N', modifiedby = " + jsonObj2.userid + " where weightid = " + jsonObj2.latestweight.weightid; 
			sqls.push(sqlLW);
		}
		if (jsonObj2.latestheight !== undefined) {
			sqlLH = "Update logoshealth.height set activeflag = 'N', modifiedby = " + jsonObj2.userid + " where heightid = " + jsonObj2.latestheight.heightid; 
			sqls.push(sqlLW);
		}
		if (jsonObj2.races !== undefined) {
			for (var j = 0; j < jsonObj2.races.length; j++) {
				sqlRace = "Update logoshealth.race set activeflag = 'N', modifiedby = " + jsonObj2.userid + " where raceid = " + jsonObj2.races[j].raceid;
				sqls.push(sqlRace);
			}
		}
	} else if (blnNewRecord) {
		sqlMain1 = "Insert into logoshealth.profile (";
		sqlMain2 = "values (";

		if (jsonObj2.accountid !==undefined) {
			sqlMain1 = sqlMain1 + "accountid, "
			sqlMain2 = sqlMain2 + jsonObj2.accountid + ", ";

			if (jsonObj2.firstname !==undefined) {
				sqlMain1 = sqlMain1 + "firstname, logosname, "
				sqlMain2 = sqlMain2 + "'" + jsonObj2.firstname + "', '" + jsonObj2.firstname + "', ";
			}	
			if (jsonObj2.lastname !==undefined) {
				sqlMain1 = sqlMain1 + "lastname, "
				sqlMain2 = sqlMain2 + "'" + jsonObj2.lastname + "', "; 
			}	
			if (jsonObj2.ssn !==undefined) {
				sqlMain1 = sqlMain1 + "ssn, "
				sqlMain2 = sqlMain2 + "'" + jsonObj2.ssn + "', ";
			}	
			if (jsonObj2.primaryflag !==undefined) {
				sqlMain1 = sqlMain1 + "primaryflag, "
				sqlMain2 = sqlMain2 + "'" + jsonObj2.primaryflag + "', ";
				if (jsonObj2.primaryflag == 'Y') {
					var sqlChangePrimary = "update logoshealth.profile set primaryflag = 'N' where accountid = " + jsonObj2.accountid + " and firstname <> '" + jsonObj2.firstname +
					  "' and activeflag = 'Y' and primaryflag = 'Y'";
					sqls.push(sqlChangePrimary);
				}
			}	
			if (jsonObj2.streetaddress !==undefined) {
				sqlMain1 = sqlMain1 + "streetaddress, "
				sqlMain2 = sqlMain2 + "'" + jsonObj2.streetaddress + "', ";
			}	
			if (jsonObj2.city !==undefined) {
				sqlMain1 = sqlMain1 + "city, "
				sqlMain2 = sqlMain2 + "'" + jsonObj2.city + "', ";
			}	
			if (jsonObj2.state !==undefined) {
				sqlMain1 = sqlMain1 + "state, "
				sqlMain2 = sqlMain2 + jsonObj2.state + ", ";
			}	
			if (jsonObj2.zipcode !==undefined) {
				sqlMain1 = sqlMain1 + "zipcode, "
				sqlMain2 = sqlMain2 + jsonObj2.zipcode + ", ";
			}	
			if (jsonObj2.timezone !==undefined) {
				sqlMain1 = sqlMain1 + "timezone, "
				sqlMain2 = sqlMain2 + "'" + jsonObj2.timezone + "', ";
			}	
			if (jsonObj2.latitude !==undefined) {
				sqlMain1 = sqlMain1 + "latitude, "
				sqlMain2 = sqlMain2 + jsonObj2.latitude + ", ";
			}	
			if (jsonObj2.longitude !==undefined) {
				sqlMain1 = sqlMain1 + "longitude, "
				sqlMain2 = sqlMain2 + jsonObj2.longitude + ", ";
			}	
			if (jsonObj2.phonenumber !==undefined) {
				sqlMain1 = sqlMain1 + "phonenumber, "
				sqlMain2 = sqlMain2 + jsonObj2.phonenumber + ", ";
			}	
			if (jsonObj2.email !==undefined) {
				sqlMain1 = sqlMain1 + "email, "
				sqlMain2 = sqlMain2 + "'" + jsonObj2.email + "', ";
			}	
			if (jsonObj2.emergencycontact !==undefined) {
				sqlMain1 = sqlMain1 + "emergencycontact, "
				sqlMain2 = sqlMain2 + "'" + jsonObj2.emergencycontact + "', ";
			}	
			if (jsonObj2.emergencycontactphone !==undefined) {
				sqlMain1 = sqlMain1 + "emergencycontactphone, "
				sqlMain2 = sqlMain2 + jsonObj2.emergencycontactphone + ", ";
			}	
			if (jsonObj2.emergencycontactrelation !==undefined) {
				sqlMain1 = sqlMain1 + "emergencycontactrelation, "
				sqlMain2 = sqlMain2 + "'" + jsonObj2.emergencycontactrelation + "', ";
			}	
			if (jsonObj2.insurancename !==undefined) {
				sqlMain1 = sqlMain1 + "insurancename, "
				sqlMain2 = sqlMain2 + "'" + jsonObj2.insurancename + "', ";
			}	
			if (jsonObj2.insurancenumber !==undefined) {
				sqlMain1 = sqlMain1 + "insurancenumber, "
				sqlMain2 = sqlMain2 + "'" + jsonObj2.insurancenumber + "', ";
			}	
			if (jsonObj2.relationtoprimary !==undefined) {
				sqlMain1 = sqlMain1 + "relationtoprimary, "
				sqlMain2 = sqlMain2 + jsonObj2.relationtoprimary + ", ";
			}	
			if (jsonObj2.biologicalparent !==undefined) {
				sqlMain1 = sqlMain1 + "biologicalparent, "
				sqlMain2 = sqlMain2 + "'" + jsonObj2.biologicalparent + "', ";
			}	
			if (jsonObj2.medicalconsent !==undefined) {
				sqlMain1 = sqlMain1 + "medicalconsent, "
				sqlMain2 = sqlMain2 + "'" + jsonObj2.medicalconsent + "', ";
			}	
			if (jsonObj2.confirmed !==undefined) {
				sqlMain1 = sqlMain1 + "confirmedflag, "
				sqlMain2 = sqlMain2 + "'" + jsonObj2.confirmed + "', ";
			}	
			if (jsonObj2.userid !==undefined) {
				sqlMain1 = sqlMain1 + "createdby, modifiedby) ";
				sqlMain2 = sqlMain2 + jsonObj2.userid + ", " + jsonObj2.userid + ")";
				sqlMain = sqlMain1 + sqlMain2;			
			} else {
				console.log('Invalid data for insert profile - no userid');
				callback('Invalid data', null);	
				blnSkip = true;	
			}
			if (!blnSkip) {
				console.log('Inserting new profile SQL Main: ' + sqlMain);
				connection.query(sqlMain,  function (err, results, fields) {
					if (err) {
						closeConnection(connection); //all is done so releasing the resources	
						callback(err, null);
					} else {
						closeConnection(connection); //all is done so releasing the resources
						var newProfileId = results.insertId;
						console.log('newProfileId: ' + newProfileId);
						sqlPP1 = "Insert into logoshealth.physicalprofile (profileid, ";
						sqlPP2 = "values (" + newProfileId + ", ";

						if (jsonObj2.birthdate !==undefined) {
							sqlPP1 = sqlPP1 + "birthdate, "
							sqlPP2 = sqlPP2 + "'" + jsonObj2.birthdate + "', ";
						}	
						if (jsonObj2.age !==undefined) {
							sqlPP1 = sqlPP1 + "age, "
							sqlPP2 = sqlPP2 + jsonObj2.age + ", ";
						}	
						if (jsonObj2.bloodtype !==undefined) {
							sqlPP1 = sqlPP1 + "bloodtype, "
							sqlPP2 = sqlPP2 + jsonObj2.bloodtype + ", ";
						}	
						if (jsonObj2.gender !==undefined) {
							sqlPP1 = sqlPP1 + "gender, "
							sqlPP2 = sqlPP2 + jsonObj2.gender + ", ";
						}	
						if (jsonObj2.ethnicity !==undefined) {
							sqlPP1 = sqlPP1 + "ethnicity, "
							sqlPP2 = sqlPP2 + jsonObj2.ethnicity + ", ";
						}	
						if (jsonObj2.species !==undefined) {
							sqlPP1 = sqlPP1 + "species, "
							sqlPP2 = sqlPP2 + jsonObj2.species + ", ";
						}	
						if (jsonObj2.breed !==undefined) {
							sqlPP1 = sqlPP1 + "breed, "
							sqlPP2 = sqlPP2 + "'" + jsonObj2.breed + "', ";
						}	
						if (jsonObj2.confirmed !==undefined) {
							sqlPP1 = sqlPP1 + "confirmedflag, "
							sqlPP2 = sqlPP2 + "'" + jsonObj2.confirmed + "', ";
						}	
						if (jsonObj2.userid !==undefined) {
							sqlPP1 = sqlPP1 + "createdby, modifiedby) ";
							sqlPP2 = sqlPP2 + jsonObj2.userid + ", " + jsonObj2.userid + ")";
							sqlPP = sqlPP1 + sqlPP2;			
							sqls.push(sqlPP);
						} else {
							console.log('Invalid data for insert physicalprofile - no userid');
							callback('Invalid data', null);	
							blnSkip = true;	
						}			
						if (jsonObj2.latestweight !== undefined) {
							sqlLW1 = "Insert into logoshealth.weight (profileid, " 
							sqlLW2 = "values ("  + newProfileId + ", ";

							if (jsonObj2.latestweight.weight !==undefined) {
								sqlLW1 = sqlLW1 + "weight, "
								sqlLW2 = sqlLW2 + jsonObj2.latestweight.weight + ", ";
							}	
							if (jsonObj2.latestweight.confirmed !==undefined) {
								sqlLW1 = sqlLW1 + "confirmedflag, "
								sqlLW2 = sqlLW2 + "'" + jsonObj2.latestweight.confirmed + "', ";
							}	
							if (jsonObj2.userid !==undefined) {
								sqlLW1 = sqlLW1 + "createdby, modifiedby, dateofmeasure) ";
								sqlLW2 = sqlLW2 + jsonObj2.userid + ", " + jsonObj2.userid + ", '" + dtSave.format("YYYY-MM-DD HH:mm") + "')";
								sqlLW = sqlLW1 + sqlLW2;			
								sqls.push(sqlLW);
							} else {
								console.log('Invalid data for insert weight - no userid');
								callback('Invalid data', null);	
								blnSkip = true;	
							}								
						}
						if (jsonObj2.latestheight !== undefined) {
							sqlLH1 = "Insert into logoshealth.height (profileid, " 
							sqlLH2 = "values ("  + newProfileId + ", ";

							if (jsonObj2.latestheight.feet !==undefined) {
								sqlLH1 = sqlLH1 + "feet, "
								sqlLH2 = sqlLH2 + jsonObj2.latestweight.feet + ", ";
							}	
							if (jsonObj2.latestheight.inches !==undefined) {
								sqlLH1 = sqlLH1 + "inches, "
								sqlLH2 = sqlLH2 + jsonObj2.latestweight.inches + ", ";
							}	
							if (jsonObj2.latestheight.confirmed !==undefined) {
								sqlLH1 = sqlLH1 + "confirmedflag, "
								sqlLH2 = sqlLH2 + "'" + jsonObj2.latestweight.confirmed + "', ";
							}	
							if (jsonObj2.userid !==undefined) {
								sqlLH1 = sqlLH1 + "createdby, modifiedby, dateofmeasure) ";
								sqlLH2 = sqlLH2 + jsonObj2.userid + ", " + jsonObj2.userid + ", '" + dtSave.format("YYYY-MM-DD HH:mm") + "')";
								sqlLH = sqlLH1 + sqlLH2;			
								sqls.push(sqlLH);
							} else {
								console.log('Invalid data for insert height - no userid');
								callback('Invalid data', null);	
								blnSkip = true;	
							}								
						}
						if (jsonObj2.races !== undefined) {
							for (var j = 0; j < jsonObj2.races.length; j++) {
								sqlRace1 = "Insert into logoshealth.height (profileid, " 
								sqlRace2 = "values ("  + newProfileId + ", ";

								if (jsonObj2.races[j].racecode !==undefined) {
									sqlRace1 = sqlRace1 + "racecode, "
									sqlRace2 = sqlRace2 + jsonObj2.races[j].racecode + ", ";
								}	
								if (jsonObj2.races[j].confirmed !==undefined) {
									sqlRace1 = sqlRace1 + "confirmedflag, "
									sqlRace2 = sqlRace2 + "'" + jsonObj2.races[j].confirmed + "', ";
								}	
								if (jsonObj2.userid !==undefined) {
									sqlRace1 = sqlRace1 + "createdby, modifiedby) ";
									sqlRace2 = sqlRace2 + jsonObj2.userid + ", " + jsonObj2.userid + ")";
									sqlRace = sqlRace1 + sqlRace2;			
									sqls.push(sqlRace);
								} else {
									console.log('Invalid data for insert race - no userid');
									callback('Invalid data', null);	
									blnSkip = true;	
								}			
							}
						}
					console.log('sqls count from profile insert: ' + sqls.length);
					if (!blnSkip && sqls !== undefined && sqls.length > 0) {
						var expectedCount = sqls.length;
						var actualCount = 0;
				
						for (var j = 0; j < sqls.length; j++) {
							if (sqls[j] !== undefined) {
								executeSQL (sqls[j], function(err, results) {
									if (err) {
										callback(err, null);	
									} else {
										actualCount = actualCount + 1;
										if (actualCount == expectedCount) {
											callback("Success", null);
										}
									}
								});	
							}
						}
					}						
				  }
				});			
			}
		} else {
			callback('Invalid data - missing accountid for profile insert', null);	
			blnSkip = true;	
		}
	} else {		
		sqlMain = "update logoshealth.profile set ";
		var blnUpdateMain  = false;
		if (jsonObj2.firstname !==undefined) {
			sqlMain = sqlMain + "firstname = '" + jsonObj2.firstname + "', ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.lasttname !==undefined) {
			sqlMain = sqlMain + "lasttname = '" + jsonObj2.lasttname + "', ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.ssn !==undefined) {
			sqlMain = sqlMain + "ssn = '" + jsonObj2.ssn + "', ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.primaryflag !==undefined) {
			sqlMain = sqlMain + "primaryflag = '" + jsonObj2.primaryflag + "', ";
			blnUpdateMain = true;
			if (jsonObj2.primaryflag == 'Y') {
				if (jsonObj2.primaryflag == 'Y') {
					var sqlChangePrimary = "update logoshealth.profile set primaryflag = 'N' where accountid = " + jsonObj2.accountid + " and profileid <> " + jsonObj2.profileid +
					  " and activeflag = 'Y' and primaryflag = 'Y'";
					sqls.push(sqlChangePrimary);
				}
			}
		}	
		if (jsonObj2.streetaddress !==undefined) {
			sqlMain = sqlMain + "streetaddress = '" + jsonObj2.streetaddress + "', ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.city !==undefined) {
			sqlMain = sqlMain + "city = '" + jsonObj2.city + "', ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.state !==undefined) {
			sqlMain = sqlMain + "state = " + jsonObj2.state + ", ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.zipcode !==undefined) {
			sqlMain = sqlMain + "zipcode = " + jsonObj2.zipcode + ", ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.timezone !==undefined) {
			sqlMain = sqlMain + "timezone = '" + jsonObj2.timezone + "', ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.latitude !==undefined) {
			sqlMain = sqlMain + "latitude = " + jsonObj2.latitude + ", ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.longitude !==undefined) {
			sqlMain = sqlMain + "longitude = " + jsonObj2.longitude + ", ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.phonenumber !==undefined) {
			sqlMain = sqlMain + "phonenumber = " + jsonObj2.phonenumber + ", ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.email !==undefined) {
			sqlMain = sqlMain + "email = '" + jsonObj2.email + "', ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.emergencycontact !==undefined) {
			sqlMain = sqlMain + "emergencycontact = '" + jsonObj2.emergencycontact + "', ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.emergencycontactphone !==undefined) {
			sqlMain = sqlMain + "emergencycontactphone = " + jsonObj2.emergencycontactphone + ", ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.emergencycontactrelation !==undefined) {
			sqlMain = sqlMain + "emergencycontactrelation = '" + jsonObj2.emergencycontactrelation + "', ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.insurancename !==undefined) {
			sqlMain = sqlMain + "insurancename = '" + jsonObj2.insurancename + "', ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.insurancenumber !==undefined) {
			sqlMain = sqlMain + "insurancenumber = '" + jsonObj2.insurancenumber + "', ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.relationtoprimary !==undefined) {
			sqlMain = sqlMain + "relationtoprimary = " + jsonObj2.relationtoprimary + ", ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.biologicalparent !==undefined) {
			sqlMain = sqlMain + "biologicalparent = '" + jsonObj2.biologicalparent + "', ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.medicalconsent !==undefined) {
			sqlMain = sqlMain + "medicalconsent = '" + jsonObj2.medicalconsent + "', ";
			blnUpdateMain = true;
		}	
		if (jsonObj2.confirmed !==undefined) {
			sqlMain = sqlMain + "confirmedflag = '" + jsonObj2.confirmed + "', ";
			blnUpdatePP = true;
		}	

		if (blnUpdateMain) {
			if (jsonObj2.userid !==undefined && jsonObj2.profileid !==undefined) {
				sqlMain = sqlMain + "modifiedby = " + jsonObj2.userid + " where profileid = " + jsonObj2.profileid;
				sqls.push(sqlMain);
			} else {
				callback('Invalid data - no profile or user id', null);	
				blnSkip = true;	
			}	
		}

		sqlPP = "update logoshealth.physicalprofile set ";
		var blnUpdatePP  = false;

		if (jsonObj2.birthdate !==undefined) {
			sqlPP = sqlPP + "birthdate = '" + jsonObj2.birthdate + "', ";
			blnUpdatePP = true;
		}	
		if (jsonObj2.age !==undefined) {
			sqlPP = sqlPP + "age = " + jsonObj2.age + ", ";
			blnUpdatePP = true;
		}	
		if (jsonObj2.bloodtype !==undefined) {
			sqlPP = sqlPP + "bloodtype = " + jsonObj2.bloodtype + ", ";
			blnUpdatePP = true;
		}	
		if (jsonObj2.gender !==undefined) {
			sqlPP = sqlPP + "gender = " + jsonObj2.gender + ", ";
			blnUpdatePP = true;
		}	
		if (jsonObj2.ethnicity !==undefined) {
			sqlPP = sqlPP + "ethnicity = " + jsonObj2.ethnicity + ", ";
			blnUpdatePP = true;
		}	
		if (jsonObj2.species !==undefined) {
			sqlPP = sqlPP + "species = " + jsonObj2.species + ", ";
			blnUpdatePP = true;
		}	
		if (jsonObj2.breed !==undefined) {
			sqlPP = sqlPP + "breed = '" + jsonObj2.breed + "', ";
			blnUpdatePP = true;
		}	
		if (jsonObj2.confirmed !==undefined) {
			sqlPP = sqlPP + "confirmedflag = '" + jsonObj2.confirmed + "', ";
			blnUpdatePP = true;
		}	
		if (blnUpdatePP) {
			if (jsonObj2.userid !==undefined && jsonObj2.physicalprofileid !==undefined) {
				sqlPP = sqlPP + "modifiedby = " + jsonObj2.userid + " where physicalprofileid = " + jsonObj2.physicalprofileid;
				sqls.push(sqlPP);
			} else {
				callback('Invalid data - no physicalprofile or user id', null);	
				blnSkip = true;	
			}	
		}

		if (jsonObj2.latestweight !== undefined) {
			if (jsonObj2.latestweight.weightid !== undefined) {
				sqlLW = "update logoshealth.weight set "; 
				if (jsonObj2.latestweight.weight !==undefined) {
					sqlLW = sqlLW + "weight = " + jsonObj2.latestweight.weight + ", ";
				}	
				if (jsonObj2.latestweight.confirmed !==undefined) {
					sqlLW = sqlLW + "confirmedflag = '" + jsonObj2.latestweight.confirmed + "', ";
				}	
				if (jsonObj2.latestweight.active !==undefined) {
					sqlLW = sqlLW + "activeflag = '" + jsonObj2.latestweight.active + "', ";
				}	
				if (jsonObj2.userid !==undefined) {
					sqlLW = sqlLW + "modifiedby = " + jsonObj2.userid + " where weightid = " + jsonObj2.latestweight.weightid;
					sqls.push(sqlLW);
				} else {
					callback('Invalid data', null);	
					blnSkip = true;	
				}				
			} else {
				sqlLW1 = "Insert into logoshealth.weight (profileid, "; 
				sqlLW2 = "values ("  + jsonObj2.profileid + ", ";
	
				if (jsonObj2.latestweight.weight !==undefined) {
					sqlLW1 = sqlLW1 + "weight, "
					sqlLW2 = sqlLW2 + jsonObj2.latestweight.weight + ", ";
				}	
				if (jsonObj2.latestweight.confirmed !==undefined) {
					sqlLW1 = sqlLW1 + "confirmedflag, "
					sqlLW2 = sqlLW2 + "'" + jsonObj2.latestweight.confirmed + "', ";
				}	
				if (jsonObj2.userid !==undefined) {
					sqlLW1 = sqlLW1 + "createdby, modifiedby, dateofmeasure) ";
					sqlLW2 = sqlLW2 + jsonObj2.userid + ", " + jsonObj2.userid + ", '" + dtSave.format("YYYY-MM-DD HH:mm") + "')";
					sqlLW = sqlLW1 + sqlLW2;			
					sqls.push(sqlLW);
				} else {
					callback('Invalid data', null);	
					blnSkip = true;	
				}									
			}
		}

		if (jsonObj2.latestheight !== undefined) {
			if (jsonObj2.latestheight.heightid !== undefined) {
				var sqlHW = "update logoshealth.height set "; 
				if (jsonObj2.latestweight.feet !==undefined) {
					sqlHW = sqlHW + "feet = " + jsonObj2.latestweight.feet + ", ";
				}	
				if (jsonObj2.latestweight.inches !==undefined) {
					sqlHW = sqlHW + "inches = " + jsonObj2.latestweight.inches + ", ";
				}	
				if (jsonObj2.latestheight.confirmed !==undefined) {
					sqlHW = sqlHW + "confirmedflag = '" + jsonObj2.latestheight.confirmed + "', ";
				}	
				if (jsonObj2.latestheight.active !==undefined) {
					sqlHW = sqlHW + "activeflag = '" + jsonObj2.latestheight.active + "', ";
				}	
				if (jsonObj2.userid !==undefined) {
					sqlHW = sqlHW + "modifiedby = " + jsonObj2.userid + " where heightid = " + jsonObj2.latestheight.heightid;
					sqls.push(sqlHW);
				} else {
					callback('Invalid data no userid', null);	
					blnSkip = true;	
				}				
			} else {
				sqlLH1 = "Insert into logoshealth.height (profileid, " 
				sqlLH2 = "values ("  + jsonObj2.profileid + ", ";
	
				if (jsonObj2.latestheight.feet !==undefined) {
					sqlLH1 = sqlLH1 + "feet, "
					sqlLH2 = sqlLH2 + jsonObj2.latestheight.feet + ", ";
				}	
				if (jsonObj2.latestheight.inches !==undefined) {
					sqlLH1 = sqlLH1 + "inches, "
					sqlLH2 = sqlLH2 + jsonObj2.latestheight.inches + ", ";
				}	
				if (jsonObj2.latestheight.confirmed !==undefined) {
					sqlLH1 = sqlLH1 + "confirmedflag, "
					sqlLH2 = sqlLH2 + "'" + jsonObj2.latestheight.confirmed + "', ";
				}	
				if (jsonObj2.userid !==undefined) {
					sqlLH1 = sqlLH1 + "createdby, modifiedby, dateofmeasure) ";
					sqlLH2 = sqlLH2 + jsonObj2.userid + ", " + jsonObj2.userid + ", '" + dtSave.format("YYYY-MM-DD HH:mm") + "')";
					sqlLH = sqlLH1 + sqlLH2;			
					sqls.push(sqlLH);
				} else {
					callback('Invalid data', null);	
					blnSkip = true;	
				}									
			}			
		}

		if (jsonObj2.races !== undefined) {
			for (var j = 0; j < jsonObj2.races.length; j++) {
				if (jsonObj2.races[j].raceid !== undefined) {
					sqlRace = "update logoshealth.race set "; 
					if (jsonObj2.races[j].racecode !==undefined) {
						sqlRace = sqlRace + "racecode = " + jsonObj2.races[j].racecode + ", ";
					}	
					if (jsonObj2.races[j].confirmed !==undefined) {
						sqlRace = sqlRace + "confirmedflag = " + "'" + jsonObj2.races[j].confirmed + "', ";
					}	
					if (jsonObj2.races[j].active !==undefined) {
						sqlRace = sqlRace + "activeflag = " + "'" + jsonObj2.races[j].active + "', ";
					}	
					if (jsonObj2.userid !==undefined) {
						sqlRace = sqlRace + "modifiedby = " + jsonObj2.userid + " where raceid = " + jsonObj2.races[j].raceid;
						sqls.push(sqlRace);
					} else {
						callback('Invalid data', null);	
						blnSkip = true;	
					}								
				} else {
					sqlRace1 = "Insert into logoshealth.race (profileid, " 
					sqlRace2 = "values ("  + jsonObj2.profileid + ", ";
	
					if (jsonObj2.races[j].racecode !==undefined) {
						sqlRace1 = sqlRace1 + "racecode, "
						sqlRace2 = sqlRace2 + jsonObj2.races[j].racecode + ", ";
					}	
					if (jsonObj2.races[j].confirmed !==undefined) {
						sqlRace1 = sqlRace1 + "confirmedflag, "
						sqlRace2 = sqlRace2 + "'" + jsonObj2.races[j].confirmed + "', ";
					}	
					if (jsonObj2.userid !==undefined) {
						sqlRace1 = sqlRace1 + "createdby, modifiedby) ";
						sqlRace2 = sqlRace2 + jsonObj2.userid + ", " + jsonObj2.userid + ")";
						sqlRace = sqlRace1 + sqlRace2;			
						sqls.push(sqlRace);
					} else {
						callback('Invalid data', null);	
						blnSkip = true;	
					}								
				}
			}
		}
	}

	if (!blnSkip && sqls !== undefined && sqls.length > 0) {
		var expectedCount = sqls.length;
		var actualCount = 0;

		for (var j = 0; j < sqls.length; j++) {
			if (sqls[j] !== undefined) {
				executeSQL (sqls[j], function(err, results) {
					if (err) {
						callback(err, null);	
					} else {
						actualCount = actualCount + 1;
						if (actualCount == expectedCount) {
							callback("Success", null);
						}
					}
				});	
			}
		}
	} else {
		console.log('Skipped');
		console.log('sqls: ', sqls);
	}
}

function executeSQL (sql, callback) {
	console.log('executeSQL: ' + sql);
	pool.getConnection(function(err, conn) {
		if (err) {
			console.log('Execute SQL error: ', err);
		} else {
			conn.query(sql, function (error, results, fields) {
				if (error) {
					console.log('executeSQL: The Error is: ', error);
					conn.release();
					callback(error, null);
				} else {
					conn.release();
					callback(null, 'Success');
				}
			});	
		}
	});
}
