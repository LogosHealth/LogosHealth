/**
 * LogosHealth App Database Utility. 
 * This Util has all support functions for DB operations, uses SQL driver supported classes & utilities for persistence 
 * Copyright Logos Health, Inc
 * 
 */

//global variables
var mysql = require('mysql');
var helper = require('./LogosHelper');

/**
 * Create a new Connection instance.
 * @param {object|string} config Configuration or connection string for new MySQL connection
 * @return {Connection} A new MySQL connection
 * @public
 */
exports.getDBConnection = function getDBConnection() {
  	console.log(' DBUtils.getDBConnection >>>>>>');
    return getLogosConnection();
};

/**
 * Closes an existing connection.
 * @param {object|string} an active connection object
 * @return {boolean} Whether connection is closed or not
 * @public
 */
exports.closeDBConnection = function closeDBConnection(connection) {
  console.log(' DBUtils.closeDBConnection >>>>>>');
  closeConnection();
  return true;
};

/**
 * Closes an existing connection.
 * @param {object|string} an active connection object
 * @return {boolean} Whether connection is closed or not
 * @public
 */
exports.getAccountIdFromEmail = function getAccountIdFromEmail(email, session, callback) {
  console.log(' DBUtils.getAccountIdFromEmail >>>>>>');
  loadAccountIDFromEmail(email, session, callback);
};

/**
 * Debugs class instantiation.
 * @param {none} 
 * @return {boolean} Function could be called
 * @public
 */
exports.getAllUserAccounts = function getAllUserAccounts() {
  console.log(' DBUtils.getAllUserAccounts >>>>>>');
  return loadUserAccounts();
};

/**
 * Debugs class instantiation.
 * @param {none} 
 * @return {boolean} Function could be called
 * @public
 */
exports.checkClassAccess = function checkClassAccess() {
  console.log(' DBUtils.checkClassAccess new >>>>>>');
  return true;
};

/**
 * Debugs class instantiation.
 * @param {none} 
 * @return {boolean} Function could be called
 * @public
 */
exports.verifyUserProfile = function verifyUserProfile(usrName, accountId, session, callback) {
  console.log(' DBUtils.verifyUserProfile >>>>>>');
  return getUserProfileByName(usrName, accountId, session, callback);
};

/**
 * Debugs class instantiation.
 * @param {none} 
 * @return {boolean} Function could be called
 * @public
 */
exports.readDictoinaryId = function readDictoinaryId(qnaObj, value, processor, session, callback) {
  console.log(' DBUtils.readDictoinaryId >>>>>>');
  return getDictionaryId(qnaObj, value, processor, session, callback);
};

exports.validateData = function validateData(qnaObj, value, processor, session, callback) {
  console.log(' DBUtils.validateData >>>>>>');
  return validateUserInput(qnaObj, value, processor, session, callback);
};

/**
 * @public name is getScriptDetails
 * @VG 2/26 | Pass the script as the param to get all possible questions
 */
exports.readQuestsionsForBranch = function readQuestsionsForBranch(questionId, scriptName, slotValue, session, callback) {
  	console.log(' DBUtils.readQuestsionsForBranch >>>>>>' +scriptName);
  	getScriptDetails(questionId, scriptName, slotValue, session, callback, false);
};

/**
 * @public
 * @VG 2/28 | Expects session information as a user response passed here to create a profile
 */
//MM 6-10-17 Changed external name to saveResponse to be more accurate in description - changed internal name to saveAnswer to be more accurate in description
exports.saveResponse = function saveResponse(qnaObj, session, callback){
  	console.log(' DBUtils.saveAnswer >>>>>>'+qnaObj.answer);
  	saveAnswer(qnaObj, session, callback);
};

/**
 * @public
 * @VG 2/28 | Expects session information as a user response passed here to create a profile
 */
exports.updateEventDetails = function updateEventDetails(qnaObj, eventQnA, answer, session, callback){
  	console.log(' DBUtils.updateSubProfileDetails >>>>>>'+qnaObj.answer);
  	setEventDetails(qnaObj, eventQnA, answer, session, callback);
};

/**
 * @public
 * @VG 3/13 | Manages Profile based script context in STAGING Table
 */
 
 
exports.setScriptContext = function setScriptContext(profileID, scriptID, scriptStep) {
  	console.log(' DBUtils.setScriptContext >>>>>>');
  	setScriptContext(profileID, scriptID, scriptStep);
 };
 
 
//VG 4/13|Purpose: Set the STG tables with processed information
//MM 6-10-17 Added scriptName variable to stgScript insert
function setTranscriptDetailsParent(newRec, qnaObj, session, callback){
    console.log("DBUtil.setTranscriptDetailsParent called with param >>>>> "+newRec);
	//Check if Staging has any record or not
    //var newRec = getStagingParentId(resArr, qnaObjArr, slotVal, session, callback);
    var connection = getLogosConnection();
	var sessionAttributes = session.attributes;
    var profileId = sessionAttributes.profileid;
	var updateSQL = '';
	
	
	
	console.log('Unique Step ID: ' + qnaObj.uniqueStepId + ', minScriptID: ' + sessionAttributes.minScriptId);
	
	//MM 6-10-17 Changed logic to only create a new parent staging record if you are on the first step of an interview
	//newRec will pass through to the Child Staging Table
	//Deprecated genStagingParentID because of stgScriptId attribute and results.insertId
	
    if (qnaObj.uniqueStepId == sessionAttributes.minScriptId) {
        var stgRec = {profileid:profileId, scriptname:session.attributes.scriptName,uniquestepid:qnaObj.uniqueStepId,createdby:profileId,modifiedby:profileId};
		console.log('STG REC: ', stgRec);
        // 1. Insert into STG_Script table
        connection.query('Insert into logoshealth.stg_script Set ?',stgRec, function (error, results, fields) {
	    	if (error) {
            	console.log('The Error in insert is: ', error);
        	} else {
				closeConnection(connection); //all is done so releasing the resources
				sessionAttributes.stgScriptId = results.insertId;
				console.log('STG_SCRIPT successfully record created!!  ID = '+sessionAttributes.stgScriptId);
				setTranscriptDetailsChild(newRec, sessionAttributes.stgScriptId, qnaObj, session, callback);
        		//getStagingParentId(newRec, qnaObj, session, callback);
			}
        	
		});
    }
    else {
        console.log("DBUtil.setTranscriptDetailsParent Into the else condition: Is New Record? >>>>> "+newRec);
		
		//MM 6-10-17 Check if script has completed - IF so, marking staging record as complete and goto main menu
		if (qnaObj.uniqueStepId == sessionAttributes.maxScriptId - 1) {
			//MM 6-10-17 ***Automatically Confirm Profile for demo purposes***
			
			updateSQL = "Update logoshealth.stg_script Set uniquestepid=" + sessionAttributes.maxScriptId + ", complete = 'Y' where stg_scriptid="+sessionAttributes.stgScriptId;
            console.log('STG Complete loop, ' + updateSQL);
        	connection.query(updateSQL,function(error, results,fields) {
        		if (error) {
            		console.log('The Error in update is: ', error);
        		} else {
					closeConnection(connection); //all is done so releasing the resources
					//MM 6-11-17 Script is complete respond with confirmation and set currentProcessor to Main Menu
					sessionAttributes.currentProcessor = 5;
					sessionAttributes.scriptComplete = true;
					
					//MM 6-14-17 Adding "Prototype" functionality to confirm user once profile create is complete to allow user to continue to additional interviews 
					if (sessionAttributes.scriptName == 'Create a New Primary Profile' || sessionAttributes.scriptName == 'Create a New Profile - Not primary - User adding own record'){
						setProfileConfirmed(newRec, sessionAttributes.stgScriptId, qnaObj, session, callback);
					} else{
						setTranscriptDetailsChild(newRec, sessionAttributes.stgScriptId, qnaObj, session, callback);
						//getStagingParentId(newRec, qnaObj, session, callback);	
					}
					
				  }
        		});				
			
		} else {
			updateSQL = "Update logoshealth.stg_script Set uniquestepid="+qnaObj.uniqueStepId+" where stg_scriptid="+sessionAttributes.stgScriptId;
            console.log('STG Update loop,  '+ sessionAttributes.stgScriptId);
	       	connection.query(updateSQL,function(error, results,fields) {
        		if (error) {
            		console.log('The Error in update is: ', error);
        		} else {
					console.log('The record updated into STG_SCRIPT successfully and now calling STG_Record table function!!');
					closeConnection(connection); //all is done so releasing the resources
					setTranscriptDetailsChild(newRec, sessionAttributes.stgScriptId, qnaObj, session, callback);
					//getStagingParentId(newRec, qnaObj, session, callback);
					}
        		});						
			}
		
    	}
}//function ends here

//VG 4/13|Purpose: Set the STG tables with processed information 
//keyID will be the key from parent table STG_Script table
//MM 6-10-17 Bypass loadcreate and go directly to getScriptDetails for the next question.  The parent call handles if the script has been completed so no need to handle here.
function setTranscriptDetailsChild(newRec, keyId, qnaObj, session, callback){
   // console.log("DBUtil.setTranscriptDetailsChild called with param >>>>> "+keyId);
	var sessionAttributes = session.attributes;
	var questionId;
    
	if(qnaObj !==null){
		console.log('DBUtil.setTranscriptDetailsChild qnaObj', qnaObj);			
	} else{
		console.log('DBUtil.setTranscriptDetailsChild qnaObj is null');					
	}
		
	
    //Only insert when the table changes
    if (newRec) {    
        var connection = getLogosConnection();
        var sessionAttributes = session.attributes;
        var profileId = sessionAttributes.profileid;
        var stgRec = {stg_scriptid:keyId, table:qnaObj.answerTable,recordid:sessionAttributes.tableId,createdby:profileId,modifiedby:profileId};
		
        // 1. Insert into STG_Record table
            console.log('STG Child Intert loop', stgRec);
			connection.query('Insert into logoshealth.stg_records Set ?',stgRec, function (error, results, fields) {
			if (error) {
				console.log('The Error is: ', error);
			} else {
				console.log('The record inserted into STG_RECORDS successfully!!');
				closeConnection(connection); //all is done so releasing the resources
				if (qnaObj.eventSpecific !== null && qnaObj.eventSpecific.toLowerCase() == 'y') {
    				//console.log("DBUtil.setTranscriptDetailsChild GetEventDetails Loop1 ");
					getEventDetails(qnaObj, session, callback);
				} else {
					questionId = qnaObj.uniqueStepId + 1;
					getScriptDetails(questionId, sessionAttributes.scriptName, sessionAttributes.logosname, session, callback, false);
					//loadProfileCreateContinueFromStaging(session.attributes.logosname, session.attributes.profileid, session.attributes.userHasProfile, session.attributes.profileComplete, session, callback);
				}
			}
			
			});
    } else {
		//********Check w/ Vikram concerning logic in this loop****************
    	console.log('DBUtil.setTranscriptDetailsChild Is Event Specific:' + qnaObj.eventSpecific.toLowerCase());
    	//console.log('DBUtil.setTranscriptDetailsChild eventScriptSeq:' + qnaObj.eventQNArr.eventScriptSeq);
    	//console.log('DBUtil.setTranscriptDetailsChild maxEventSeq:' + qnaObj.eventQNArr.maxEventSeq);
		
		//MM 6-13-17 If this is the last event driven question in interview, move to next main question.  Otherwise, loop to next event driven question
		if (qnaObj.eventSpecific !== null && qnaObj.eventSpecific.toLowerCase() == 'y') {
			if(!isEmpty(qnaObj.eventQNArr) && qnaObj.eventQNArr.eventScriptSeq == qnaObj.eventQNArr.maxEventSeq && qnaObj.eventQNArr.eventScriptSeq > 0){
				questionId = qnaObj.uniqueStepId + 1;
				getScriptDetails(questionId, sessionAttributes.scriptName, sessionAttributes.logosname, session, callback, false);				
			} else {
				getEventDetails(qnaObj, session, callback);			
			}
				
		} else {
    		console.log("DBUtil.setTranscriptDetailsChild GetEventDetails Loop4 ");
			questionId = qnaObj.uniqueStepId + 1;
			getScriptDetails(questionId, sessionAttributes.scriptName, sessionAttributes.logosname, session, callback, false);
			//loadProfileCreateContinueFromStaging(session.attributes.logosname, session.attributes.profileid, session.attributes.userHasProfile, session.attributes.profileComplete, session, callback);
		}
	}
    
}//function ends here

function setProfileConfirmed(newRec, keyId, qnaObj, session, callback){
   // console.log("DBUtil.setTranscriptDetailsChild called with param >>>>> "+keyId);
	var sessionAttributes = session.attributes;
	var questionId;
    var connection = getLogosConnection();
    var profileId = sessionAttributes.profileid;
		
        // 1. Insert into STG_Record table
        console.log('Enter setProfileConfirmed');
		connection.query("Update logoshealth.profile Set confirmedflag = 'Y' where profileid = "+ profileId, function (error, results, fields) {
		if (error) {
			console.log('The Error is: ', error);
		} else {
			console.log('setProfileConfirmed successful!!');
			closeConnection(connection); //all is done so releasing the resources
			setTranscriptDetailsChild(newRec, sessionAttributes.stgScriptId, qnaObj, session, callback);
			}
			
		});
}//function ends here


function getStagingParentId(newRec, qnaObj, session, callback) {
	console.log("DBUtil.getStagingParentId called to get Staging script ID for value >>>  ");
	var connection = getLogosConnection();
	var stgId = "";
	
	var sessionAttributes = session.attributes;
    var profileId = sessionAttributes.profileid;
	
	var query = "select stg_scriptid from stg_script where profileid ="+profileId+" and uniquestepid="+qnaObj.uniqueStepId;
	console.log("DBUtil.getStagingParentId Select Query is >>> "+query);
	
	connection.query(query, function (error, results, fields) {
		if (error) {
			console.log("DBUtil.getStagingParentId - Database QUERY ERROR >>>> ");
		} else {
			console.log('DBUtil.getStagingParentId - Query results '+results.length);
			
			if (results !== null && results.length > 0) {
                stgId = results[0].stg_scriptid;
				sessionAttributes.stgScriptId = stgId;
       			console.log("DBUtil.getStagingParentId - Script ID retrieved as >>>> "+stgId);
    			
    			setTranscriptDetailsChild(newRec, stgId, qnaObj, session, callback);
            } else {
            	console.log("DBUtil.getDictionaryId - RegEx threw error for user input >>>> "+tempObj.errResponse);
    			//process error response
    			helper.processErrResponse("Couldn't find Staging Script Error - Admin Error ", processor, session, callback);
            }
		}
		closeConnection(connection); //all is done so releasing the resources
	});
}

//VG 2/25|Purpose: Insert a new Account Information in DB
function createNewAccountIDFromEmail(vEmail, session, callback, connection)
{
	var accountRec = {email:vEmail, password:'vgtiger',createdby:'1',modifiedby:'1'};
	connection.query('Insert into logoshealth.Account Set ?',accountRec, function (error, results, fields) {
	if (error) {
            console.log('The Error is: ', error);
        } else {
			console.log('The record seems inserted successfully and now calling LoadAccountIDFromEmail again!!');
			loadAccountIDFromEmail(vEmail, session, callback); //Semi-Recursive call. New buzzword from VG.
		}
	});
}

//VG 5/5|Purpose: Read the answers and Insert/Update the eventDetails table
function setEventDetails(qnaObj, eventQnA, answer, session, callback) {
        console.log("DBUtil.setEventDetails for >>>>> "+answer);
        var connection = getLogosConnection();
        var sessionAttributes = session.attributes;
        
        var profileId = sessionAttributes.profileid;
        var primaryProfileId = sessionAttributes.primaryProfileId;
        
        var logosname = sessionAttributes.logosname;
        var insertRec;
        console.log("DBUtil.setEventDetails for >>>>> Answer table "+eventQnA.answerTable);
        console.log("DBUtil.setEventDetails for >>>>> Answer Field  "+eventQnA.answerField);
        
        var tblName = eventQnA.answerTable;
        var vFields = eventQnA.answerField;
        
       if (tblName !== null && tblName !== "") { 
		   //Check if event fuction field is present
		   if(eventQnA.insertnewrow == 'Y') {
				vFields=vFields.split(","); //This will split based on the comma
				insertRec = "Insert into "+tblName+"(createdby,modifiedby";
				for (var i = 0; i < vFields.length; i++) {
					console.log('The vField value in: DBUtil.setEventDetails - ' + tblName+' >> and field split '+vFields[i]);
					insertRec = insertRec+","+vFields[i];
				}
				insertRec=insertRec+") values('1','1','"+eventQnA.answer+"')";
				console.log("DBUtil.setEventDetails - Final Insert STMT >> "+insertRec);
				connection = getLogosConnection();
				connection.query(insertRec, function (error, results, fields) {
					if (error) {
						console.log('The Error is: DBUtil.saveAnswer INSERT- ', error);
					} else {
							console.log('The record INSERTED successfully from event function!!');
							closeConnection(connection);
							processEventFunction(qnaObj, eventQnA, answer, session, callback);
					}
				});
			} else  {   //This is for update
				var updateRec="Update "+tblName+" Set "+vFields+" ='"+answer+"' Where "+eventQnA.answerKeyField+"="+profileId; //resArr.answerFieldValue;
				console.log("DBUtil.setEVENTDetails - Update STMT >> ",updateRec);
				connection = getLogosConnection();
				connection.query(updateRec, function (error, results, fields) {
					if (error) {
						console.log('The Error is: DBUtil.setEventDetails UPDATE- ', error);
					} else  {
						console.log('The record UPDATED successfully from DBUtil.setEventDetails !!');
						closeConnection(connection);
						processEventFunction(qnaObj, eventQnA, answer, session, callback);
					}
				});
			}
		} //Close of tbl name check
            
} //Function setEventDetails ends here

function processEventFunction(qnaObj, eventQnA, answer, session, callback) {
	console.log('processEventFunction: Even function called >>> ');
	
	var profileId = session.attributes.profileid;
    var primaryProfileId = session.attributes.primaryProfileId;
	var questionId = 0;
	
	if (eventQnA.eventFunction!==null && eventQnA.eventFunction != ""){
	
		var vEvent = eventQnA.eventFunction.replace(/fromprofile/gi, "'"+primaryProfileId+"'");
		vEvent = vEvent.replace(/toprofile/gi, "'"+profileId+"'");  
		//vEvent = vEvent.replace(/physicalprofileidvalue/gi, "'"+eventQnA.answerKeyField+"'");  
		
		console.log('processEventFunction: The eventFunction post REPLACE is '+vEvent);
		
		connection = getLogosConnection();
		connection.query(vEvent,function(error,results,fields) {
			if(error)  {
				console.log('The Error is: DBUtil.processEventFunction executing - ', error);
			} else {
				console.log('processEventFunction: The EventFuction value executed successfully: DBUtil.processEventFunction');
				closeConnection(connection);
				setTranscriptDetailsParent(false, qnaObj, session, callback);
			}
		});
		//MM 6-13-17 If this is the last seq in event script, move back to main script.  Otherwise move to the next event seq
		console.log('processEventFunction: EventScriptSeq '+qnaObj.eventQNArr.eventScriptSeq);
		console.log('processEventFunction: MaxEventSeq '+qnaObj.eventQNArr.maxEventSeq);
		if(qnaObj.eventQNArr.eventScriptSeq == qnaObj.eventQNArr.maxEventSeq){
			questionId = qnaObj.uniqueStepId + 1;
			getScriptDetails(questionId, session.attributes.scriptName, session.attributes.logosname, session, callback, false);
		} else {
			getEventDetails(qnaObj, session, callback);
		}
    }  else {
    	console.log('processEventFunction: INTO the else condition >>>> ');
    	setTranscriptDetailsParent(false, qnaObj, session, callback); 
    }
}

//VG 4/30|Purpose: To pull event based questions
function getEventDetails(qnaObj, session, callback) {
	console.log("DBUtil.getEventDetails called with param >>>>> SQL Query is " +qnaObj.questionId);
	
	var questionId = qnaObj.questionId ;
	var answerFieldValue = qnaObj.answerFieldValue==null?"":qnaObj.answerFieldValue;
	var sessionAttributes = session.attributes;
	var connection = getLogosConnection();
    var vSQL;
	var mainQuestionId;
		
   	console.log('getEventDetails: eventScriptSeq >>>> ' + qnaObj.eventQNArr.eventScriptSeq);
	//MM 6-13-17 - Added functionality to iterate to the next sequence in the event script has already been triggered.  Otherwise, load first script if it is there 
    if(!isEmpty(qnaObj.eventQNArr)){
		//MM 6-13-17 Get the next event driven question by increasing the event sequence
		qnaObj.eventQNArr.eventScriptSeq = qnaObj.eventQNArr.eventScriptSeq + 1; 
		vSQL="select * from logoshealth.eventquestion where questionid="+questionId+ " and lower(event)='"+qnaObj.eventQNArr.event+"' and eventscriptsequence = "+qnaObj.eventQNArr.eventScriptSeq;		
	} else {
		vSQL="select * from logoshealth.eventquestion where questionid="+questionId+ " and lower(event)='"+answerFieldValue.toLowerCase()+"' order by eventscriptsequence asc limit 1";
	}
    
    console.log("DBUtil.getEventDetails called with param >>>>> SQL Query is " +vSQL);
    
    connection.query(vSQL, function (error, results, fields) {
        if (error) {
            console.log('DBUtils.getEventDetails Error. the Error is: ', error);
    	} else {
    		console.log('DBUtils.getEventDetails results gound. results length is : '+results.length);
			if (results !== null && results.length > 0)  {
                closeConnection(connection); //all is done so releasing the resources
                console.log("DBUtil.getEventDetails : "+results.length);
                
				//MM 6-13-17 - Added addional variables to manage the full event driven interview lifecycle 
				//pull event questions into an array and set them back to QnAObject under session
                var eventQnaObj = {};
                //var eventObjArr = [];
				var maxEventSeq = 0;
                
                eventQnaObj = {
                	"questionId": results[0].eventquestionid==null?"":results[0].eventquestionid,
        			"questionVer": results[0].eventquestionversion==null?"":results[0].eventquestionversion,
        			"answer": "",
        			"processed": false,
        			"questionVersion":results[0].questionversion==null?"":results[0].questionversion,
        			"event":results[0].event==null?"":results[0].event,
        			"eventScriptSeq":results[0].eventscriptsequence==null?"":results[0].eventscriptsequence,
					"maxEventSeq":maxEventSeq,
        			"eventQuestion":results[0].question==null?"":results[0].question,
        			"eventFunction":results[0].eventfunction==null?"":results[0].eventfunction,
        			"eventFunVar":results[0].eventfuncionvariables==null?"":results[0].eventfuncionvariables,
        			"answerTable":results[0].answertable==null?"":results[0].answertable,
        			"answerKeyField":results[0].answerkeyfield==null?"":results[0].answerkeyfield,
        			"answerField":results[0].answerfield==null?"":results[0].answerfield,
        			"isDictionary":results[0].isdictionary==null?"":results[0].isdictionary,
        			"formatId":results[0].formatid==null?"":results[0].formatid,
        			"isMultiEntry":results[0].multientry==null?"":results[0].multientry,
        			"isOnlyOnce":results[0].onlyonce==null?"":results[0].onlyonce,
        			"isInsertNewRow":results[0].insertnewrow==null?"":results[0].insertnewrow,
        			"errResponse":results[0].errorresponse==null?"":results[0].errorresponse
                };
                       
                qnaObj.eventQNArr = eventQnaObj;
               
                //VG 5/26|| Added eventFunction execution code here 
				//Check if event fuction field is present
				console.log("DBUtil.getEventDetails :  Event function is >>> "+eventQnaObj.eventFunction);
				getMaxEventScriptId (qnaObj, session, callback);		
				
			} else {
				//MM 6-12-17 If there are no event driven questions for this event, move to next main question
				mainQuestionId = qnaObj.uniqueStepId + 1;
				getScriptDetails(mainQuestionId, sessionAttributes.scriptName, sessionAttributes.logosname, session, callback, false);

			}
				
		}
    });
}//Function getEventDetails() ends here

//MM 6-13-17 Get the Max EventSequenceID for this event driven interview
function getMaxEventScriptId (qnaObj, session, callback) {
	var connection2 = getLogosConnection();
    var vSQL2;
	var questionId = qnaObj.questionId;

	//console.log('DBUtils.getMaxEventScriptId maxEventSeq: '+ qnaObj.eventQNArr.maxEventSeq);
	if (qnaObj.eventQNArr.maxEventSeq == 0) {

    	vSQL2="select max(eventscriptsequence) as value from logoshealth.eventquestion where questionid="+questionId+ " and lower(event)='"+qnaObj.eventQNArr.event.toLowerCase()+"'";
		console.log('DBUtils.getMaxEventScriptId SQL is : '+vSQL2);

		connection2.query(vSQL2, function (error, results, fields) {
    	
			if (error) {
            	console.log('DBUtils.getMaxEventScriptId connection2 Error. the Error is: ', error);
    		} else {
    
				console.log('DBUtils.getMaxEventScriptId connection2 results gound. result is : '+results[0].value);
			
				if (results !== null && results.length > 0) {
					qnaObj.eventQNArr.maxEventSeq = results[0].value;
				};			
				console.log('DBUtils.getMaxEventScriptId The getMaxEventScript is : '+qnaObj.eventQNArr.maxEventSeq);
			}
			closeConnection(connection2); //all is done so releasing the resources
			
			if (qnaObj.eventQNArr.eventFunction !== ""){
					console.log('DBUtils.getMaxEventScriptId Loop1');
					processEventFunction(qnaObj, qnaObj.eventQNArr, qnaObj.eventQNArr.answer, session, callback);
			} else {  
					console.log('DBUtils.getMaxEventScriptId Loop2');
				//callback response with QnA object array
				helper.processQnAEvent(qnaObj, session, callback, false);
			}
		});	
	} else {
		console.log('DBUtils.getMaxEventScriptId The eventFunction is : '+ qnaObj.eventQNArr.eventFunction);
		if (qnaObj.eventQNArr.eventFunction !== ""){
				console.log('DBUtils.getMaxEventScriptId Loop3');
				processEventFunction(qnaObj, qnaObj.eventQNArr, qnaObj.eventQNArr.answer, session, callback);
		} else {  
			//callback response with QnA object array
			console.log('DBUtils.getMaxEventScriptId Loop4');
			helper.processQnAEvent(qnaObj, session, callback, false);
		}
	}
}


function getMinScriptId (questionId, scriptName, slotValue, session, callback, retUser, qnaObj) {
	var connection3 = getLogosConnection();
    var vSQL3;
	
	console.log('DBUtils.getMinScriptID: ' +session.attributes.minScriptId + ', maxScriptID: ' + session.attributes.maxScriptId);
	//MM 6-10-17 Add SQL and populate minUniqueStep ID for current interview on initial load
	if (session.attributes.minScriptId == 0) {
    	vSQL3="SELECT min(uniquestepid) as value FROM logoshealth.script s, logoshealth.question q where s.questionid=q.questionid and scriptname='"+scriptName+"'";

		connection3.query(vSQL3, function (error, results, fields) {
    	
			if (error) {
            	console.log('DBUtils.getMinScriptID connection3 Error. the Error is: ', error);
    		} else {
    
				console.log('DBUtils.getMinScriptID connection3 results gound. results length is : '+results.length);
			
				if (results !== null && results.length > 0) {
					session.attributes.minScriptId = results[0].value;
				};
			
				console.log('DBUtils.DBUtils.getMinScriptID The minScriptID is : '+session.attributes.minScriptId);
			}
			closeConnection(connection3); //all is done so releasing the resources
			getMaxScriptId (questionId, scriptName, slotValue, session, callback, retUser, qnaObj);
		});
	} else {
			getMaxScriptId (questionId, scriptName, slotValue, session, callback, retUser, qnaObj);		
	}	
	
	
}

function getMaxScriptId (questionId, scriptName, slotValue, session, callback, retUser, qnaObj) {
	var connection2 = getLogosConnection();
    var vSQL2;
	
		//MM 6-10-17 Add SQL and populate maxUniqueStep ID for current interview on initial load
	if (session.attributes.maxScriptId == 0) {

    	vSQL2="SELECT max(uniquestepid) as value FROM logoshealth.script s, logoshealth.question q where s.questionid=q.questionid and scriptname='"+scriptName+"'";

		connection2.query(vSQL2, function (error, results, fields) {
    	
			if (error) {
            	console.log('DBUtils.getScriptDetails connection2 Error. the Error is: ', error);
    		} else {
    
				console.log('DBUtils.getScriptDetails connection2 results gound. results length is : '+results.length);
			
				if (results !== null && results.length > 0) {
					session.attributes.maxScriptId = results[0].value;
				};
			
				console.log('DBUtils.getMaxScriptId The maxScriptID is : '+session.attributes.maxScriptId);
				helper.processQnAResponse(qnaObj, session, callback, retUser);
			}
			closeConnection(connection2); //all is done so releasing the resources
			helper.processQnAResponse(qnaObj, session, callback, retUser);
		});	
	
	} else {
		//callback response with QnA object array
		helper.processQnAResponse(qnaObj, session, callback, retUser);		
	}
		

}
//VG 2/26|Purpose: To pull script based questions for Alexa Madam
//MM 6-10-17 Adding the capture of two addtional persistence variables: scriptname which will be used to enter into the staging script table and max step id which will be used to identfiy 
//when a script has been completed
function getScriptDetails(questionId, scriptName, slotValue, session, callback, retUser) {
	
	console.log("DBUtil.getScriptDetails called with param >>>>> Question ID " +questionId+ " and return user? "+retUser);
	
	var connection = getLogosConnection();
	var connection2 = getLogosConnection();
	var connection3 = getLogosConnection();
    var vSQL;
    
	//MM 6-10-17 setting session attribute scriptname
	session.attributes.scriptName = scriptName;
	
	if (questionId == 0){
        vSQL="SELECT q.*,s.* FROM logoshealth.script s, logoshealth.question q where s.questionid=q.questionid and scriptname='"+scriptName+"' order by uniquestepid asc limit 1";
    }
    else {
        vSQL="SELECT q.*,s.* FROM logoshealth.script s, logoshealth.question q where s.questionid=q.questionid and scriptname='"+scriptName+"' and uniquestepid="+questionId;    
    }
    console.log("DBUtil.getScriptDetails Query is  >>>>> " +vSQL);

	connection.query(vSQL, function (error, results, fields) {
    	
    	var qnaObj = {};
    	var eventQNArr = {};
		if (error) {
            console.log('DBUtils.getScriptDetails Error. the Error is: ', error);
    	} else {
    
			console.log('DBUtils.getScriptDetails results gound. results length is : '+results.length);
			
			if (results !== null && results.length > 0) {
			
				qnaObj = {
					"questionId": results[0].questionid,
					"question": results[0].question,
					"answer": "",
					"processed": false,
					"uniqueStepId":results[0].uniquestepid,
					"scriptname":scriptName,
					"answerKey":results[0].answerkeyfield,
					"answerField":results[0].answerfield,
					"answerTable":results[0].answertable,
					"answerFieldValue":0,
					"insertNewRow":results[0].insertnewrow,
					"isDictionary":results[0].isdictionary,
					"formatId":results[0].formatid,
					"eventSpecific":results[0].iseventspecific,
					"eventQNArr":eventQNArr,
					"errResponse":results[0].errorresponse
				};
			
				console.log('DBUtils.getScriptDetails The QnA Objects is : '+qnaObj);
			}
		}
		closeConnection(connection); //all is done so releasing the resources
		console.log("DBUtil.getScriptDetails : Message send for return user? >>> "+retUser);
		session.attributes.retUser = retUser;
		getMinScriptId (questionId, scriptName, slotValue, session, callback, retUser, qnaObj);
		//callback response with QnA object array
		//helper.processQnAResponse(qnaObj, session, callback, retUser);
	});
}

//VG 2/28|Purpose: Read the answers and Insert/Update the Profile
//MM 6-10-17 Various updates to genericize function
function saveAnswer(qnaObj, session, callback) {
        console.log("DBUtil.saveAnswer for >>>>> "+qnaObj.answer);
        var connection = getLogosConnection();
        var sessionAttributes = session.attributes;
        var profileId = sessionAttributes.profileid;
        var logosname = sessionAttributes.logosname;
        var isPrimary = session.attributes.isPrimaryProfile;
        
        console.log("DBUtil.saveAnswer for >>>>> profileId : "+profileId);
        console.log("DBUtil.saveAnswer for >>>>> uniquestepid : "+qnaObj.uniqueStepId);
        
        //retrieve the specific step in the script with mapping to data tables/fields
        var chkQuery = "SELECT s.*,q.* from logoshealth.script s, logoshealth.question q where s.questionid=q.questionid and uniquestepid="+qnaObj.uniqueStepId;
        
        console.log('DBUtil.saveAnswer Profile retrieve query is - ' + chkQuery);

        //Check 1: If the script step call for insert, insert a new record
        connection.query(chkQuery,function(error,results,fields) {
          if(error)  {
                console.log('The Error is: DBUtil.saveAnswer - ', error);
          }
            else {
                    closeConnection(connection);
                    if (results !== null && results.length > 0) {
                        var rec;
                        var insertRec;
                        var tblName = results[0].answertable;
                        var vFields = results[0].answerfield;
						var answerKey = results[0].answerkeyfield;
						var insertSQL = {};
						var equalSplit;
						
						if(vFields !== null && vFields.length > 0){   						
							 vFields=vFields.split(","); //This will split based on the comma
							//MM 6-10-17 Added functionality to handle hardcoded values within field mapping as well as known field mapping.
							//Stated behavior - ****For insert, the spoken answer will map to the last field always.
							//Besides this, there are two types of fields - one which maps to specific fields in the system attributes and two
							//hardcoded values with an = sign in them.
                        	if(results[0].insertnewrow == 'Y') {                            
                            	for (var i = 0; i < vFields.length - 1; i++) {
                                	console.log('The vField value in: DBUtil.saveAnswer - ' + tblName+' >> and field split '+vFields[i]);

									if (vFields[i].indexOf("=") != -1) {
										equalSplit = vFields[i].split("=");
									
										var fieldLabelSplit = equalSplit[0].trim();							
										var fieldSplit = equalSplit[1].trim();							
										insertSQL[fieldLabelSplit] = fieldSplit;
 	                                	console.log('DBUtil.saveAnswer - Build SQL From SPLIT ', insertSQL);
									
									} else {
										var fieldLabelMap = vFields[i].trim();							
										insertSQL[fieldLabelMap] = sessionAttributes[fieldLabelMap];
 	                                	console.log('DBUtil.saveAnswer - Build SQL From MAP ', insertSQL);
									}
                            	}
								var fieldLabel1 = vFields[vFields.length - 1];
								var fieldLabelTrim = fieldLabel1.trim();
								insertSQL[fieldLabelTrim] = qnaObj.answer;

								//MM 6-11-17 Added functionality to spoof the profile insert record with default user for prototype.
								if(sessionAttributes.profileid == 0){
									insertSQL["createdby"] = 2;
									insertSQL["modifiedby"] = 2;																
								} else {
									insertSQL["createdby"] = sessionAttributes.profileid;
									insertSQL["modifiedby"] = sessionAttributes.profileid;								
								}
								
								console.log('DBUtil.saveAnswer - FINAL INSERT SQL: ', insertSQL);
								console.log('DBUtil.saveAnswer - tblName: ', tblName);
								var insertStart = 'Insert into logoshealth.' + tblName + ' Set ?';
								console.log('DBUtil.saveAnswer - insertStart : ' + insertStart);
								connection = getLogosConnection();
                            	connection.query(insertStart, insertSQL, function (error, results, fields) {
                                                                if (error) {
                                                                        console.log('The Error is: DBUtil.saveAnswer INSERT- ', error);
                                                                } else {
                                                                        console.log('The record INSERTED successfully into Profile Table!!');
																		closeConnection(connection);
																		sessionAttributes.tableId = results.insertId;
																	
																		//MM 6-11-17 Set profile id when creating a new profile record
																		if (tblName == 'profile' && sessionAttributes.profileid == 0) {
																			sessionAttributes.profileid = results.insertId;
																		}
																	    setTranscriptDetailsParent(true, qnaObj, session, callback);  //insert records into Parent Transcript Array

                                                                        //getUniqueIdFromAnswerTable(qnaObj, qnaObj.answerTable, qnaObj.answerKey, profileId, session, callback);
                                                                }
                                                        });

                        	} else { //insertRow != Yes hence execute update
								//MM 6-11-17 Updated variables to ensure key field is generic
                                var updateRec="Update "+tblName+" Set "+vFields+" ='"+qnaObj.answer+"' Where "+answerKey+"="+sessionAttributes.tableId; //resArr.answerFieldValue;
                                console.log("DBUtil.saveAnswer - Update STMT >> ",updateRec);
                                connection = getLogosConnection();
                                connection.query(updateRec, function (error, results, fields) {
                                                                        if (error) {
                                                                                console.log('The Error is: DBUtil.saveAnswer UPDATE- ', error);
                                                                        } else {
                                                                                console.log('The record UPDATED successfully into Profile Table!!');
                                                                                closeConnection(connection);
                                                                                //insert records into Parent Transcript Array - Staging scripts would redirect to Response process
                                                                                setTranscriptDetailsParent(false, qnaObj, session, callback);  
                                                                        }
                                                                });
                            }
						
                    } else {
                        console.log("Fall Through where field is null - event function behavior");
						setTranscriptDetailsParent(false, qnaObj, session, callback);
					}
            	}	
			}			
        }); //First Select SQL ends here
} //Funcion ends here


function getUniqueIdFromAnswerTable(qnaObj, tableNm, colNm, profileId, session, callback) {
	console.log("DBUtil.getUniqueIdFromAnswerTable called "+qnaObj.answer);
	var connection = getLogosConnection();
	var answerVal = "";
	var slotVal = qnaObj.answer;
	var sessionAttributes = session.attributes;
	
	var query = "";
	if (tableNm != null && tableNm.toLowerCase() == 'profile') {
		query = "SELECT "+colNm+", primaryflag FROM "+tableNm+" where logosname = '"+ sessionAttributes.logosname + "' and accountid = '"+sessionAttributes.accountid+"'";
	} else {
		query = "SELECT "+colNm+" FROM "+tableNm+" where profileid = '"+profileId+"'";
	}
	
	console.log("DBUtil.getUniqueIdFromAnswerTable Select Query is >>> "+query);
	connection.query(query, function (error, results, fields) {
		if (error) {
			console.log('The Error is: ', error);
		} else {
			console.log('Get Answer Key Value select query works with records size '+results.length);
			if (results !== null && results.length > 0) {
                answerVal = results[0][qnaObj.answerKey];
                console.log("DBUtil.getUniqueIdFromAnswerTable - ID retrieved as >>>> "+answerVal);
                if (tableNm != null && tableNm.toLowerCase() == 'profile') {
                	profileId = results[0].profileid;
                	session.attributes.profileid = profileId;
                	if (results[0].primaryflag.toLowerCase() == 'y') {
                		session.attributes.isPrimaryProfile = true;
                	}
                } 
                
                qnaObj.answerFieldValue = answerVal;
				closeConnection(connection);
				
				setTranscriptDetailsParent(true, qnaObj, session, callback);  //insert records into Parent Transcript Array
            } else {
            	console.log("DBUtil.getUniqueIdFromAnswerTable Results are empty, that mean no profile found which is created just now >>> "+query);
            }
		}
	});
}

function getDictionaryId(qnaObj, value, processor, session, callback) {
	console.log("DBUtil.getDictionaryId called to get Dictionary ID for value >>>  "+value);
	console.log("DBUtil.getDictionaryId called to get Dictionary ID for Question ID >>>  "+qnaObj.questionId);
	console.log("DBUtil.getDictionaryId called to get Dictionary ID for answerField  >>>  "+qnaObj.answerField);
	
	var connection = getLogosConnection();
	var dictId = "";
	var fields = qnaObj.answerField === null?"":qnaObj.answerField.split(",");
	var field = "";
	var query = "";
	
	console.log("DBUtil.getDictionaryId called to get Dictionary : Filed and Fileds are  >>>  "+field+" and "+fields[fields.length-1]);
	
	if (fields != "") {
		field = fields[fields.length-1];
		query = "SELECT dictionaryid FROM logoshealth.dictionary WHERE fieldname = '"+field.trim()+"' and (value = '"+value+"' OR dictionarycode = '"+value+"' )";
	} else {
		query = "SELECT * FROM logoshealth.dictionary WHERE questionid = "+qnaObj.questionId+" and (value = '"+value+"')";
	}
	
	console.log("DBUtil.getDictionaryId Select Query is >>> "+query);
	
	connection.query(query, function (error, results, fields) {
		if (error) {
			console.log("DBUtil.getDictionaryId - Database QUERY ERROR >>>> ");
		} else {
			console.log('DBUtil.getDictionaryId - Query results '+results.length);
			
			if (results !== null && results.length > 0) {
                dictId = results[0].dictionaryid;
       			console.log("DBUtil.getDictionaryId - Dictionary ID retrieved as >>>> "+dictId);
       			qnaObj.answer = dictId;
    			console.log(' DBUtil.getDictionaryId Found: Set Dictionary Id to temp and QnA Objects >>>>>> '+qnaObj.answer);
    			closeConnection(connection);
				
				//MM 6-12-17 Data needs to be saved, so move event specific check to child staging record change 
    			saveAnswer(qnaObj, session, callback);
				
				/* if (qnaObj.eventSpecific != "" && qnaObj.eventSpecific.toLowerCase() == 'y') {
    				getEventDetails(qnaObj, session, callback);
    			} else {
    				saveAnswer(qnaObj, session, callback);
    			} */
            } else {
            	console.log("DBUtil.getDictionaryId - RegEx threw error for user input >>>> "+qnaObj.errResponse);
    			//process error response
    			helper.processErrResponse(qnaObj.errResponse, processor, session, callback);
            }
		}
	});
}

function validateUserInput(qnaObj, value, processor, session, callback) {
	console.log("DBUtil.validateUserInput called to get regex script for value >>>  "+value);
	var connection = getLogosConnection();
	var regEx = "";
	var query = "select formatcode from logoshealth.format where formatid="+qnaObj.formatId;
	console.log("DBUtil.validateUserInput Select Query is >>> "+query);
	
	connection.query(query, function (error, results, fields) {
		if (error) {
			console.log("DBUtil.validateUserInput - Database QUERY ERROR >>>> ");
		} else {
			console.log('DBUtil.validateUserInput - Query results '+results.length);
			
			if (results !== null && results.length > 0) {
                regEx = results[0].formatcode;
                var pattern = "";
                
                if (qnaObj.formatId == 1) {
                	//validate with zipcode
                	pattern = new RegExp("^[0-9]{5}(?:-[0-9]{4})?$");
                } else if (qnaObj.formatId == 2) {
                	//validate with phone number format
                	pattern = new RegExp("^\\d{10}$");
                } else if (qnaObj.formatId == 3) {
                	//validate with allowed data format yyyy-mm-dd TODO: actual date conversion is required.
                	pattern = new RegExp("^\d{4}-\d{2}-\d{2}$");
                	//pattern = new RegExp("date_format()");
                } else if (qnaObj.formatId == 4) {
                	//validate 9 digits
                	pattern = new RegExp("^\\d{9}$");
                } 
                
       			console.log("DBUtil.getDictionaryId - RegEx Format retrieved as >>>> "+regEx);
       			
       			//var pattern = new RegExp(results[0].formatcode);
       			if (pattern.test(value)) {
       				qnaObj.answer = value;
    				console.log(' LogosHelper.executeCreateProfileQNA Found Q answered: skipping to DB for isnert/update >>>>>> '+qnaObj.answer);
    				saveAnswer(qnaObj, session, callback);
    			} else {
    				console.log("DBUtil.validateUserInput - RegEx threw error for user input >>>> "+qnaObj.errResponse);
    				//process error response
    				helper.processErrResponse(qnaObj.errResponse, processor, session, callback);
    			}
            } 
		}
		closeConnection(connection);
	});
}

function getLogosConnection() {
	console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'logoshealth.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'logosadmin', //yet to encrypt password and read from properties
        password : 'L0g0sH3alth', //yet to encrypt password and read from properties
        database: 'logoshealth'
    });
    
    return connection;
}

function loadUserAccounts() {
	var connection = getLogosConnection();
	var accountsArr = [];
	connection.query('SELECT * FROM logoshealth.Account', function (error, results, fields) {
        if (error) {
            console.log('The Error is: ', error);
        } else {
            if (results !== null && results.length > 0) {
                for (var res in results) {
                    console.log('DBUtils - Record row is >>>> : ', results[res]);
                    accountsArr.push(results[res]);
                }
            }
            connection.end();
        }
    });
    
    return accountsArr;
}

//Load Account ID based on Email registered with the Alexa
function loadAccountIDFromEmail(email, session, callback) {
	console.log("DBUtil.getAccountFromEmail called with param >>>>> "+email);
	var connection = getLogosConnection();
	var accountid = "";
	connection.query("SELECT accountid FROM logoshealth.Account where email = '"+ email + "'" , function (error, results, fields) {
        if (error) {
            console.log('The Error is: ', error);
        } else {
            if (results !== null && results.length > 0) {
                for (var res in results) {
                    console.log('DBUtils - Email found from account table >>>> : ', results[res]);
                    accountid = results[res].accountid;
                    helper.displayWelcomeMsg(accountid, session, callback);
				    console.log('DBUtils - AccountID from email inside loop>>> : ', accountid);
                }
            } else{
				createNewAccountIDFromEmail(email, session, callback, connection);
			}
			
            connection.end();
        }
    });
    
    console.log('DBUtils - AccountID from email outside of loop near return>>> : ', accountid);
    return accountid;
}

//Check of logosname has already registered account, if not we continue to create one or menu
function getUserProfileByName(userName, accountId, session, callback) {
    console.log("DBUtil.getUserProfileByName called with param >>>>> "+userName+" and "+accountId);
    
	var connection = getLogosConnection();
	var hasProfile = false;
	var profileComplete = false;
	var profileId = 0;
	console.log("DBUtil.getUserProfileByName - Initiating SQL call ");
	connection.query("SELECT * FROM logoshealth.profile where logosname = '"+userName+ "' and accountid = '"+accountId+"'", function (error, results, fields) {
        if (error) {
            console.log('The Error is: ', error);
        } else {
            if (results !== null && results.length > 0) {
                console.log("DBUtil.getUserProfileByName Profile ID found as  >>>>>"+results[0].profileid);
                hasProfile = true;
				//MM 6-6-17 Changed to proper database attribute
                //profileComplete = results[0].iscomplete;
				if (results[0].confirmedflag.toLowerCase() == 'y') {
					profileComplete = true;
				}
				
				
                profileId = results[0].profileid;

				if (results[0].primaryflag.toLowerCase() == 'y') {
                	session.attributes.isPrimaryProfile = true;
                }
            }
        }
        connection.end();
        
        session.attributes.logosname = userName;
        
        
        // check if user has completed profile, if yes send them back to main menu
		// if not bring QnA object with current or last save point and respond.
		
		//MM 6-6-17 *****Add Code Here to check staging for any outstanding interviews*****
        if (profileComplete) {
			//MM 6-10-17 *****Add Code Here to check staging for any outstanding interviews*****
        	helper.processNameIntent(userName, profileId, hasProfile, profileComplete, session, callback);
        } else {
        	checkIfAccountHasAnyPrimaryProfile(userName, profileId, hasProfile, accountId, profileComplete, session, callback);
        }
    });
}

//check if account has any profile associated to it, if not new one to be primary
function checkIfAccountHasAnyPrimaryProfile(userName, profileId, hasProfile, accountId, profileComplete, session, callback){
	console.log("DBUtil.checkIfProfileHasPrimaryProfile called with hasProfile >>>>> "+hasProfile);
    
	var connection = getLogosConnection();
	//check if any profile exists for this account
	var sql = "select * from logoshealth.profile where accountid="+accountId+" and lower(primaryflag) = 'y' ";
	console.log("DBUtil.getUserProfileByName - Initiating SQL call "+sql);
	var isPrimary = true;
	var primaryFirstName = "";
	var primaryProfileId = 0;
	
	connection.query(sql, function (error, results, fields) {
        if (error) {
            console.log('DBUtil.checkIfProfileHasPrimaryProfile : The Error is: ', error);
        } else {
            if (results !== null && results.length > 0) {
                console.log("DBUtil.getUserProfileByName : Main account do not have any account listed, which mean its primary account >>>>>"+results[0].logosname);
                isPrimary = false;
                primaryFirstName = results[0].firstname;
                primaryProfileId = results[0].profileid;
            }
        }
        connection.end();
        
        session.attributes.isPrimaryProfile = isPrimary;
        session.attributes.primaryAccHolder = primaryFirstName;
        session.attributes.primaryProfileId = primaryProfileId;
        
        //process user response
        if (!hasProfile) {
        	helper.processNameIntent(userName, profileId, hasProfile, profileComplete, session, callback);
        } else {
        	loadProfileCreateContinueFromStaging(userName, profileId, hasProfile, profileComplete, session, callback);
        }
    });
}

//MM 6-10-17 ***This function is only for continuing a create profile interview script and will only be triggered if the profile has been started but not yet completed
//MM 6-10-15 Changed name to loadProfileCreateContinueFromStaging
function loadProfileCreateContinueFromStaging(userName, profileId, hasProfile, profileComplete, session, callback) {
	console.log("DBUtil.loadProfileCreateContinueFromStaging called with param >>>>> "+profileId);
    var connection = getLogosConnection();
    var questionId = 0;
    var isPrimary = session.attributes.isPrimaryProfile;
    
    console.log("DBUtil.loadProfileCreateContinueFromStaging called for the first time, is it? "+session.attributes.retUser);
    
    var retUser = false;
    
    // Get max available question id from staging using profile id
    //if no record found that mean user to start with First Question else max +1 question onwards
    connection.query("select max(uniquestepid) as uniquestepid, stg_scriptid from logoshealth.stg_script where profileid = "+profileId, function (error, results, fields) {
	if (error) {
            console.log('The Error is: ', error);
    } else {
		console.log('DBUtil.loadProfileCreateContinueFromStaging - The Staging Question ID found as '+results[0].uniquestepid);
		if (results.length > 0) {
			questionId = results[0].uniquestepid + 1;
			//MM 6-12-17 Added stgscriptid
			session.attributes.stgScriptId = results[0].stg_scriptid;
			session.attributes.profileid = profileId;
			if (session.attributes.retUser == undefined) {
    			retUser = true;
    		}
		} 
	}
        closeConnection(connection); //all is done so releasing the resources
        var scriptName = "Create a New Primary Profile";
        
        if(!isPrimary) {
        	scriptName = "Create a New Profile - Not primary - User adding own record";
        }
        
        console.log('DBUtil.loadProfileCreateContinueFromStaging - is User returing? '+retUser);
        getScriptDetails(questionId, scriptName, userName, session, callback, retUser);
	});
}

function closeConnection(connection) {
	connection.end();
}

function isEmpty(obj) {
    for(var key in obj) {
        if(obj.hasOwnProperty(key))
            return false;
    }
    return true;
}