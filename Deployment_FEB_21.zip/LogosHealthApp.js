'use strict';

var dbUtil = require('./utils/DBUtils');
var helper = require('./utils/LogosHelper');
var request = require('request');

// --------------- Functions that control the skill's behavior -----------------------
function onLaunch(event, launchRequest, session, callback) {
	var data = "";
	
	//getAccountLinkName(event, data, callback);
	accountEmail(event, request, session, accountId, callback);
}

function accountId(error, data, callback) {
    if (error) throw error;
    console.log(" The Email found from account is "+data.email);
    dbUtil.getAccountIdFromEmail(data.email, callback);
}

var accountEmail = function (event, request, session, accountId, callback) {
    console.log(" Getting Account Linked Email ");
	
	var amznProfileURL = 'https://api.amazon.com/user/profile?access_token=';
    amznProfileURL += event.session.user.accessToken;
    
    request(amznProfileURL, function(error, response, body) {
 	    var respBody = "";
 	    if (!error && response.statusCode == 200) {
    	    respBody = JSON.parse(body);
    	    console.log('Email from Amazon: ' + respBody.email);
	    }
	    accountId(error,respBody, callback);
	});
};


function processUserReponse(event, request, session, callback) {
    console.log('Generic User response has been triggered >>>>>>');
    var sessionAttributes = session.attributes;
    
    switch (sessionAttributes.currentProcessor) {
    case 0:
        helper.getUserName(callback);
        break;
    case 1:
        //process method
        break;
    case 2:
        //process method
        break;
    case 3:
        //process method
        break;
    case 4:
        //process method
        break;
    case 5:
        //process method
        break;
    default: helper.displayWelcomeMsg(callback, "");
    }
    
}

function handleSessionEndRequest(callback) {
    helper.processSessionEnd(callback);
}

function processIntent(event, context, intentRequest, session, callback) {
    console.log("onIntent requestId=" + intentRequest.requestId
        + ", sessionId=" + session.sessionId);
 
    var intent = intentRequest.intent,
        intentName = intentRequest.intent.name;
 
 
    // dispatch custom intents to handlers here
    if (intentName == 'OpenLogosHealthProfile') {
        helper.openProfile(event, context,intent, session, callback);
    }    
    else if (intentName == 'CreateLogosHealthProfile') {        
	    helper.createProfile(event, context, intent, session, callback);    
    } 
    else if (intentName == 'AMAZON.HelpIntent') {        
	    //helpRequest(intent, session, callback);    
    }    
    else if (intentName == 'AMAZON.CancelIntent')  {        
	    //quitRequest(intent, session, callback);  
    }
    else if (intentName == 'LaunchIntent')  {        
	    processUserReponse(event, intent, session, callback);  
    }
    else {
        //throw "Invalid intent";
        processUserReponse(event, intent, session, callback);
    }
}


/**
 * Called when the session starts.
 */
function onSessionStarted(event, sessionStartedRequest, session) {
    console.log('onSessionStarted requestId=${sessionStartedRequest.requestId}, sessionId=${session.sessionId}');
}

function onSessionEnded(sessionEndedRequest, session) {
    console.log('onSessionEnded requestId=${sessionEndedRequest.requestId}, sessionId=${session.sessionId}');
    
}
// --------------- Main handler -----------------------
exports.handler = (event, context, callback) => {
    try {
        
        if (event.session.new) {           
            console.log('New Session created >>>>>');
            onSessionStarted(event,{ requestId: event.request.requestId }, event.session);
            onLaunch(event,event.request,event.session,
                    (sessionAttributes, speechletResponse) => {
                        callback(null, helper.buildResponse(sessionAttributes, speechletResponse));
                    });
        } else {
        
            if (event.request.type === 'LaunchRequest') {
                console.log('Launch Request processing >>>>>.');
                onLaunch(event,event.request,event.session,
                    (sessionAttributes, speechletResponse) => {
                        callback(null, helper.buildResponse(sessionAttributes, speechletResponse));
                    });
            } else if (event.request.type === 'IntentRequest') {
                console.log('Intent Request processing >>>>>');
                processIntent(event, context, event.request,event.session,
                    (sessionAttributes, speechletResponse) => {
                        callback(null, helper.buildResponse(sessionAttributes, speechletResponse));
                    });            
            } else if (event.request.type === 'SessionEndedRequest') {
                console.log('SessionEndedRequest >>>>>>');
                onSessionEnded(event.request, event.session);
                callback();
            }}
        } catch (err) {
            callback(err);
    }
};